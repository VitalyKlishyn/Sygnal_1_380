/*
 * sygnal_1_380_bus.c
 *
 *  Created on: 7 сент. 2022 г.
 *      Author: vitaly
 */

/* Includes ------------------------------------------------------------------*/

#include <string.h>
#include <stdlib.h>
#include "stm32f0xx_hal.h"
#include "stm32f0xx_hal_flash_ex.h"
#include "main.h"
#include "ds1307.h"
#include "sygnal_1_380_bus.h"
#include "sygnal_1_380_zu.h"
#include "sygnal_1_380.h"

const uint8_t sequenceABCphEqu[6] = {0x00, 0x70, 0x00, 0x70, 0x00, 0x70};	// 2
const uint8_t sequenceABCphDown[6] = {0x10, 0x50, 0x40, 0x60, 0x20, 0x30};	// 1
const uint8_t sequenceABCphUp[6] = {0x10, 0x30, 0x20, 0x60, 0x40, 0x50};  	// 0
const uint8_t sequenceAphUp[6] = {0x60, 0x70, 0x60, 0x70, 0x60, 0x70};		// 6
const uint8_t sequenceBphUp[6] = {0x50, 0x70, 0x50, 0x70, 0x50, 0x70};		// 7
const uint8_t sequenceCphUp[6] = {0x30, 0x70, 0x30, 0x70, 0x30, 0x70};		// 8

const uint32_t bitsData[4] = {UART_WORDLENGTH_7B, UART_WORDLENGTH_8B, UART_WORDLENGTH_9B, UART_WORDLENGTH_8B};
const uint32_t bitsStop[4] = {UART_STOPBITS_1, UART_STOPBITS_1_5, UART_STOPBITS_2, UART_STOPBITS_1};
const uint32_t bitsParity[4] = {UART_PARITY_NONE, UART_PARITY_EVEN, UART_PARITY_ODD, UART_PARITY_NONE};
const uint32_t baudRates[6] = {0x30, 0x60, 0xC0, 0x0180, 0x0240, 0x0480};	//  4800, 9600, 19200, 38400, 57600, 115200

extern TIM_HandleTypeDef    htim6;
extern TIM_HandleTypeDef    htim7;
extern I2C_HandleTypeDef	hi2c1;
extern uint32_t TableChangeTimeZimaLeto[ZIMALETO_TABLE_SIZE];

void InitializeBus(void)
{
//	FlashToRegisters();		// move to main.c for USART setup
	ReadRamToRegisters();
	InitOutputPins();
	InitInputPins();
	Setup_UARTs();
	cnt10mS = 10;
	IndexingRegisters();
	InitArchive();
	beginDelay = PREDELAY;			// in sec
	beginInputFlag = FALSE; // flag for delay digital inputs
	countTestDelay = 0;
	countSettingsDelay = 0;
#ifdef _BUS_OUTPUT_UART
	if(debugMessage == MESSAGE_BUS)
	{
		Println(&huart1, "\n------- Initialize_after_reset BUS ----------");
	}
#endif
}

void FlashToRegisters(void)
{
	nvAddress = FLASH_CONFIG_START_ADDR;
	nvIndex = 0;
	nvError = 0;
	while(nvAddress < FLASH_CONFIG_END_ADDR)
	{
		DevNVRAM.data32[nvIndex] = *(__IO uint32_t*) nvAddress;
		nvIndex += 1;
		nvAddress += 4;
	}

	if((DevNVRAM.config.VersionPP380 != VERSION_PP380) || (resetDefault == 1))
	{
		resetDefault = 0;
		memset(DevNVRAM.data32, 0, sizeof(DevNVRAM.data32));
		// set default data
		DevNVRAM.config.AlarmParam1 = COUNT_WAIT_ALARM;
		DevNVRAM.config.AlarmParam2 = COUNT_TIMER_ALARM;
		DevNVRAM.config.AlarmParam3 = ALARM_CYCLES_TRESHOLD;
		DevNVRAM.config.VoltageBatteryFull = U_BAT1;
		DevNVRAM.config.VoltageBatteryCharge = U_BAT2;
		DevNVRAM.config.VoltageBatteryDischarge = U_BAT3;
		DevNVRAM.config.VoltageBatteryOff = U_BAT4;
		DevNVRAM.config.VoltageBatteryGood = U_BAT5;
		DevNVRAM.config.VoltageBatteryFault = U_BAT6;
		DevNVRAM.config.TimeBatteryPrecharge = TIME_ZU_1;
		DevNVRAM.config.TimeBatteryTest = TIME_ZU_2;
		DevNVRAM.config.TimeBatteryCheck = TIME_ZU_3;
		DevNVRAM.config.TimeBatteryLimit = 24;			// TIME_ZU_4 * 3600;
		DevNVRAM.config.TimeBatteryHealth = 72;			// TIME_ZU_5 * 3600;
		DevNVRAM.config.PrechargeCycles = CYCLES_PRECHARGE;
		DevNVRAM.config.VersionPP380 = VERSION_PP380;
		DevNVRAM.config.DeviceType = 380;
		DevNVRAM.config.ReleaseDate = 922;		// month, year
		DevNVRAM.config.SerialNumber1 = 1;
		DevNVRAM.config.SerialNumber2 = 0;
		DevNVRAM.config.AddressPP380 = 0x01;
		DevNVRAM.config.BaudRate = 96;
		DevNVRAM.config.BitsConfig = 1;
		DevNVRAM.config.VoltageLevelInput = U_AC;			// 14, 14v default
		DevNVRAM.config.VoltageInputHysteresis = 1;		// in V (1==>1.0V)
		DevNVRAM.config.VoltageLevelBattery = 110;			// U_BAT7, Uak7, in V*10 (110==>11.0V)
		DevNVRAM.config.VoltageBatteryHysteresis = 10;			// in V*10 (10==>1.0V)
		DevNVRAM.config.LowTemperature = LOW_TEMPERATURE;
		DevNVRAM.config.LowHysteresys = LOW_HYSTERESIS;
		DevNVRAM.config.HighTemperature = HIGH_TEMPERATURE;
		DevNVRAM.config.HighHysteresis = HIGH_HYSTERESIS;
		DevNVRAM.config.FaultControl = FAULT_CONTROL;
		DevNVRAM.config.DelayNetSensor = FAZA_DELAY;	// in second, MSB-test poryadok phase
		//  Inputs store DevNVRAM
		DevNVRAM.config.DF1.CfgTypeDelay = 0x0005;	//		0x05 -> 1 Sec., NO-type
		memset(DevNVRAM.config.DF1.Name, 0, sizeof(DevNVRAM.config.DF1.Name));
		memcpy(DevNVRAM.config.DF1.Name, "VYSOKA T(cS) VODY", 17);	// "Висока T (°C) води";
		DevNVRAM.config.DF2.CfgTypeDelay = 0x0005;	//		0x05 -> 1 Sec., NO-type
		memset(DevNVRAM.config.DF2.Name, 0, sizeof(DevNVRAM.config.DF2.Name));
		memcpy(DevNVRAM.config.DF2.Name, "NYZjKYJ TYSK VODY", 17);  // "Низький тиск води";
		DevNVRAM.config.DF3.CfgTypeDelay = 0x0005;	//		0x05 -> 1 Sec., NO-type
		memset(DevNVRAM.config.DF3.Name, 0, sizeof(DevNVRAM.config.DF3.Name));
		memcpy(DevNVRAM.config.DF3.Name, "VYSOKYJ TYSK GAZU", 17);  // "Високий тиск газу";
		DevNVRAM.config.DF4.CfgTypeDelay = 0x0005;	//		0x05 -> 1 Sec., NO-type
		memset(DevNVRAM.config.DF4.Name, 0, sizeof(DevNVRAM.config.DF4.Name));
		memcpy(DevNVRAM.config.DF4.Name, "NYZjKYJ TYSK GAZU", 17);  // "Низький тиск газу";
		DevNVRAM.config.DF5.CfgTypeDelay = 0x0005;	//		0x05 -> 1 Sec., NO-type
		memset(DevNVRAM.config.DF5.Name, 0, sizeof(DevNVRAM.config.DF5.Name));
		memcpy(DevNVRAM.config.DF5.Name, "ZAGAZOVANISTj SN4", 17);  // "Загазованість CН4";
		DevNVRAM.config.DF6.CfgTypeDelay = 0x0005;	//		0x05 -> 1 Sec., NO-type
		memset(DevNVRAM.config.DF6.Name, 0, sizeof(DevNVRAM.config.DF6.Name));
		memcpy(DevNVRAM.config.DF6.Name, "POgEgNA TRYVOGA", 15);  // "Пожежна тривога";
		DevNVRAM.config.DF7.CfgTypeDelay = 0x0005;	//		0x05 -> 1 Sec., NO-type
		memset(DevNVRAM.config.DF7.Name, 0, sizeof(DevNVRAM.config.DF7.Name));
		memcpy(DevNVRAM.config.DF7.Name, "VIDMOVA KOTLA", 13);  // "Відмова котла";
		DevNVRAM.config.DF8.CfgTypeDelay = 0x0005;	//		0x05 -> 1 Sec., NO-type
		memset(DevNVRAM.config.DF8.Name, 0, sizeof(DevNVRAM.config.DF8.Name));
		memcpy(DevNVRAM.config.DF8.Name, "OHORONNA TRYVOGA", 20);  // "Охоронна тривога";
		DevNVRAM.config.DF9.CfgTypeDelay = 0x0005;	//		0x05 -> 1 Sec., NO-type
		memset(DevNVRAM.config.DF9.Name, 0, sizeof(DevNVRAM.config.DF9.Name));
		memcpy(DevNVRAM.config.DF9.Name, "NYZjKYJ RIVENj VODY", 19);  // "Низький рівень води";
		DevNVRAM.config.DF10.CfgTypeDelay = 0x0005;	//		0x05 -> 1 Sec., NO-type
		memset(DevNVRAM.config.DF10.Name, 0, sizeof(DevNVRAM.config.DF10.Name));
		memcpy(DevNVRAM.config.DF10.Name, "AVARIa NASOSU n1", 16);  // "Аварія насосу №1";
		DevNVRAM.config.DF11.CfgTypeDelay = 0x0005;	//		0x05 -> 1 Sec., NO-type
		memset(DevNVRAM.config.DF11.Name, 0, sizeof(DevNVRAM.config.DF11.Name));
		memcpy(DevNVRAM.config.DF11.Name, "AVARIa NASOSU n2", 16);  // "Аварія насосу №2";
		DevNVRAM.config.DF12.CfgTypeDelay = 0x0005;	//		0x05 -> 1 Sec., NO-type
		memset(DevNVRAM.config.DF12.Name, 0, sizeof(DevNVRAM.config.DF12.Name));
		memcpy(DevNVRAM.config.DF12.Name, "NYZjKA T(cS) POVITRa", 20);  // "Низька T (°C) повітря";
		DevNVRAM.config.DF13.CfgTypeDelay = 0x0005;	//		0x05 -> 1 Sec., NO-type
		memset(DevNVRAM.config.DF13.Name, 0, sizeof(DevNVRAM.config.DF13.Name));
		memcpy(DevNVRAM.config.DF13.Name, "REZERV 1", 8);  // "Резерв 1";
		DevNVRAM.config.DF14.CfgTypeDelay = 0x0005;	//		0x05 -> 1 Sec., NO-type
		memset(DevNVRAM.config.DF14.Name, 0, sizeof(DevNVRAM.config.DF14.Name));
		memcpy(DevNVRAM.config.DF14.Name, "REZERV 2", 8);  // "Резерв 2";
		DevNVRAM.config.DF15.CfgTypeDelay = 0x0005;	//		0x05 -> 1 Sec., NO-type
		memset(DevNVRAM.config.DF15.Name, 0, sizeof(DevNVRAM.config.DF15.Name));
		memcpy(DevNVRAM.config.DF15.Name, "REZERV 3", 8);  // "Резерв 3";
		DevNVRAM.config.DF16.CfgTypeDelay = 0x0005;	//		0x05 -> 1 Sec., NO-type
		memset(DevNVRAM.config.DF16.Name, 0, sizeof(DevNVRAM.config.DF16.Name));
		memcpy(DevNVRAM.config.DF16.Name, "REZERV 4", 8);  // "Резерв 4";
		//  Outputs store DevNVRAM
		DevNVRAM.config.ReleF1.CfgTypeInit = (OUT_SHBL_NASOS << 8) | (OUT_CNTR_MASK << 2) | OUTTYPE_NC;
		DevNVRAM.config.ReleF1.Mask_0_15 = MASK_NASOS_VAL & 0xFFFF;
		DevNVRAM.config.ReleF1.Mask_16_31 = MASK_NASOS_VAL >> 16;
		memset(DevNVRAM.config.ReleF1.Name, 0, sizeof(DevNVRAM.config.ReleF1.Name));
		memcpy(DevNVRAM.config.ReleF1.Name, "NASOS n1", 8);
		DevNVRAM.config.ReleF2.CfgTypeInit = (OUT_SHBL_NASOS << 8) | (OUT_CNTR_MASK << 2) | OUTTYPE_NC;
		DevNVRAM.config.ReleF2.Mask_0_15 = MASK_NASOS_VAL & 0xFFFF;
		DevNVRAM.config.ReleF2.Mask_16_31 = MASK_NASOS_VAL >> 16;
		memset(DevNVRAM.config.ReleF2.Name, 0, sizeof(DevNVRAM.config.ReleF2.Name));
		memcpy(DevNVRAM.config.ReleF2.Name, "NASOS n2", 8);
		DevNVRAM.config.ReleF3.CfgTypeInit = (OUT_SHBL_MN << 8) | (OUT_CNTR_MASK << 2) | OUTTYPE_NC;
		DevNVRAM.config.ReleF3.Mask_0_15 = MASK_MN_VAL & 0xFFFF;
		DevNVRAM.config.ReleF3.Mask_16_31 = MASK_MN_VAL >> 16;
		memset(DevNVRAM.config.ReleF3.Name, 0, sizeof(DevNVRAM.config.ReleF3.Name));
		memcpy(DevNVRAM.config.ReleF3.Name, "MN", 2);
		DevNVRAM.config.ReleF4.CfgTypeInit = (OUT_SHBL_AVARIA << 8) | (OUT_CNTR_MASK << 2) | OUTTYPE_NO;
		DevNVRAM.config.ReleF4.Mask_0_15 = MASK_AVARIA_VAL & 0xFFFF;
		DevNVRAM.config.ReleF4.Mask_16_31 = MASK_AVARIA_VAL >> 16;
		memset(DevNVRAM.config.ReleF4.Name, 0, sizeof(DevNVRAM.config.ReleF4.Name));
		memcpy(DevNVRAM.config.ReleF4.Name, "AVARIa", 6);
		DevNVRAM.config.ReleF5.CfgTypeInit = (OUT_SHBL_SZO << 8) | (OUT_CNTR_MASK << 2) | OUTTYPE_NO;
		DevNVRAM.config.ReleF5.Mask_0_15 = MASK_SZO_VAL & 0xFFFF;
		DevNVRAM.config.ReleF5.Mask_16_31 = MASK_SZO_VAL >> 16;
		memset(DevNVRAM.config.ReleF5.Name, 0, sizeof(DevNVRAM.config.ReleF5.Name));
		memcpy(DevNVRAM.config.ReleF5.Name, "SZO", 3);
		DevNVRAM.config.ValveF.CfgTypeInit = (OUT_SHBL_KLAPAN << 8) | (OUT_CNTR_MASK << 2) | OUTTYPE_NO;
		DevNVRAM.config.ValveF.Mask_0_15 = MASK_KLAPAN_VAL & 0xFFFF;
		DevNVRAM.config.ValveF.Mask_16_31 = MASK_KLAPAN_VAL >> 16;
		memset(DevNVRAM.config.ValveF.Name, 0, sizeof(DevNVRAM.config.ValveF.Name));
		memcpy(DevNVRAM.config.ValveF.Name, "KLAPAN", 6);

		DevNVRAM.sector.cntWrite = 0;

		RefreshFlashData();						// write data to flash memory
		// set default registers
		InputCmd.InputDelay = 0x0005;			//	0x05 -> 1 Sec., NO-type
		OutputCmd.OutputType = (OUT_CNTR_MANUAL << 2) | PINTYPE_NO;
		OutputCmd.OutputMask0_15 = MASK_NASOS_VAL & 0xFFFF;				// 0x0002;
		OutputCmd.OutputMask16_31 = MASK_NASOS_VAL >> 16;
	}
}

void ReadRamToRegisters(void)
{
	ReadRAM(0, ClockRAM.data8, RAM_CONFIG_LEN_BYTES);
	if(ClockRAM.config.ramKey != RAM_KEY_DEFINE)
	{
		memset(ClockRAM.data8, 0, RAM_CONFIG_LEN_BYTES);
		ClockRAM.config.ramKey = RAM_KEY_DEFINE;
		ClockRAM.config.output_switch_PP380 = DEFAULT_SOFT_SWITCH;
		RefreshMemData();						// write data to clock RAM memory
	}
}

void TimeOutReceive_10ms(void)
{
	RunSequenceCmd();
	ComparePhase(phaseNet.select);
	if(UART_1.waitTimer)		UART_1.waitTimer--;
	if(UART_1.waitTimer == 1)	UART_1.dataReady++;
	if(UART_2.waitTimer)		UART_2.waitTimer--;
	if(UART_2.waitTimer == 1)	UART_2.dataReady++;
	if(UART_3.waitTimer)		UART_3.waitTimer--;
	if(UART_3.waitTimer == 1)	UART_3.dataReady++;
	if(VALVE.counter)			VALVE.counter--;
	if(beginInputFlag == FALSE)		return;
	ReadUART1();
	ReadUART2();
	ReadUART3();
	RefreshOutputPins();
	if(UART_1.cntTimeOut)	UART_1.cntTimeOut--;
	if(UART_1.cntTimeOut == 1)
	{
		UART_1.cntTimeOut = 0;
		UART_1.dataReady = 0;
	}
	if(UART_2.cntTimeOut)	UART_2.cntTimeOut--;
	if(UART_2.cntTimeOut == 1)
	{
		UART_2.cntTimeOut = 0;
		UART_2.dataReady = 0;
	}
	if(UART_3.cntTimeOut)	UART_3.cntTimeOut--;
	if(UART_3.cntTimeOut == 1)
	{
		UART_3.cntTimeOut = 0;
		UART_3.dataReady = 0;
	}
#ifdef _BUS_OUTPUT_UART
	if(debugMessage == MESSAGE_BUS)
	{
		TestStatus01();
	}
#endif
}

void Event_1sec_bus(void)
{
	Working();
	TimeToRegisters();			// refresh date/time in registers
	RefreshMemData();			// refresh data in clock memory
	DelayCounting();
}

void Setup_UARTs(void)
{
	USART1->CR1 |= USART_CR1_RXNEIE;
	UART_1.input_buff[0] = USART1->RDR;
	USART2->CR1 |= USART_CR1_RXNEIE;
	UART_2.input_buff[0] = USART2->RDR;
	USART3->CR1 |= USART_CR1_RXNEIE;
	UART_3.input_buff[0] = USART3->RDR;

	HAL_GPIO_WritePin(DIR1_GPIO_Port, DIR1_Pin, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(DIR2_GPIO_Port, DIR2_Pin, GPIO_PIN_RESET);

	WaitPeriod = (uint16_t)(WAIT_BASE / DevNVRAM.config.BaudRate);
	if(WaitPeriod < WAIT_PERIOD_MIN)		WaitPeriod = WAIT_PERIOD_MIN;

#ifdef _BUS_OUTPUT_UART
	if(debugMessage == MESSAGE_BUS)
	{
		char buf[8];
		Println(&huart1, "\nmyAddress 0x");
		itoa(DevNVRAM.config.AddressPP380, buf, 16);
		Println(&huart1, buf);
		Println(&huart1, "\nUART_1 speed: ");
		itoa(huart1.Init.BaudRate, buf, 10);
		Println(&huart1, buf);
		Println(&huart1, "\nUART_1 set speed: ");
		itoa(DevNVRAM.config.BaudRate*100, buf, 10);
		Println(&huart1, buf);
	}
#endif

	UART_1.cntReceive = 0;
	UART_1.dataReady = 0;
	UART_1.dataOver = 0;
	UART_1.waitTimer = 0;
	UART_1.cntTestLine = TEST_LINE_TIME;
	UART_1.tstLine = 0;
	UART_1.mineStranger = STRANGER;
	if(ClockRAM.config.LineTest & 0x0001)	UART_1.tstLine = 1;
	UART_2.cntReceive = 0;
	UART_2.dataReady = 0;
	UART_2.dataOver = 0;
	UART_2.waitTimer = 0;
	UART_2.cntTestLine = TEST_LINE_TIME;
	UART_2.tstLine = 0;
	UART_2.mineStranger = STRANGER;
	if(ClockRAM.config.LineTest & 0x0002)	UART_2.tstLine = 1;
	UART_3.cntReceive = 0;
	UART_3.dataReady = 0;
	UART_3.dataOver = 0;
	UART_3.waitTimer = 0;
	UART_3.cntTestLine = TEST_LINE_TIME;
	UART_3.tstLine = 1;			// for PI382
	UART_3.mineStranger = MINE;
	flagReInstal = 0;
	myAddress = DevNVRAM.config.AddressPP380 & 0xFF;	// copy address for work
	oldSpeed = DevNVRAM.config.BaudRate;
	errorInitUART1 = 0;
	errorInitUART2 = 0;
}

void RefreshFlashData(void)
{ // write data to flash memory
	static FLASH_EraseInitTypeDef  EraseInitStruct;
// Инициализация структуры для очистки памяти
	EraseInitStruct.TypeErase = FLASH_TYPEERASE_PAGES;
	EraseInitStruct.PageAddress = FLASH_CONFIG_START_ADDR;
	EraseInitStruct.NbPages = 0x01;

	nvAddress = FLASH_CONFIG_START_ADDR;
	nvIndex = 0;
	nvError = 0;
	while(nvAddress < FLASH_CONFIG_END_ADDR)
	{
		if(DevNVRAM.data32[nvIndex] != *(__IO uint32_t*) nvAddress)
		{
			nvError++;
		}
		nvIndex++;
		nvAddress += 4;
	}
	if(nvError != 0)
	{
		HAL_FLASH_Unlock();
		HAL_FLASHEx_Erase(&EraseInitStruct, &nvError);
#ifdef _BUS_OUTPUT_UART
		if(debugMessage == MESSAGE_BUS)
		{
			Println(&huart1, "\nErase Flash...");
		}
#endif
		nvAddress = FLASH_CONFIG_START_ADDR;
		nvIndex = 0;
		nvError = 0;
		DevNVRAM.sector.cntWrite++;
		while(nvAddress < FLASH_CONFIG_END_ADDR)
		{
			if(HAL_FLASH_Program(FLASH_TYPEPROGRAM_WORD, nvAddress, DevNVRAM.data32[nvIndex]) == HAL_OK)
			{
				nvIndex++;
				nvAddress += 4;
			}
		}
#ifdef _BUS_OUTPUT_UART
		if(debugMessage == MESSAGE_BUS)
		{
			Println(&huart1, "  Writing end!");
		}
#endif
		HAL_FLASH_Lock();
	}
}

void RefreshMemData(void)
{ // writing data to clock RAM memory
	ClockRAM.config.Temperature = ClockRAM.config.temperature;
	WriteRAM(0, ClockRAM.data8, RAM_CONFIG_LEN_BYTES);
}

void ReadUART1(void)
{
	if(UART_1.dataReady)
	{
		UART_1.num = 1;
		UART_1.cntTimeOut = WaitPeriod;
		ParseInput(&UART_1);
		UART_1.cntReceive = 0;
		UART_1.dataReady = 0;
	}
}

void ReadUART2(void)
{
	if(UART_2.dataReady)
	{
		UART_2.num = 2;
		UART_2.cntTimeOut = WaitPeriod;
		ParseInput(&UART_2);
		UART_2.cntReceive = 0;
		UART_2.dataReady = 0;
	}
}

void ReadUART3(void)
{
	if(UART_3.dataReady)
	{
		UART_3.num = 3;
		UART_3.cntTimeOut = WAITPERIOD_PI382;
		ParseInput(&UART_3);
		UART_3.dataReady = 0;
		UART_3.cntReceive = 0;
	}
}

void Working(void)
{ // in 1 second
	if(beginDelay)
	{
		beginDelay--;
		return;
	}
	if(beginInputFlag == FALSE)		return;
	ReadTime();
	ReadInputPins();
	SetOutputPins();
	ReadTemperature();
	TestOVP();
	TestLines();
	RunValve();
	OffSZO();
	TestPhase();
	ChangeSettings();
}

void ChangeSettings(void)
{
	if(countSettingsDelay == 0)
	{
		if((flagReInstal != 0) || (errorInitUART1 != 0) ||(errorInitUART2 != 0))
		{
			Ports_1_2_ReInit();
			flagReInstal = 0;
		}
		return;
	}
	if(countSettingsDelay == 1)
	{ // set old settings for port setting
		DevNVRAM.config.AddressPP380 = myAddress;
		DevNVRAM.config.BaudRate = oldSpeed;
		DevNVRAM.config.BitsConfig = oldParam;
		RefreshFlashData();
		flagReInstal = 1;
		countSettingsDelay = 0;
		BIT_CLR(ClockRAM.config.status_PP380, 1);
		BIT_CLR(ClockRAM.config.status_PP380, 2);
		InputCmd.InputsState = 0;
		OutputCmd.OutputState = 0;
#ifdef _BUS_OUTPUT_UART
		if(debugMessage == MESSAGE_BUS)
		{
			Println(&huart1, "\nwrite my address to NVRAM");
		}
#endif
	}
	if(countSettingsDelay > 1)
	{
		if((BIT_TEST(ClockRAM.config.status_PP380, 1) == 0) && (BIT_TEST(ClockRAM.config.status_PP380, 2) == 0))
		{
			myAddress = DevNVRAM.config.AddressPP380 & 0xFF;
			flagReInstal = 1;
			countSettingsDelay = 0;
			InputCmd.InputsState = 0;
			OutputCmd.OutputState = 0;
#ifdef _BUS_OUTPUT_UART
		if(debugMessage == MESSAGE_BUS)
		{
			Println(&huart1, "\nwrite NVRAM to my address");
		}
#endif
		}
	}
}

void OffSZO(void)
{
	if(BIT_TEST(ClockRAM.config.status_PP380, 5))
	{
		if(RELE1.shablon == OUT_SHBL_SZO)	RELE1.init = OUT_OFF_SZO;
		if(RELE2.shablon == OUT_SHBL_SZO)	RELE2.init = OUT_OFF_SZO;
		if(RELE3.shablon == OUT_SHBL_SZO)	RELE3.init = OUT_OFF_SZO;
		if(RELE4.shablon == OUT_SHBL_SZO)	RELE4.init = OUT_OFF_SZO;
		if(RELE5.shablon == OUT_SHBL_SZO)	RELE5.init = OUT_OFF_SZO;
		BIT_CLR(ClockRAM.config.status_PP380, 5);
	}
	if(flagDiSZO)
	{
		RELE1.init = (DevNVRAM.config.ReleF1.CfgTypeInit >> 2) & 0x0007;
		RELE2.init = (DevNVRAM.config.ReleF2.CfgTypeInit >> 2) & 0x0007;
		RELE3.init = (DevNVRAM.config.ReleF3.CfgTypeInit >> 2) & 0x0007;
		RELE4.init = (DevNVRAM.config.ReleF4.CfgTypeInit >> 2) & 0x0007;
		RELE5.init = (DevNVRAM.config.ReleF5.CfgTypeInit >> 2) & 0x0007;
		flagDiSZO = 0;
	}
}

void TestPhase(void)
{  // 1 Sec.
	if(phaseNet.phaseOld != phaseNet.phase)
	{ // phaseNet.phaseOld = phaseNet.phase in ComparePhase(phaseNet.select, sequenceABCphUp, FAZA_SELECT_SIZE);
		PhaseStateChange();
		phaseNet.phaseOld = phaseNet.phase;
		phaseNet.delay = (DevNVRAM.config.DelayNetSensor & 0x003F)+1;
		if(phaseNet.delay == 0)			phaseNet.delay = 1;
		if(phaseNet.phase < FAZA_AB)	phaseNet.delay = 1;
	}
	if((DevNVRAM.config.DelayNetSensor & 0x8000) == 0)
	{
		if(BIT_TEST(ClockRAM.config.di2_PP380, 7))
		{		// poryadok phase))
			BIT_CLR(ClockRAM.config.di2_PP380, 7);
			BIT_SET(ClockRAM.config.dim2_PP380, 7);
		}
	}
	if(phaseNet.delay == 1)
	{
		phaseNet.delay = 0;
		switch(phaseNet.phase)
		{
		case FAZA_NO_PHASE:
			BIT_SET(ClockRAM.config.di2_PP380, 6);		// no all phases
			if(BIT_TEST(ClockRAM.config.di2_PP380, 7))
			{
				BIT_CLR(ClockRAM.config.di2_PP380, 7);
				BIT_SET(ClockRAM.config.dim2_PP380, 7);
			}
			if(BIT_TEST(ClockRAM.config.di2_PP380, 3))
			{		// no phase 1
				BIT_CLR(ClockRAM.config.di2_PP380, 3);
				BIT_SET(ClockRAM.config.dim2_PP380, 3);
			}
			if(BIT_TEST(ClockRAM.config.di2_PP380, 4))
			{		// no phase 2
				BIT_CLR(ClockRAM.config.di2_PP380, 4);
				BIT_SET(ClockRAM.config.dim2_PP380, 4);
			}
			if(BIT_TEST(ClockRAM.config.di2_PP380, 5))
			{		// no phase 3
				BIT_CLR(ClockRAM.config.di2_PP380, 5);
				BIT_SET(ClockRAM.config.dim2_PP380, 5);
			}
			break;

		case FAZA_A:
			BIT_SET(ClockRAM.config.di2_PP380, 4);		// no phase 2
			BIT_SET(ClockRAM.config.di2_PP380, 5);		// no phase 3
			if(BIT_TEST(ClockRAM.config.di2_PP380, 3))
			{		// no phase 1
				BIT_CLR(ClockRAM.config.di2_PP380, 3);
				BIT_SET(ClockRAM.config.dim2_PP380, 3);
			}
			if(BIT_TEST(ClockRAM.config.di2_PP380, 7))
			{
				BIT_CLR(ClockRAM.config.di2_PP380, 7);
				BIT_SET(ClockRAM.config.dim2_PP380, 7);
			}
			if(BIT_TEST(ClockRAM.config.di2_PP380, 6))
			{
				BIT_CLR(ClockRAM.config.di2_PP380, 6);
				BIT_SET(ClockRAM.config.dim2_PP380, 6);
			}
			break;

		case FAZA_B:
			BIT_SET(ClockRAM.config.di2_PP380, 3);		// no phase 1
			BIT_SET(ClockRAM.config.di2_PP380, 5);		// no phase 3
			if(BIT_TEST(ClockRAM.config.di2_PP380, 4))
			{		// no phase 2
				BIT_CLR(ClockRAM.config.di2_PP380, 4);
				BIT_SET(ClockRAM.config.dim2_PP380, 4);
			}
			if(BIT_TEST(ClockRAM.config.di2_PP380, 7))
			{
				BIT_CLR(ClockRAM.config.di2_PP380, 7);
				BIT_SET(ClockRAM.config.dim2_PP380, 7);
			}
			if(BIT_TEST(ClockRAM.config.di2_PP380, 6))
			{
				BIT_CLR(ClockRAM.config.di2_PP380, 6);
				BIT_SET(ClockRAM.config.dim2_PP380, 6);
			}
			break;

		case FAZA_C:
			BIT_SET(ClockRAM.config.di2_PP380, 3);		// no phase 1
			BIT_SET(ClockRAM.config.di2_PP380, 4);		// no phase 2
			if(BIT_TEST(ClockRAM.config.di2_PP380, 5))
			{		// no phase 3
				BIT_CLR(ClockRAM.config.di2_PP380, 5);
				BIT_SET(ClockRAM.config.dim2_PP380, 5);
			}
			if(BIT_TEST(ClockRAM.config.di2_PP380, 7))
			{
				BIT_CLR(ClockRAM.config.di2_PP380, 7);
				BIT_SET(ClockRAM.config.dim2_PP380, 7);
			}
			if(BIT_TEST(ClockRAM.config.di2_PP380, 6))
			{
				BIT_CLR(ClockRAM.config.di2_PP380, 6);
				BIT_SET(ClockRAM.config.dim2_PP380, 6);
			}
			break;

		case FAZA_BC:
			BIT_SET(ClockRAM.config.di2_PP380, 3);		// no phase 1
			if(BIT_TEST(ClockRAM.config.di2_PP380, 7))
			{
				BIT_CLR(ClockRAM.config.di2_PP380, 7);
				BIT_SET(ClockRAM.config.dim2_PP380, 7);
			}
			if(BIT_TEST(ClockRAM.config.di2_PP380, 4))
			{		// no phase 2
				BIT_CLR(ClockRAM.config.di2_PP380, 4);
				BIT_SET(ClockRAM.config.dim2_PP380, 4);
			}
			if(BIT_TEST(ClockRAM.config.di2_PP380, 5))
			{		// no phase 3
				BIT_CLR(ClockRAM.config.di2_PP380, 5);
				BIT_SET(ClockRAM.config.dim2_PP380, 5);
			}
			if(BIT_TEST(ClockRAM.config.di2_PP380, 6))
			{
				BIT_CLR(ClockRAM.config.di2_PP380, 6);
				BIT_SET(ClockRAM.config.dim2_PP380, 6);
			}
			break;

		case FAZA_AC:
			BIT_SET(ClockRAM.config.di2_PP380, 4);		// no phase 2
			if(BIT_TEST(ClockRAM.config.di2_PP380, 7))
			{
				BIT_CLR(ClockRAM.config.di2_PP380, 7);
				BIT_SET(ClockRAM.config.dim2_PP380, 7);
			}
			if(BIT_TEST(ClockRAM.config.di2_PP380, 3))
			{		// no phase 1
				BIT_CLR(ClockRAM.config.di2_PP380, 3);
				BIT_SET(ClockRAM.config.dim2_PP380, 3);
			}
			if(BIT_TEST(ClockRAM.config.di2_PP380, 5))
			{		// no phase 3
				BIT_CLR(ClockRAM.config.di2_PP380, 5);
				BIT_SET(ClockRAM.config.dim2_PP380, 5);
			}
			if(BIT_TEST(ClockRAM.config.di2_PP380, 6))
			{
				BIT_CLR(ClockRAM.config.di2_PP380, 6);
				BIT_SET(ClockRAM.config.dim2_PP380, 6);
			}
			break;

		case FAZA_AB:
			BIT_SET(ClockRAM.config.di2_PP380, 5);		// no phase 3
			if(BIT_TEST(ClockRAM.config.di2_PP380, 7))
			{
				BIT_CLR(ClockRAM.config.di2_PP380, 7);
				BIT_SET(ClockRAM.config.dim2_PP380, 7);
			}
			if(BIT_TEST(ClockRAM.config.di2_PP380, 3))
			{		// no phase 1
				BIT_CLR(ClockRAM.config.di2_PP380, 3);
				BIT_SET(ClockRAM.config.dim2_PP380, 3);
			}
			if(BIT_TEST(ClockRAM.config.di2_PP380, 4))
			{		// no phase 2
				BIT_CLR(ClockRAM.config.di2_PP380, 4);
				BIT_SET(ClockRAM.config.dim2_PP380, 4);
			}
			if(BIT_TEST(ClockRAM.config.di2_PP380, 6))
			{
				BIT_CLR(ClockRAM.config.di2_PP380, 6);
				BIT_SET(ClockRAM.config.dim2_PP380, 6);
			}
			break;

		case FAZA_ABC_EQU:
		case FAZA_ABC_DOWN:
			if(DevNVRAM.config.DelayNetSensor & 0x8000)
			{
				BIT_SET(ClockRAM.config.di2_PP380, 7);		// poryadok phase
			}
			if(BIT_TEST(ClockRAM.config.di2_PP380, 6))
			{		// no all phases
				BIT_CLR(ClockRAM.config.di2_PP380, 6);
				BIT_SET(ClockRAM.config.dim2_PP380, 6);
			}
			if(BIT_TEST(ClockRAM.config.di2_PP380, 3))
			{		// no phase 1
				BIT_CLR(ClockRAM.config.di2_PP380, 3);
				BIT_SET(ClockRAM.config.dim2_PP380, 3);
			}
			if(BIT_TEST(ClockRAM.config.di2_PP380, 4))
			{		// no phase 2
				BIT_CLR(ClockRAM.config.di2_PP380, 4);
				BIT_SET(ClockRAM.config.dim2_PP380, 4);
			}
			if(BIT_TEST(ClockRAM.config.di2_PP380, 5))
			{		// no phase 3
				BIT_CLR(ClockRAM.config.di2_PP380, 5);
				BIT_SET(ClockRAM.config.dim2_PP380, 5);
			}
			break;

		case FAZA_ABC_UP:
			if(BIT_TEST(ClockRAM.config.di2_PP380, 7))
			{		// poryadok phase))
				BIT_CLR(ClockRAM.config.di2_PP380, 7);
				BIT_SET(ClockRAM.config.dim2_PP380, 7);
			}
			if(BIT_TEST(ClockRAM.config.di2_PP380, 6))
			{		// no all phases
				BIT_CLR(ClockRAM.config.di2_PP380, 6);
				BIT_SET(ClockRAM.config.dim2_PP380, 6);
			}
			if(BIT_TEST(ClockRAM.config.di2_PP380, 3))
			{		// no phase 1
				BIT_CLR(ClockRAM.config.di2_PP380, 3);
				BIT_SET(ClockRAM.config.dim2_PP380, 3);
			}
			if(BIT_TEST(ClockRAM.config.di2_PP380, 4))
			{		// no phase 2
				BIT_CLR(ClockRAM.config.di2_PP380, 4);
				BIT_SET(ClockRAM.config.dim2_PP380, 4);
			}
			if(BIT_TEST(ClockRAM.config.di2_PP380, 5))
			{		// no phase 3
				BIT_CLR(ClockRAM.config.di2_PP380, 5);
				BIT_SET(ClockRAM.config.dim2_PP380, 5);
			}
			break;

		default:
			break;
		}
	}
}

uint8_t ComparePhase(uint8_t *buff)
{
	uint8_t ci, imin, vmin, inBuff[FAZA_SELECT_SIZE], outBuff[6];

	if(beginDelay)				return FAZA_NO_PHASE;
	memset(outBuff, FAZA_NO_PHASE, sizeof(outBuff));
	memcpy(inBuff, buff, sizeof(inBuff));
// находим индекс наименьшего значения из входного буффера и проверяем наличие фаз
	imin = 0;			// index
	vmin = 0xFF;		// value
	for(ci=0; ci<FAZA_SELECT_SIZE; ci++)
	{
		if(vmin > inBuff[ci])
		{
			imin = ci;
			vmin = inBuff[ci];
		}
		if((inBuff[ci] & FAZA_NO_PHASE_A) == FAZA_NO_PHASE_A)
		{
			phaseNet.nophAcnt++;
			if(phaseNet.nophAcnt > FAZA_FAULT)		phaseNet.nophAcnt = FAZA_FAULT;
		}
		if((inBuff[ci] & FAZA_NO_PHASE_A) == 0)
		{
			phaseNet.nophAcnt = 0;
		}
		if((inBuff[ci] & FAZA_NO_PHASE_B) == FAZA_NO_PHASE_B)
		{
			phaseNet.nophBcnt++;
			if(phaseNet.nophBcnt > FAZA_FAULT)		phaseNet.nophBcnt = FAZA_FAULT;
		}
		if((inBuff[ci] & FAZA_NO_PHASE_B) == 0)
		{
			phaseNet.nophBcnt = 0;
		}
		if((inBuff[ci] & FAZA_NO_PHASE_C) == FAZA_NO_PHASE_C)
		{
			phaseNet.nophCcnt++;
			if(phaseNet.nophCcnt > FAZA_FAULT)		phaseNet.nophCcnt = FAZA_FAULT;
		}
		if((inBuff[ci] & FAZA_NO_PHASE_C) == 0)
		{
			phaseNet.nophCcnt = 0;
		}
	}
// составляем outBuff[6] из неповторяющихся значений inBuff от индекса наименьшего значения
	outBuff[0] = inBuff[imin];
	ci = 0;
	phaseNet.nophcnt = 0;
	while(ci<6)
	{
		if(outBuff[ci] != inBuff[imin])
		{
			outBuff[++ci] = inBuff[imin];
		}
		if(inBuff[imin] != FAZA_NO_PHASE)	phaseNet.nophcnt = 0;
		phaseNet.nophcnt++;						// проверка на отсутствие фаз
		if(phaseNet.nophcnt	> FAZA_SELECT_SIZE)		break;
		imin++;
		if(imin > FAZA_SELECT_SIZE-1)		imin = 0;
	}
	if(ci < 6)												phaseNet.phase = FAZA_NO_PHASE;
	else if(memcmp(outBuff, sequenceABCphUp, 6) == 0)		phaseNet.phase = FAZA_ABC_UP;
	else if(memcmp(outBuff, sequenceABCphDown, 6) == 0)		phaseNet.phase = FAZA_ABC_DOWN;
	else if(memcmp(outBuff, sequenceABCphEqu, 6) == 0)		phaseNet.phase = FAZA_ABC_EQU;
	else if(memcmp(outBuff, sequenceAphUp, 6) == 0)			phaseNet.phase = FAZA_A;
	else if(memcmp(outBuff, sequenceBphUp, 6) == 0)			phaseNet.phase = FAZA_B;
	else if(memcmp(outBuff, sequenceCphUp, 6) == 0)			phaseNet.phase = FAZA_C;
	else if(phaseNet.nophAcnt >= FAZA_FAULT)				phaseNet.phase = FAZA_BC;
	else if(phaseNet.nophBcnt >= FAZA_FAULT)				phaseNet.phase = FAZA_AC;
	else if(phaseNet.nophCcnt >= FAZA_FAULT)				phaseNet.phase = FAZA_AB;
//	else													phaseNet.phase = FAZA_FAULT;
	return phaseNet.phase;
}

void PhaseStateChange(void)
{
	switch(phaseNet.phase)
	{
	case FAZA_NO_PHASE:
		OVP.type = 0;
#ifdef _BUS_OUTPUT_UART
		if(debugMessage == MESSAGE_BUS)
		{
			Println(&huart1, "\nNo phases.");
		}
#endif
		break;

	case FAZA_ABC_UP:
		OVP.type = 1;
#ifdef _BUS_OUTPUT_UART
		if(debugMessage == MESSAGE_BUS)
		{
			Println(&huart1, "\nABC phase, UP.");
		}
#endif
		break;

	case FAZA_ABC_DOWN:
		OVP.type = 1;
#ifdef _BUS_OUTPUT_UART
		if(debugMessage == MESSAGE_BUS)
		{
			Println(&huart1, "\nABC phase, DOWN.");
		}
#endif
		break;

	case FAZA_A:
		OVP.type = 1;
#ifdef _BUS_OUTPUT_UART
		if(debugMessage == MESSAGE_BUS)
		{
			Println(&huart1, "\nA phase.");
		}
#endif
		break;

	case FAZA_B:
		OVP.type = 0;
#ifdef _BUS_OUTPUT_UART
		if(debugMessage == MESSAGE_BUS)
		{
			Println(&huart1, "\nB phase.");
		}
#endif
		break;

	case FAZA_C:
		OVP.type = 0;
#ifdef _BUS_OUTPUT_UART
		if(debugMessage == MESSAGE_BUS)
		{
			Println(&huart1, "\nC phase.");
		}
#endif
		break;

	case FAZA_AB:
		OVP.type = 1;
#ifdef _BUS_OUTPUT_UART
		if(debugMessage == MESSAGE_BUS)
		{
			Println(&huart1, "\nA, B phases.");
		}
#endif
		break;

	case FAZA_AC:
		OVP.type = 1;
#ifdef _BUS_OUTPUT_UART
		if(debugMessage == MESSAGE_BUS)
		{
			Println(&huart1, "\nA, C phases.");
		}
#endif
		break;

	case FAZA_BC:
		OVP.type = 0;
#ifdef _BUS_OUTPUT_UART
		if(debugMessage == MESSAGE_BUS)
		{
			Println(&huart1, "\nB, C phases.");
		}
#endif
		break;

	case FAZA_ABC_EQU:
		OVP.type = 1;
#ifdef _BUS_OUTPUT_UART
		if(debugMessage == MESSAGE_BUS)
		{
			Println(&huart1, "\nA, B, C phases EQUIVALENT.");
		}
#endif
		break;

	default:
#ifdef _BUS_OUTPUT_UART
		if(debugMessage == MESSAGE_BUS)
		{
			Println(&huart1, "\nTest phases fail.");
		}
#endif
		break;
	}
}

void ReadTemperature(void)
{
	if((ClockRAM.config.temperature <= ERROR_TEMP_LOW) || (ClockRAM.config.temperature >= ERROR_TEMP_HIGH))
	{	// error temperature sensor; DI2, avary 19, -30C, +110C
		tempSensorOk = FALSE;
		if(BIT_TEST(ClockRAM.config.di2_PP380, 0))
		{	// DI2, avary 17
			BIT_CLR(ClockRAM.config.di2_PP380, 0);
			BIT_SET(ClockRAM.config.dim2_PP380, 0);
		}
		if(BIT_TEST(ClockRAM.config.di2_PP380, 1))
		{	// DI2, avary 18
			BIT_CLR(ClockRAM.config.di2_PP380, 1);
			BIT_SET(ClockRAM.config.dim2_PP380, 1);
		}
		if((DevNVRAM.config.FaultControl & 0x0001) == 0x0001)
		{ // no wire sensor avary
			if(!BIT_TEST(ClockRAM.config.di2_PP380, 2))
			{
				BIT_SET(ClockRAM.config.di2_PP380, 2);
#ifdef _BUS_OUTPUT_UART
				if(debugMessage == MESSAGE_BUS)
				{
					Println(&huart1, "\nTemperature_sensor_error.");
				}
#endif
			}
		}
	}

	if((ClockRAM.config.temperature >= NO_ERROR_TEMP_LOW) && (ClockRAM.config.temperature <= NO_ERROR_TEMP_HIGH))
	{	// temperature sensor ok; DI2, avary 19, -25C, +100C
		tempSensorOk = TRUE;
		if(BIT_TEST(ClockRAM.config.di2_PP380, 2))
		{
			BIT_CLR(ClockRAM.config.di2_PP380, 2);
			BIT_SET(ClockRAM.config.dim2_PP380, 2);
#ifdef _BUS_OUTPUT_UART
			if(debugMessage == MESSAGE_BUS)
			{
				Println(&huart1, "\nTemperature_sensor_OK.");
			}
#endif
		}
	}

	if(tempSensorOk == FALSE)		return;

	if((DevNVRAM.config.FaultControl & 0x0002) == 0x0002)
	{ // no low temperature avary
		if((ClockRAM.config.temperature <= (int16_t)DevNVRAM.config.LowTemperature) && (!BIT_TEST(ClockRAM.config.di2_PP380, 0)))
		{	// avary low temperature set; DI2, avary 17
			BIT_SET(ClockRAM.config.di2_PP380, 0);
		}
	}

	if((ClockRAM.config.temperature >= ((int16_t)DevNVRAM.config.LowTemperature + DevNVRAM.config.LowHysteresys)) && BIT_TEST(ClockRAM.config.di2_PP380, 0))
	{	// low temperature up; DI2, avary 17
		BIT_CLR(ClockRAM.config.di2_PP380, 0);
		BIT_SET(ClockRAM.config.dim2_PP380, 0);
	}

	if((ClockRAM.config.temperature >= DevNVRAM.config.HighTemperature) && (!BIT_TEST(ClockRAM.config.di2_PP380, 1)))
	{	// avary high temperature set; DI2, avary 18
		BIT_SET(ClockRAM.config.di2_PP380, 1);
	}

	if((ClockRAM.config.temperature <= (DevNVRAM.config.HighTemperature - DevNVRAM.config.HighHysteresis)) && BIT_TEST(ClockRAM.config.di2_PP380, 1))
	{	// high temperature down; DI2, avary 18
		BIT_CLR(ClockRAM.config.di2_PP380, 1);
		BIT_SET(ClockRAM.config.dim2_PP380, 1);
	}
}

void InitInputPins(void)
{
	InitD(&D1, &DevNVRAM.config.DF1, 0);
	InitD(&D2, &DevNVRAM.config.DF2, 0);
	InitD(&D3, &DevNVRAM.config.DF3, 0);
	InitD(&D4, &DevNVRAM.config.DF4, 0);
	InitD(&D5, &DevNVRAM.config.DF5, 0);
	InitD(&D6, &DevNVRAM.config.DF6, 0);
	InitD(&D7, &DevNVRAM.config.DF7, 0);
	InitD(&D8, &DevNVRAM.config.DF8, 0);
	InitD(&D9, &DevNVRAM.config.DF9, 0);
	InitD(&D10, &DevNVRAM.config.DF10, 0);
	InitD(&D11, &DevNVRAM.config.DF11, 0);
	InitD(&D12, &DevNVRAM.config.DF12, 0);
	InitD(&D13, &DevNVRAM.config.DF13, 0);
	InitD(&D14, &DevNVRAM.config.DF14, 0);
	InitD(&D15, &DevNVRAM.config.DF15, 0);
	InitD(&D16, &DevNVRAM.config.DF16, 0);
	memset(phaseNet.select, FAZA_NO_PHASE, sizeof(phaseNet.select));
	phaseNet.nophAcnt = 0;
	phaseNet.nophBcnt = 0;
	phaseNet.nophCcnt = 0;
	phaseNet.phase = FAZA_FAULT;
	phaseNet.state = 0;
	OVP.type = 0;
	OVP.delay = 0;
	tempSensorOk = TRUE;
//	InputCmd.InputsState = 0;
}

void ReadInputPins(void)
{ // in Working();
	TestD(&D1, &DevNVRAM.config.DF1, 0, D1_GPIO_Port, D1_Pin);
	TestD(&D2, &DevNVRAM.config.DF2, 1, D2_GPIO_Port, D2_Pin);
	TestD(&D3, &DevNVRAM.config.DF3, 2, D3_GPIO_Port, D3_Pin);
	TestD(&D4, &DevNVRAM.config.DF4, 3, D4_GPIO_Port, D4_Pin);
	TestD(&D5, &DevNVRAM.config.DF5, 4, D5_GPIO_Port, D5_Pin);
	TestD(&D6, &DevNVRAM.config.DF6, 5, D6_GPIO_Port, D6_Pin);
	TestD(&D7, &DevNVRAM.config.DF7, 6, D7_GPIO_Port, D7_Pin);
//	TestD(&D8, &DevNVRAM.config.DF8, 7, D8_GPIO_Port, D8_Pin);			// D8-sensor door (ohrana)
	TestD(&D9, &DevNVRAM.config.DF9, 8, D9_GPIO_Port, D9_Pin);
	TestD(&D10, &DevNVRAM.config.DF10, 9, D10_GPIO_Port, D10_Pin);
	TestD(&D11, &DevNVRAM.config.DF11, 10, D11_GPIO_Port, D11_Pin);
	TestD(&D12, &DevNVRAM.config.DF12, 11, D12_GPIO_Port, D12_Pin);
	TestD(&D13, &DevNVRAM.config.DF13, 12, D13_GPIO_Port, D13_Pin);
	TestD(&D14, &DevNVRAM.config.DF14, 13, D14_GPIO_Port, D14_Pin);
	TestD(&D15, &DevNVRAM.config.DF15, 14, D15_GPIO_Port, D15_Pin);
	TestD(&D16, &DevNVRAM.config.DF16, 15, D16_GPIO_Port, D16_Pin);
	SetFlagValve();
	SetFlagSZO();
	WriteArchive();
}

void WriteArchive(void)
{
	uint32_t rtmp, mask;
	uint16_t datetmp;
	uint8_t  ri, re, event[32], wr_ee[ARCHIVE_MSG_LEN+2];	// +2 -> address

	inputNowMem = (ClockRAM.config.dim2_PP380 << 16);
	inputNowMem |= ClockRAM.config.dim1_PP380;
	if(inputOldMem != inputNowMem)
	{
		if(inputNowMem != 0)
		{
			BIT_SET(ClockRAM.config.status_PP380, 11);
		}
		inputOldMem = inputNowMem;
	}
	if(inputNowMem != 0)
	{
		BIT_SET(ClockRAM.config.status_PP380, 3);
	}
	if(inputNowMem == 0)
	{
		BIT_CLR(ClockRAM.config.status_PP380, 3);
	}
	inputNow = (ClockRAM.config.di2_PP380 << 16);
	inputNow |= ClockRAM.config.di1_PP380;
	if(inputOld != inputNow)
	{
		BIT_SET(ClockRAM.config.status_PP380, 11);
		rtmp = inputOld ^ inputNow;
		mask = 0x0001;
		re = 0;
		memset(event, 0, sizeof(event));
		for(ri=0; ri<32; ri++)
		{
			if(rtmp & mask)
			{
				if(inputNow & mask)		event[re] = (ri+1) | 0x80;
				else					event[re] = ri+1;
				re++;
			}
			mask = mask << 1;
		}
		while(re)
		{
			re--;
			datetmp = ClockRAM.config.date_PP380 & 0x7FFF;	// whitout zima/leto bit
			wr_ee[0] = datetmp >> 8;
			wr_ee[1] = datetmp;
			wr_ee[2] = ClockRAM.config.time_PP380 >> 8;
			wr_ee[3] = ClockRAM.config.time_PP380;
			wr_ee[4] = (int8_t)ClockRAM.config.temperature;
			wr_ee[5] = event[re];
			wr_ee[6] = (uint8_t)ClockRAM.config.u_battery;
			wr_ee[7] = (uint8_t)ClockRAM.config.u_input;

			HAL_I2C_Mem_Write(&hi2c1, MEM_ADDR, ClockRAM.config.eeAddress, I2C_MEMADD_SIZE_16BIT, wr_ee, ARCHIVE_MSG_LEN, TIMEOUT_I2C); //wr_ee, ARCHIVE_MSG_LEN
			HAL_Delay(TIMEOUT_I2C);
#ifdef _BUS_OUTPUT_UART
			if(debugMessage == MESSAGE_BUS)
			{
				memset(buff_i2c, 0, ARCHIVE_MSG_LEN);
				HAL_I2C_Mem_Read(&hi2c1, MEM_ADDR, ClockRAM.config.eeAddress, I2C_MEMADD_SIZE_16BIT, buff_i2c, ARCHIVE_MSG_LEN, TIMEOUT_I2C);
				if(memcmp(wr_ee, buff_i2c, ARCHIVE_MSG_LEN))
				{
					Println(&huart1, "\nWriting EEPROM fail!");
					Println(&huart1, "\nwrite:\n 0x");
					itoa(ClockRAM.config.eeAddress, buff, 16);
					Println(&huart1, buff);
					Println(&huart1, ": 0x");
					for(ri=0; ri<ARCHIVE_MSG_LEN; ri++)
					{
						itoa(wr_ee[ri], buff, 16);
						Println(&huart1, buff);
						Println(&huart1, ", 0x");
					}
					Println(&huart1, "\nread: 0x");
					for(ri=0; ri<ARCHIVE_MSG_LEN; ri++)
					{
						itoa(buff_i2c[ri], buff, 16);
						Println(&huart1, buff);
						Println(&huart1, ", 0x");
					}
				}
			}
#endif
			NextAddrEEPROM();
		}
		inputOld = inputNow;
	}
}

void SetFlagValve(void)
{
	inputDiNow = (ClockRAM.config.di2_PP380 << 16);
	inputDiNow |= ClockRAM.config.di1_PP380;
	inputDiNow &= (VALVE.mask1 << 16) | VALVE.mask0;
	if(inputDiNow != inputDiOld)
	{
		if(inputDiNow && (inputDiNow > inputDiOld))
		{
			flagRunVLV = VALVE_ON;
		}
		if(inputDiNow == 0)
		{
			flagRunVLV = VALVE_OFF;
		}
		inputDiOld = inputDiNow;
	}
}

void SetFlagSZO(void)
{
	inputDiNowSZO = (ClockRAM.config.di2_PP380 << 16);
	inputDiNowSZO |= ClockRAM.config.di1_PP380;
	inputDiNowSZO &= inputSZOmask;
	if(inputDiNowSZO != inputDiOldSZO)
	{
		if(inputDiNowSZO && (inputDiNowSZO > inputDiOldSZO))
		{
			flagDiSZO = 1;				// for activate SZO output
		}
		if(inputDiNowSZO == 0)
		{
			flagDiSZO = 1;				// for restore output settings
		}
		inputDiOldSZO = inputDiNowSZO;
	}
}

void InitOutputPins(void)
{
	InitRele1(MASK_INIT_OUTPUT);
	InitRele2(MASK_INIT_OUTPUT);
	InitRele3(MASK_INIT_OUTPUT);
	InitRele4(MASK_INIT_OUTPUT);
	InitRele5(MASK_INIT_OUTPUT);
	InitValve(MASK_INIT_OUTPUT);
//	OutputCmd.OutputState = 0;
}

void SetOutputPins(void)
{ // in Working();
	SetRele1();
	SetRele2();
	SetRele3();
	SetRele4();
	SetRele5();
	SetValve();
	RefreshOutputPins();
}

void RefreshOutputPins(void)
{
	if(HAL_GPIO_ReadPin(RELE1_GPIO_Port, RELE1_Pin))		BIT_SET(ClockRAM.config.output_switch_PP380, 0);
	else													BIT_CLR(ClockRAM.config.output_switch_PP380, 0);
	if(HAL_GPIO_ReadPin(RELE2_GPIO_Port, RELE2_Pin))		BIT_SET(ClockRAM.config.output_switch_PP380, 1);
	else													BIT_CLR(ClockRAM.config.output_switch_PP380, 1);
	if(HAL_GPIO_ReadPin(RELE3_GPIO_Port, RELE3_Pin))		BIT_SET(ClockRAM.config.output_switch_PP380, 2);
	else													BIT_CLR(ClockRAM.config.output_switch_PP380, 2);
	if(HAL_GPIO_ReadPin(RELE4_GPIO_Port, RELE4_Pin))		BIT_SET(ClockRAM.config.output_switch_PP380, 3);
	else													BIT_CLR(ClockRAM.config.output_switch_PP380, 3);
	if(HAL_GPIO_ReadPin(RELE5_GPIO_Port, RELE5_Pin))		BIT_SET(ClockRAM.config.output_switch_PP380, 4);
	else													BIT_CLR(ClockRAM.config.output_switch_PP380, 4);
	if(HAL_GPIO_ReadPin(VLV_GPIO_Port, VLV_Pin))			BIT_SET(ClockRAM.config.output_switch_PP380, 5);
	else													BIT_CLR(ClockRAM.config.output_switch_PP380, 5);
}

void InitOut(output_t *rel, outFlash_t *relF, uint16_t mask)
{ // bit5-Name, bit6-Type, bit7-Init, bit8-Scenary, bit9-Shablon, bit10-Mask,
	uint8_t refresh;

	refresh = 0;
	if((BIT_TEST(mask, 6)) || (BIT_TEST(mask, 7)) || (BIT_TEST(mask, 9)))
	{
		relF->CfgTypeInit = OutputCmd.OutputType;
		refresh++;
	}
	if(BIT_TEST(mask, 5))
	{
		SetOutputName(relF->Name);
		refresh++;
	}
	if(BIT_TEST(mask, 10))
	{
		relF->Mask_16_31 = OutputCmd.OutputMask16_31;
		relF->Mask_0_15 = OutputCmd.OutputMask0_15;
		refresh++;
	}
	if(refresh)		RefreshFlashData();
	rel->type = relF->CfgTypeInit & 0x0003;				// 2bit(0,1)-type out, 0-NC, 1-NO
	rel->init = (relF->CfgTypeInit >> 2) & 0x0007;		// 3bit(2,3,4)-init, 0-mask, 1-mask_user, 2-manual, 4-remote
//    3bit(5,6,7)-scenary, not used, always - 0
	rel->shablon = (relF->CfgTypeInit >> 8) & 0x0007;	// 3bit(8,9,10)-shablon for mask, 0-nasos, 1-mh, 2-szo, 3-klapan, 4-alarm
	rel->mask0 = relF->Mask_0_15;
	rel->mask1 = relF->Mask_16_31;
	if(rel->shablon == OUT_SHBL_SZO)
	{
		inputSZOmask = (rel->mask1) << 16;
		inputSZOmask |= rel->mask0;
	}
}

void InitRele1(uint16_t mask)
{ // bit5-Name, bit6-Type, bit7-Init, bit8-Scenary, bit9-Shablon, bit10-Mask,
	InitOut(&RELE1, &DevNVRAM.config.ReleF1, mask);
	if(RELE1.type == OUTTYPE_NO)
	{
		HAL_GPIO_WritePin(RELE1_GPIO_Port, RELE1_Pin, GPIO_PIN_RESET);
	}
	if(RELE1.type == OUTTYPE_NC)
	{
		HAL_GPIO_WritePin(RELE1_GPIO_Port, RELE1_Pin, GPIO_PIN_SET);
	}
	SetRele1();
}

void GetInitRele1(void)
{
	OutputCmd.OutputType = DevNVRAM.config.ReleF1.CfgTypeInit;
	GetOutputName(DevNVRAM.config.ReleF1.Name);
	OutputCmd.OutputMask16_31 = DevNVRAM.config.ReleF1.Mask_16_31;
	OutputCmd.OutputMask0_15 = DevNVRAM.config.ReleF1.Mask_0_15;
}

void InitRele2(uint16_t mask)
{ // bit5-Name, bit6-Type, bit7-Init, bit8-Scenary, bit9-Shablon, bit10-Mask,
	InitOut(&RELE2, &DevNVRAM.config.ReleF2, mask);
	if(RELE2.type == OUTTYPE_NO)
	{
		HAL_GPIO_WritePin(RELE2_GPIO_Port, RELE2_Pin, GPIO_PIN_RESET);
	}
	if(RELE2.type == OUTTYPE_NC)
	{
		HAL_GPIO_WritePin(RELE2_GPIO_Port, RELE2_Pin, GPIO_PIN_SET);
	}
	SetRele2();
}

void GetInitRele2(void)
{
	OutputCmd.OutputType = DevNVRAM.config.ReleF2.CfgTypeInit;
	GetOutputName(DevNVRAM.config.ReleF2.Name);
	OutputCmd.OutputMask16_31 = DevNVRAM.config.ReleF2.Mask_16_31;
	OutputCmd.OutputMask0_15 = DevNVRAM.config.ReleF2.Mask_0_15;
}

void InitRele3(uint16_t mask)
{ // bit5-Name, bit6-Type, bit7-Init, bit8-Scenary, bit9-Shablon, bit10-Mask,
	InitOut(&RELE3, &DevNVRAM.config.ReleF3, mask);
	if(RELE3.type == OUTTYPE_NO)
	{
		HAL_GPIO_WritePin(RELE3_GPIO_Port, RELE3_Pin, GPIO_PIN_RESET);
	}
	if(RELE3.type == OUTTYPE_NC)
	{
		HAL_GPIO_WritePin(RELE3_GPIO_Port, RELE3_Pin, GPIO_PIN_SET);
	}
	SetRele3();
}

void GetInitRele3(void)
{
	OutputCmd.OutputType = DevNVRAM.config.ReleF3.CfgTypeInit;
	GetOutputName(DevNVRAM.config.ReleF3.Name);
	OutputCmd.OutputMask16_31 = DevNVRAM.config.ReleF3.Mask_16_31;
	OutputCmd.OutputMask0_15 = DevNVRAM.config.ReleF3.Mask_0_15;
}

void InitRele4(uint16_t mask)
{ // bit5-Name, bit6-Type, bit7-Init, bit8-Scenary, bit9-Shablon, bit10-Mask,
	InitOut(&RELE4, &DevNVRAM.config.ReleF4, mask);
	if(RELE4.type == OUTTYPE_NO)
	{
		HAL_GPIO_WritePin(RELE4_GPIO_Port, RELE4_Pin, GPIO_PIN_RESET);
	}
	if(RELE4.type == OUTTYPE_NC)
	{
		HAL_GPIO_WritePin(RELE4_GPIO_Port, RELE4_Pin, GPIO_PIN_SET);
	}
	SetRele4();
}

void GetInitRele4(void)
{
	OutputCmd.OutputType = DevNVRAM.config.ReleF4.CfgTypeInit;
	GetOutputName(DevNVRAM.config.ReleF4.Name);
	OutputCmd.OutputMask16_31 = DevNVRAM.config.ReleF4.Mask_16_31;
	OutputCmd.OutputMask0_15 = DevNVRAM.config.ReleF4.Mask_0_15;
}

void InitRele5(uint16_t mask)
{ // bit5-Name, bit6-Type, bit7-Init, bit8-Scenary, bit9-Shablon, bit10-Mask,
	InitOut(&RELE5, &DevNVRAM.config.ReleF5, mask);
	if(RELE5.type == OUTTYPE_NO)
	{
		HAL_GPIO_WritePin(RELE5_GPIO_Port, RELE5_Pin, GPIO_PIN_RESET);
	}
	if(RELE5.type == OUTTYPE_NC)
	{
		HAL_GPIO_WritePin(RELE5_GPIO_Port, RELE5_Pin, GPIO_PIN_SET);
	}
	SetRele5();
}

void GetInitRele5(void)
{
	OutputCmd.OutputType = DevNVRAM.config.ReleF5.CfgTypeInit;
	GetOutputName(DevNVRAM.config.ReleF5.Name);
	OutputCmd.OutputMask16_31 = DevNVRAM.config.ReleF5.Mask_16_31;
	OutputCmd.OutputMask0_15 = DevNVRAM.config.ReleF5.Mask_0_15;
}

void InitValve(uint16_t mask)
{ // bit5-Name, bit6-Type, bit7-Init, bit8-Scenary, bit9-Shablon, bit10-Mask,
	InitOut(&VALVE, &DevNVRAM.config.ValveF, mask);
	VALVE.state = VALVE_STOP;
	VALVE.counter = 0;
	if(VALVE.type == OUTTYPE_NO)
	{
		HAL_GPIO_WritePin(VLV_GPIO_Port, VLV_Pin, GPIO_PIN_SET);
		BIT_CLR(ClockRAM.config.output_switch_PP380, 11);		// off klapan pin
	}
	if(VALVE.type == OUTTYPE_NC)
	{
		HAL_GPIO_WritePin(VLV_GPIO_Port, VLV_Pin, GPIO_PIN_SET);
	}
}

void GetInitValve(void)
{
	OutputCmd.OutputType = DevNVRAM.config.ValveF.CfgTypeInit;
	GetOutputName(DevNVRAM.config.ValveF.Name);
	OutputCmd.OutputMask16_31 = DevNVRAM.config.ValveF.Mask_16_31;
	OutputCmd.OutputMask0_15 = DevNVRAM.config.ValveF.Mask_0_15;
}

void SetRele1(void)
{
	if(BIT_TEST(ClockRAM.config.output_switch_PP380, 6) == 0)
	{
		HAL_GPIO_WritePin(RELE1_GPIO_Port, RELE1_Pin, GPIO_PIN_RESET);
		return;
	}
	switch(RELE1.init)
	{
	case OUT_OFF_SZO:
		if(RELE1.type == OUTTYPE_NO)	HAL_GPIO_WritePin(RELE1_GPIO_Port, RELE1_Pin, GPIO_PIN_RESET);
		if(RELE1.type == OUTTYPE_NC)	HAL_GPIO_WritePin(RELE1_GPIO_Port, RELE1_Pin, GPIO_PIN_SET);
		break;

	case OUT_CNTR_REMOTE:
	case OUT_CNTR_MANUAL:
		if(BIT_TEST(ClockRAM.config.output_switch_PP380, 6))
		{
			HAL_GPIO_WritePin(RELE1_GPIO_Port, RELE1_Pin, GPIO_PIN_SET);
		}
		break;

	case OUT_CNTR_MASK:
	case OUT_CNTR_MASK_USER:
		if((ClockRAM.config.di1_PP380 & RELE1.mask0) != 0 || (ClockRAM.config.di2_PP380 & RELE1.mask1) != 0)
		{
			if(RELE1.type == OUTTYPE_NO)	HAL_GPIO_WritePin(RELE1_GPIO_Port, RELE1_Pin, GPIO_PIN_SET);
			if(RELE1.type == OUTTYPE_NC)	HAL_GPIO_WritePin(RELE1_GPIO_Port, RELE1_Pin, GPIO_PIN_RESET);
		}
		if((ClockRAM.config.di1_PP380 & RELE1.mask0) == 0 && (ClockRAM.config.di2_PP380 & RELE1.mask1) == 0)
		{
			if(RELE1.type == OUTTYPE_NO)	HAL_GPIO_WritePin(RELE1_GPIO_Port, RELE1_Pin, GPIO_PIN_RESET);
			if(RELE1.type == OUTTYPE_NC)	HAL_GPIO_WritePin(RELE1_GPIO_Port, RELE1_Pin, GPIO_PIN_SET);
		}
		break;

	default:
		break;
	}
}

void SetRele2(void)
{
	if(BIT_TEST(ClockRAM.config.output_switch_PP380, 7) == 0)
	{
		HAL_GPIO_WritePin(RELE2_GPIO_Port, RELE2_Pin, GPIO_PIN_RESET);
		return;
	}
	switch(RELE2.init)
	{
	case OUT_OFF_SZO:
		if(RELE2.type == OUTTYPE_NO)	HAL_GPIO_WritePin(RELE2_GPIO_Port, RELE2_Pin, GPIO_PIN_RESET);
		if(RELE2.type == OUTTYPE_NC)	HAL_GPIO_WritePin(RELE2_GPIO_Port, RELE2_Pin, GPIO_PIN_SET);
		break;

	case OUT_CNTR_REMOTE:
	case OUT_CNTR_MANUAL:
		if(BIT_TEST(ClockRAM.config.output_switch_PP380, 7))
		{
			HAL_GPIO_WritePin(RELE2_GPIO_Port, RELE2_Pin, GPIO_PIN_SET);
		}
		break;

	case OUT_CNTR_MASK:
	case OUT_CNTR_MASK_USER:
		if((ClockRAM.config.di1_PP380 & RELE2.mask0) != 0 || (ClockRAM.config.di2_PP380 & RELE2.mask1) != 0)
		{
			if(RELE2.type == OUTTYPE_NO)	HAL_GPIO_WritePin(RELE2_GPIO_Port, RELE2_Pin, GPIO_PIN_SET);
			if(RELE2.type == OUTTYPE_NC)	HAL_GPIO_WritePin(RELE2_GPIO_Port, RELE2_Pin, GPIO_PIN_RESET);
		}
		if((ClockRAM.config.di1_PP380 & RELE2.mask0) == 0 && (ClockRAM.config.di2_PP380 & RELE2.mask1) == 0)
		{
			if(RELE2.type == OUTTYPE_NO)	HAL_GPIO_WritePin(RELE2_GPIO_Port, RELE2_Pin, GPIO_PIN_RESET);
			if(RELE2.type == OUTTYPE_NC)	HAL_GPIO_WritePin(RELE2_GPIO_Port, RELE2_Pin, GPIO_PIN_SET);
		}
		break;

		default:
			break;
	}
}

void SetRele3(void)
{
	if(BIT_TEST(ClockRAM.config.output_switch_PP380, 8) == 0)
	{
		HAL_GPIO_WritePin(RELE3_GPIO_Port, RELE3_Pin, GPIO_PIN_RESET);
		return;
	}
	switch(RELE3.init)
	{
	case OUT_OFF_SZO:
		if(RELE3.type == OUTTYPE_NO)	HAL_GPIO_WritePin(RELE3_GPIO_Port, RELE3_Pin, GPIO_PIN_RESET);
		if(RELE3.type == OUTTYPE_NC)	HAL_GPIO_WritePin(RELE3_GPIO_Port, RELE3_Pin, GPIO_PIN_SET);
		break;

	case OUT_CNTR_REMOTE:
	case OUT_CNTR_MANUAL:
		if(BIT_TEST(ClockRAM.config.output_switch_PP380, 8))
		{
			HAL_GPIO_WritePin(RELE3_GPIO_Port, RELE3_Pin, GPIO_PIN_SET);
		}
		break;

	case OUT_CNTR_MASK:
	case OUT_CNTR_MASK_USER:
		if((ClockRAM.config.di1_PP380 & RELE3.mask0) != 0 || (ClockRAM.config.di2_PP380 & RELE3.mask1) != 0)
		{
			if(RELE3.type == OUTTYPE_NO)	HAL_GPIO_WritePin(RELE3_GPIO_Port, RELE3_Pin, GPIO_PIN_SET);
			if(RELE3.type == OUTTYPE_NC)	HAL_GPIO_WritePin(RELE3_GPIO_Port, RELE3_Pin, GPIO_PIN_RESET);
		}
		if((ClockRAM.config.di1_PP380 & RELE3.mask0) == 0 && (ClockRAM.config.di2_PP380 & RELE3.mask1) == 0)
		{
			if(RELE3.type == OUTTYPE_NO)	HAL_GPIO_WritePin(RELE3_GPIO_Port, RELE3_Pin, GPIO_PIN_RESET);
			if(RELE3.type == OUTTYPE_NC)	HAL_GPIO_WritePin(RELE3_GPIO_Port, RELE3_Pin, GPIO_PIN_SET);
		}
		break;

	default:
		break;
	}
}

void SetRele4(void)
{
	if(BIT_TEST(ClockRAM.config.output_switch_PP380, 9) == 0)
	{
		HAL_GPIO_WritePin(RELE4_GPIO_Port, RELE4_Pin, GPIO_PIN_RESET);
		return;
	}
	switch(RELE4.init)
	{
	case OUT_OFF_SZO:
		if(RELE4.type == OUTTYPE_NO)	HAL_GPIO_WritePin(RELE4_GPIO_Port, RELE4_Pin, GPIO_PIN_RESET);
		if(RELE4.type == OUTTYPE_NC)	HAL_GPIO_WritePin(RELE4_GPIO_Port, RELE4_Pin, GPIO_PIN_SET);
		break;

	case OUT_CNTR_REMOTE:
	case OUT_CNTR_MANUAL:
		if(BIT_TEST(ClockRAM.config.output_switch_PP380, 9))
		{
			HAL_GPIO_WritePin(RELE4_GPIO_Port, RELE4_Pin, GPIO_PIN_SET);
		}
		break;

	case OUT_CNTR_MASK:
	case OUT_CNTR_MASK_USER:
		if((ClockRAM.config.di1_PP380 & RELE4.mask0) != 0 || (ClockRAM.config.di2_PP380 & RELE4.mask1) != 0)
		{
			if(RELE4.type == OUTTYPE_NO)	HAL_GPIO_WritePin(RELE4_GPIO_Port, RELE4_Pin, GPIO_PIN_SET);
			if(RELE4.type == OUTTYPE_NC)	HAL_GPIO_WritePin(RELE4_GPIO_Port, RELE4_Pin, GPIO_PIN_RESET);
		}
		if((ClockRAM.config.di1_PP380 & RELE4.mask0) == 0 && (ClockRAM.config.di2_PP380 & RELE4.mask1) == 0)
		{
			if(RELE4.type == OUTTYPE_NO)	HAL_GPIO_WritePin(RELE4_GPIO_Port, RELE4_Pin, GPIO_PIN_RESET);
			if(RELE4.type == OUTTYPE_NC)	HAL_GPIO_WritePin(RELE4_GPIO_Port, RELE4_Pin, GPIO_PIN_SET);
		}
		break;

	default:
		break;
	}
}

void SetRele5(void)
{
	if(BIT_TEST(ClockRAM.config.output_switch_PP380, 10) == 0)
	{
		HAL_GPIO_WritePin(RELE5_GPIO_Port, RELE5_Pin, GPIO_PIN_RESET);
		return;
	}
	switch(RELE5.init)
	{
	case OUT_OFF_SZO:
		if(RELE5.type == OUTTYPE_NO)	HAL_GPIO_WritePin(RELE5_GPIO_Port, RELE5_Pin, GPIO_PIN_RESET);
		if(RELE5.type == OUTTYPE_NC)	HAL_GPIO_WritePin(RELE5_GPIO_Port, RELE5_Pin, GPIO_PIN_SET);
		break;

	case OUT_CNTR_REMOTE:
	case OUT_CNTR_MANUAL:
		if(BIT_TEST(ClockRAM.config.output_switch_PP380, 10))
		{
			HAL_GPIO_WritePin(RELE5_GPIO_Port, RELE5_Pin, GPIO_PIN_SET);
		}
		break;

	case OUT_CNTR_MASK:
	case OUT_CNTR_MASK_USER:
		if((ClockRAM.config.di1_PP380 & RELE5.mask0) != 0 || (ClockRAM.config.di2_PP380 & RELE5.mask1) != 0)
		{
			if(RELE5.type == OUTTYPE_NO)	HAL_GPIO_WritePin(RELE5_GPIO_Port, RELE5_Pin, GPIO_PIN_SET);
			if(RELE5.type == OUTTYPE_NC)	HAL_GPIO_WritePin(RELE5_GPIO_Port, RELE5_Pin, GPIO_PIN_RESET);
		}
		if((ClockRAM.config.di1_PP380 & RELE5.mask0) == 0 && (ClockRAM.config.di2_PP380 & RELE5.mask1) == 0)
		{
			if(RELE5.type == OUTTYPE_NO)	HAL_GPIO_WritePin(RELE5_GPIO_Port, RELE5_Pin, GPIO_PIN_RESET);
			if(RELE5.type == OUTTYPE_NC)	HAL_GPIO_WritePin(RELE5_GPIO_Port, RELE5_Pin, GPIO_PIN_SET);
		}
		break;

	default:
		break;
	}
}

void SetValve(void)
{ // only mask control! OUT_CNTR_MASK OUT_CNTR_MASK_USER
	if(VALVE.type == OUTTYPE_NO && VALVE.state == VALVE_STOP)
	{
		if(flagRunVLV == VALVE_ON)
		{
			VALVE.state = VALVE_START;	// HAL_GPIO_WritePin(VLV_GPIO_Port, VLV_Pin, GPIO_PIN_SET);
			flagRunVLV = 0;
		}
		if(flagRunVLV == VALVE_OFF)
		{	// HAL_GPIO_WritePin(VLV_GPIO_Port, VLV_Pin, GPIO_PIN_RESET);
			flagRunVLV = 0;
		}
	}

	if(VALVE.type == OUTTYPE_NC)
	{
		if(flagRunVLV == VALVE_ON || BIT_TEST(ClockRAM.config.output_switch_PP380, 11))
		{
			HAL_GPIO_WritePin(VLV_GPIO_Port, VLV_Pin, GPIO_PIN_RESET);
			flagRunVLV = 0;
		}
		if((flagRunVLV == VALVE_OFF) && (BIT_TEST(ClockRAM.config.output_switch_PP380, 11) == 0))
		{
			HAL_GPIO_WritePin(VLV_GPIO_Port, VLV_Pin, GPIO_PIN_SET);
			flagRunVLV = 0;
		}
	}
}

void RunValve(void)
{ // working  process, only PINTYPE_NO

	switch(VALVE.state)
	{
	case VALVE_START:				// 1, on pin, set delay on
		HAL_GPIO_WritePin(VLV_GPIO_Port, VLV_Pin, GPIO_PIN_RESET);
		VALVE.counter = VALVE_DLY_ON;
		VALVE.state++;
		break;

	case VALVE_START+1:				// 2, off pin, set delay off
		if(VALVE.counter == 0)
		{
			HAL_GPIO_WritePin(VLV_GPIO_Port, VLV_Pin, GPIO_PIN_SET);
			VALVE.counter = VALVE_DLY_OFF;
			VALVE.state++;
		}
		break;

	case VALVE_START+2:				// 3, on pin, set delay on
		if(VALVE.counter == 0)
		{
			HAL_GPIO_WritePin(VLV_GPIO_Port, VLV_Pin, GPIO_PIN_RESET);
			VALVE.counter = VALVE_DLY_ON;
			VALVE.state++;
		}
		break;

	case VALVE_START+3:				// 4, off pin, set delay off
		if(VALVE.counter == 0)
		{
			HAL_GPIO_WritePin(VLV_GPIO_Port, VLV_Pin, GPIO_PIN_SET);
			VALVE.counter = VALVE_DLY_OFF;
			VALVE.state++;
		}
		break;

	case VALVE_START+4:				// 5, on pin, set delay on
		if(VALVE.counter == 0)
		{
			HAL_GPIO_WritePin(VLV_GPIO_Port, VLV_Pin, GPIO_PIN_RESET);
			VALVE.counter = VALVE_DLY_ON;
			VALVE.state++;
		}
		break;

	case VALVE_START+5:				// 6, off pin, set delay off
		if(VALVE.counter == 0)
		{
			HAL_GPIO_WritePin(VLV_GPIO_Port, VLV_Pin, GPIO_PIN_SET);
			VALVE.counter = VALVE_DLY_OFF;
			VALVE.state++;
		}
		break;

	case VALVE_START+6:				// 7, off pin, end running
		if(VALVE.counter == 0)
		{
			HAL_GPIO_WritePin(VLV_GPIO_Port, VLV_Pin, GPIO_PIN_SET);
			BIT_CLR(ClockRAM.config.output_switch_PP380, 11);
			VALVE.state = VALVE_STOP;
		}
		break;

	case VALVE_STOP:
	default:
		break;
	}
}

void DelayCounting(void)
{ // 1 sec
	if(D1.delay)			D1.delay--;
	if(D2.delay)			D2.delay--;
	if(D3.delay)			D3.delay--;
	if(D4.delay)			D4.delay--;
	if(D5.delay)			D5.delay--;
	if(D6.delay)			D6.delay--;
	if(D7.delay)			D7.delay--;
	if(D8.delay)			D8.delay--;
	if(D9.delay)			D9.delay--;
	if(D10.delay)			D10.delay--;
	if(D11.delay)			D11.delay--;
	if(D12.delay)			D12.delay--;
	if(D13.delay)			D13.delay--;
	if(D14.delay)			D14.delay--;
	if(D15.delay)			D15.delay--;
	if(D16.delay)			D16.delay--;
//	if(OVP.delay)			OVP.delay--;
	if(phaseNet.delay)		phaseNet.delay--;
	if(UART_1.cntTestLine)	UART_1.cntTestLine--;
	if(UART_2.cntTestLine)	UART_2.cntTestLine--;
	if(UART_3.cntTestLine)	UART_3.cntTestLine--;
	if(countTestDelay)		countTestDelay--;
	if(countTestDelay == 1)
	{ // reset test bit of status register
		BIT_CLR(ClockRAM.config.status_PP380, 0);
		countTestDelay = 0;
	}
	if(countSettingsDelay)	countSettingsDelay--;
}

void ParseInput(config_uart_t *uart)
{
	uint32_t cb, cv;
	uint16_t ci, cval;
	uint16_t cmd17addr, cmd17len;
	uint8_t  errcode;

	if(uart->cntReceive < 4)
	{
		uart->cntReceive = 0;
		return;
	}

	errcode = 0;
#ifdef _BUS_OUTPUT_UART
	if(debugMessage == MESSAGE_BUS)
	{
		len_bf = uart->cntReceive;
		if(debugMessage == MESSAGE_BUS)
		{
			memcpy(input_bf, uart->input_buff, len_bf);
		}
	}
#endif
	ci = uart->cntReceive;
	cv = uart->input_buff[ci-1];
	cv = cv << 8;
	cv |= uart->input_buff[ci-2];
	cb = CalculateCRC16(uart->input_buff, ci-2);
	if(cv != cb)
	{
#ifdef _BUS_OUTPUT_UART
		if(debugMessage == MESSAGE_BUS)
		{
			cval = cv >> 8;
			cv = cv << 8;
			cval |= cv;
			itoa(cval, buff, 16);
			Println(&huart1, "\nInput check sum cv: 0x");
			Println(&huart1, buff);
			cval = cb >> 8;
			cb = cb << 8;
			cval |= cb;
			itoa(cval, buff, 16);
			Println(&huart1, "\nCalculate check sum: 0x");
			Println(&huart1, buff);

			itoa(uart->cntReceive, buff, 10);
			Println(&huart1, "\ndata len: ");
			Println(&huart1, buff);

			Println(&huart1, "\nInput buff: ");
			for(cval=0; cval<len_bf; cval++)
			{
				itoa(input_bf[cval], buff, 16);
				if(strlen(buff) == 1)	Println(&huart1, "0");
				Println(&huart1, buff);
				Println(&huart1, " ");
			}
		}
#endif
		return;
	}
	uart->cntTestLine = TEST_LINE_TIME;		// reload counter for test line
	trueAddress = 0;		// false
	if((uart->input_buff[0] == myAddress) && (uart->num == 1))
	{
		trueAddress = 1;	// true, out port, USB
	}
	if((uart->input_buff[0] == myAddress) && (uart->num == 2))
	{
		trueAddress = 1;	// true, out port
	}
	if((uart->input_buff[0] == 1) && (uart->num == 3))
	{
		trueAddress = 1;	// true, PI382 port
	}
	if(uart->input_buff[0] == 0)
	{
		trueAddress = 1;	// true
	}
	if(trueAddress)
	{
		currAddress = uart->input_buff[0];
		switch(uart->input_buff[1])
		{
		case READ_HOLD_REG:			// cmd	0x03 read registers
		case READ_IN_REG:			// cmd	0x04 read registers
//			Println(&huart1, "\ncmd 0x04 send.");
			uart->startReg = (uart->input_buff[2]) << 8;
			uart->startReg |= uart->input_buff[3];
			uart->lenReg = (uart->input_buff[4]) << 8;
			uart->lenReg |= uart->input_buff[5];
			if((uart->startReg + uart->lenReg) > REGISTERS)
			{
#ifdef _BUS_OUTPUT_UART
				if(debugMessage == MESSAGE_BUS)
				{
					Println(&huart1, "\nIncorrect read command (4).");
				}
#endif
				return;
			}
			UARTsend(uart, ReadRegisters(uart));
			break;

		case WRITE_ONE_REG:			// cmd	0x06
//			Println(&huart1, "\ncmd 0x06 send.");
			uart->startReg = (uart->input_buff[2]) << 8;
			uart->startReg |= uart->input_buff[3];
			uart->lenReg = (uart->input_buff[4]) << 8;		// value for write
			uart->lenReg |= uart->input_buff[5];
			errcode = WriteRegister(uart->startReg, uart->lenReg, uart->num);
			if(errcode == 0)
			{
				uart->output_buff[0] = uart->input_buff[0];
				uart->output_buff[1] = uart->input_buff[1];
				uart->output_buff[2] = uart->input_buff[2];			// bytes to answer
				uart->output_buff[3] = uart->input_buff[3];
				uart->output_buff[4] = uart->input_buff[4];
				uart->output_buff[5] = uart->input_buff[5];
				CalculateCRC16(uart->output_buff, 6);
				UARTsend(uart, 8);
				if(uart->startReg > 12)		RefreshFlashData();		// write data to flash memory
			}
			else
			{
				uart->output_buff[0] = uart->input_buff[0];
				uart->output_buff[1] = WRITE_ONE_REG | 0x80;
				uart->output_buff[2] = errcode;
				CalculateCRC16(uart->output_buff, 3);
				UARTsend(uart, 5);
			}
			break;

		case LOOP_TEST:				// cmd 	0x08
//			Println(&huart1, "\ncmd 0x08 send.");
			for(ci=0; ci<uart->cntReceive; ci++)
			{
				uart->output_buff[ci] = uart->input_buff[ci];
			}
			UARTsend(uart, ci);
			break;

		case WRITE_MULTI_REG:		// cmd	0x10
//			Println(&huart1, "\ncmd 0x10 send.");
			uart->startReg = (uart->input_buff[2]) << 8;
			uart->startReg |= uart->input_buff[3];
			uart->lenReg = (uart->input_buff[4]) << 8;		// length words for write
			uart->lenReg |= uart->input_buff[5];
//			cb = uart->input_buff[6];						// length bytes
			if((uart->startReg + uart->lenReg) > REGISTERS)
			{
#ifdef _BUS_OUTPUT_UART
				if(debugMessage == MESSAGE_BUS)
				{
					Println(&huart1, "\nIncorrect write command.");
				}
#endif
				return;
			}
			cb = 7;
			for(ci=0; ci<uart->lenReg; ci++)
			{
				cval = (uart->input_buff[cb++]) << 8;
				cval |= uart->input_buff[cb++];
				errcode = WriteRegister(uart->startReg+ci, cval, uart->num);
				if((ci << 1) > uart->input_buff[6])		break;
			}
			if(errcode == 0)
			{
				uart->output_buff[0] = uart->input_buff[0];
				uart->output_buff[1] = uart->input_buff[1];
				uart->output_buff[2] = (uart->startReg) >> 8;
				uart->output_buff[3] = uart->startReg;
				uart->output_buff[4] = ci >> 8;
				uart->output_buff[5] = ci;
				CalculateCRC16(uart->output_buff, 6);
				UARTsend(uart, 8);
				RefreshFlashData();						// write data to flash memory
			}
			else
			{
				uart->output_buff[0] = uart->input_buff[0];
				uart->output_buff[1] = uart->input_buff[1] | 0x80;
				uart->output_buff[2] = errcode;
				CalculateCRC16(uart->output_buff, 3);
				UARTsend(uart, 5);
			}
			break;

		case REPORT_ID:				// cmd	0x11
			GetReportId(uart);
			break;

		case READ_WRITE:			// cmd 0x17
//			Println(&huart1, "\ncmd 0x17 send.");
#ifdef _BUS_OUTPUT_UART
			if(debugMessage == MESSAGE_BUS)
			{
				Println(&huart1, "\ninput cmd: ");
				for(ci=0; ci<(uart->cntReceive); ci++)
				{
					cval = uart->input_buff[ci];
					itoa(cval, buff, 16);
					if(strlen(buff) < 2)	Println(&huart1, "0");
					Println(&huart1, buff);
					Println(&huart1, " ");
				}
			}
#endif
			uart->startReg = (uart->input_buff[2]) << 8;	// addr for read
			uart->startReg |= uart->input_buff[3];
			uart->lenReg = (uart->input_buff[4]) << 8;		// length words for read
			uart->lenReg |= uart->input_buff[5];
			cmd17addr = (uart->input_buff[6]) << 8;			// addr for write
			cmd17addr |= uart->input_buff[7];
			cmd17len = (uart->input_buff[8]) << 8;			// length words for write
			cmd17len |= uart->input_buff[9];
//			cb = uart->input_buff[10];						// length bytes	for write
			if((cmd17addr + cmd17len) > REGISTERS)
			{
#ifdef _BUS_OUTPUT_UART
				if(debugMessage == MESSAGE_BUS)
				{
					Println(&huart1, "\nIncorrect read/write command.");
				}
#endif
				return;
			}
			cb = 11;
			for(ci=0; ci<cmd17len; ci++)
			{
				cval = (uart->input_buff[cb++]) << 8;
				cval |= uart->input_buff[cb++];
				errcode = WriteRegister(cmd17addr+ci, cval, uart->num);
				if((ci << 1) > uart->input_buff[10])		break;
			}
			if((uart->startReg + uart->lenReg) > REGISTERS)
			{
#ifdef _BUS_OUTPUT_UART
				if(debugMessage == MESSAGE_BUS)
				{
					Println(&huart1, "\nIncorrect read/write command (17).");
				}
#endif
				return;
			}
#ifdef _BUS_OUTPUT_UART
			UARTsend(uart, len_bf=ReadRegisters(uart));
#else
			UARTsend(uart, ReadRegisters(uart));
#endif
			RefreshFlashData();		// write data to flash memory
#ifdef _BUS_OUTPUT_UART
			if(debugMessage == MESSAGE_BUS)
			{
				Println(&huart1, "\nOutput buff: ");
				for(cval=0; cval<len_bf; cval++)
				{
					itoa(uart->output_buff[cval], buff, 16);
					if(strlen(buff) == 1)	Println(&huart1, "0");
					Println(&huart1, buff);
					Println(&huart1, " ");
				}
			}
#endif
			break;
//////////////// Zima - Leto command
		case TABLE_ZIMA_LETO_READ:		// cmd 0xF0
			Println(&huart1, "\nTable for change time (zima-leto):");
			for(ci=0; ci<ZIMALETO_TABLE_SIZE; ci++)
			{
				cb = TableChangeTimeZimaLeto[ci];
				if(cb != 0xFFFFFFFF)
				{
					itoa(ci, buff, 10);
					Println(&huart1, "\n");
					Println(&huart1, buff);
					Println(&huart1, ": ");
					itoa((cb >> 24), buff, 16);
					Println(&huart1, buff);
					Println(&huart1, "/");
					itoa(((cb >> 16) & 0xFF), buff, 16);
					Println(&huart1, buff);
					Println(&huart1, "/20");
					itoa(((cb >> 8) & 0xFF), buff, 16);
					if(strlen(buff) < 2)	Println(&huart1, "0");
					Println(&huart1, buff);
				}
			}
			break;

		case TABLE_ZIMA_LETO_DEL_LINE:	// cmd 0xF2
			ci = (uart->input_buff[2]) << 8;	// cmd param 1
			ci |= uart->input_buff[3];
			if(ci < ZIMALETO_TABLE_SIZE)
			{
				TableChangeTimeZimaLeto[ci] = 0xFFFFFFFF;
				itoa(ci, buff, 10);
				Println(&huart1, "\nDelete line ");
				Println(&huart1, buff);
			}
			else
			{
				Println(&huart1, "\nIndex line out of range.");
			}
			break;

		case TABLE_ZIMA_LETO_ADD_LINE:	// cmd 0xF4
			if(uart->cntReceive < 10)
			{
				Println(&huart1, "\nNo data for write.");
			}
			else
			{
				cb = (uart->input_buff[3] << 24) | (uart->input_buff[5] << 16) | (uart->input_buff[7] << 8);
				if(uart->input_buff[5] < 6)		cb |= 0x02;
				else							cb |= 0x03;
				for(ci=0; ci<ZIMALETO_TABLE_SIZE; ci++)
				{
					if(TableChangeTimeZimaLeto[ci] == cb)
					{
						ci = ZIMALETO_TABLE_SIZE;
						Println(&huart1, "\nDate already exist.");
					}
					if(TableChangeTimeZimaLeto[ci] == 0xFFFFFFFF)
					{
						TableChangeTimeZimaLeto[ci] = cb;
						Println(&huart1, "\nDate add: ");
						itoa((cb >> 24), buff, 16);
						Println(&huart1, buff);
						Println(&huart1, "/");
						itoa(((cb >> 16) & 0xFF), buff, 16);
						Println(&huart1, buff);
						Println(&huart1, "/20");
						itoa(((cb >> 8) & 0xFF), buff, 16);
						if(strlen(buff) < 2)	Println(&huart1, "0");
						Println(&huart1, buff);
						ci = ZIMALETO_TABLE_SIZE;
					}
				}
			}
			break;

//////////////// Debug command //////////////////////////////////////////
		case TEST_CMD_0:			// cmd	0xA2
// clear error memory registers
#ifdef _BUS_OUTPUT_UART
			ClockRAM.config.di1_PP380 = 0;
			ClockRAM.config.di2_PP380 = 0;
			ClockRAM.config.dim1_PP380 = 0;
			ClockRAM.config.dim2_PP380 = 0;
			RefreshMemData();
			Println(&huart1, "\nDIM1_and_DIM2_is_cleared.");
////// ERASE EEPROM MEMORY	///////////////////
/*
			memset(buff_i2c, 0xFF, 32);
			for(ci=0; ci<0x8000; ci += 32)
			{
				HAL_I2C_Mem_Write(&hi2c1, MEM_ADDR, ci, I2C_MEMADD_SIZE_16BIT, buff_i2c, 32, TIMEOUT_I2C);
				HAL_Delay(TIMEOUT_I2C);
			}
			buff_i2c[0] = 0x0;
			buff_i2c[1] = 0x0;
			HAL_I2C_Mem_Write(&hi2c1, MEM_ADDR, CURR_ADDR, I2C_MEMADD_SIZE_16BIT, buff_i2c, 2, TIMEOUT_I2C);
			HAL_Delay(TIMEOUT_I2C);
			Println(&huart1, "\nErasihg 24C256 complete! ");
*/
#endif
			break;

		case TEST_CMD_1:			// cmd	0xA4, 01 A4 01 9B
//			Println(&huart1, "\ncmd 0xA4 send.");
// read status
#ifdef _BUS_OUTPUT_UART
			uart->startReg = (uart->input_buff[2]) << 8;	// cmd param 1, year archive
			uart->startReg |= uart->input_buff[3];
			uart->lenReg = (uart->input_buff[4]) << 8;		// cmd param 2, month archive
			uart->lenReg |= uart->input_buff[5];
			cmd17addr = (uart->input_buff[6]) << 8;			// cmd param 3, day archive
			cmd17addr |= uart->input_buff[7];
			itoa(ClockRAM.config.u_battery*100, buff, 10);
			Println(&huart1, "\nU_BAT: ");
			Println(&huart1, buff);
			if(stateCharge == CHARGE_ON)	Println(&huart1, "mV, Charging_ON.");
			if(stateCharge == CHARGE_OFF)	Println(&huart1, "mV, Charging_OFF.");
			PhaseStateChange();
			itoa(ClockRAM.config.temperature, buff, 10);
			Println(&huart1, "\nTemperature: ");
			Println(&huart1, buff);
			itoa(ClockRAM.config.di1_PP380, buff, 16);
			Println(&huart1, "\nDI_1:  0x");
			Println(&huart1, buff);
			itoa(ClockRAM.config.di2_PP380, buff, 16);
			Println(&huart1, "; DI_2:  0x");
			Println(&huart1, buff);
			itoa(ClockRAM.config.dim1_PP380, buff, 16);
			Println(&huart1, "\nDIM_1: 0x");
			Println(&huart1, buff);
			itoa(ClockRAM.config.dim2_PP380, buff, 16);
			Println(&huart1, "; DIM_2: 0x");
			Println(&huart1, buff);
			ReadTime();
			TimeToString((uint8_t*)buff);
			Println(&huart1, buff);
			DateToString((uint8_t*)buff);
			Println(&huart1, buff);
			ArchiveDebug(uart->startReg, uart->lenReg, cmd17addr);
#endif
			break;

		case TEST_CMD_2:			// cmd	0xA6
//			Println(&huart1, "\ncmd 0xA6 send.");
#ifdef _BUS_OUTPUT_UART
// read 24C256, addr A6 addrEE Nbytes; buff_i2c[32]
			uart->startReg = (uart->input_buff[2]) << 8;
			uart->startReg |= uart->input_buff[3];
			uart->lenReg = (uart->input_buff[4]) << 8;		// length bytes for read
			uart->lenReg |= uart->input_buff[5];
			if(uart->lenReg > 32)	uart->lenReg = 32;
			Println(&huart1, "\ncurr addr: 0x");
			itoa(ClockRAM.config.eeAddress, buff, 16);
			Println(&huart1, buff);
			HAL_I2C_Mem_Read(&hi2c1, MEM_ADDR, uart->startReg, I2C_MEMADD_SIZE_16BIT, buff_i2c, uart->lenReg, TIMEOUT_I2C);
			Println(&huart1, "\neeprom\n 0x");
			itoa(uart->startReg, buff, 16);
			Println(&huart1, buff);
			Println(&huart1, ": 0x");
			for(ci=0; ci<uart->lenReg; ci++)
			{
				itoa(buff_i2c[ci], buff, 16);
				Println(&huart1, buff);
				if((ci & 0x07) == 0x07)
				{
					Println(&huart1, "\n 0x");
					itoa((uart->startReg)+ci+1, buff, 16);
					Println(&huart1, buff);
					Println(&huart1, ": 0x");
				}
				else
				{
					Println(&huart1, ", 0x");
				}
			}
#endif
			break;

		case TEST_CMD_3:			// cmd	0xA8
//			Println(&huart1, "\ncmd 0xA8 send.");
#ifdef _BUS_OUTPUT_UART
// write 24C256, addr, A8, addrEE, Nbytes, uint8_t data[], CRC
			uart->startReg = (uart->input_buff[2]) << 8;
			uart->startReg |= uart->input_buff[3];
			uart->lenReg = (uart->input_buff[4]) << 8;		// length bytes for write
			uart->lenReg |= uart->input_buff[5];
			if(uart->lenReg > 32)	uart->lenReg = 32;
			cb = 6;
			for(ci=0; ci<uart->lenReg; ci++)
			{
				buff_i2c[ci] = uart->input_buff[cb++];
			}
			HAL_I2C_Mem_Write(&hi2c1, MEM_ADDR, uart->startReg, I2C_MEMADD_SIZE_16BIT, buff_i2c, uart->lenReg, TIMEOUT_I2C);
			HAL_Delay(TIMEOUT_I2C);
			Println(&huart1, "\nWrite to 24C256 ");
			itoa(uart->lenReg, buff, 10);
			Println(&huart1, buff);
			Println(&huart1, " bytes.");
#endif
			break;

		case TEST_CMD_4:			// cmd	0xAA
//			Println(&huart1, "\ncmd 0xAA send.");
#ifdef _BUS_OUTPUT_UART
			debugMessage = uart->input_buff[3];
			switch(debugMessage)
			{
			case MESSAGE_BUS:
				Println(&huart1, "\nDebug BUS message ON");
				break;

			case MESSAGE_ZU:
				Println(&huart1, "\nDebug ZU message ON");
				break;

			case MESSAGE_OS:
				Println(&huart1, "\nDebug OS message ON");
				break;

			case MESSAGE_OFF:
			default:
				Println(&huart1, "\nDebug message OFF");
				break;
			}
			itoa(ClockRAM.config.status_PP380, buff, 16);
			Println(&huart1, "\nStatus PP380: 0x");
			Println(&huart1, buff);
			itoa(DevNVRAM.config.AddressPP380, buff, 16);
			Println(&huart1, "\nAddress PP380: 0x");
			Println(&huart1, buff);
			itoa(DevNVRAM.config.BaudRate*100, buff, 10);
			Println(&huart1, "\nbaud: ");
			Println(&huart1, buff);
			cval = DevNVRAM.config.BitsConfig & 0x03;
			switch(cval)
			{
				case 0:
				Println(&huart1, ", 7 bits");
				break;
				case 1:
				Println(&huart1, ", 8 bits");
				break;
				case 2:
				Println(&huart1, ", 9 bits");
				break;
				default:
				Println(&huart1, ", error bits");
				break;
			}
			cval = (DevNVRAM.config.BitsConfig >> 2) & 0x03;
			switch(cval)
			{
				case 0:
				Println(&huart1, ", 1 stop");
				break;
				case 1:
				Println(&huart1, ", 1.5 stop");
				break;
				case 2:
				Println(&huart1, ", 2 stop");
				break;
				default:
				Println(&huart1, ", error stop");
				break;
			}
			cval = (DevNVRAM.config.BitsConfig >> 4) & 0x03;
			switch(cval)
			{
				case 0:
				Println(&huart1, ", no parity");
				break;
				case 1:
				Println(&huart1, ", even parity");
				break;
				case 2:
				Println(&huart1, ", odd parity");
				break;
				default:
				Println(&huart1, ", error parity");
				break;
			}
			Println(&huart1, "\nOVP: ");
			itoa(HAL_GPIO_ReadPin(OVP_GPIO_Port, OVP_Pin), buff, 16);
			Println(&huart1, buff);
			Println(&huart1, ", OVP.type: ");
			itoa(OVP.type, buff, 16);
			Println(&huart1, buff);
#endif
			break;

		case TEST_CMD_5:			// cmd	0xA0
#ifdef _BUS_OUTPUT_UART
// 	set registers 36(0x24) 39(0x3B)
			InputCmd.InputsState = uart->input_buff[3] << 8;
			InputCmd.InputsState |= uart->input_buff[2];
			OutputCmd.OutputState = uart->input_buff[5] << 8;
			OutputCmd.OutputState |= uart->input_buff[4];
			itoa(InputCmd.InputsState, buff, 16);
			Println(&huart1, "\nwrite in register 36: 0x");
			Println(&huart1, buff);
			itoa(OutputCmd.OutputState, buff, 16);
			Println(&huart1, ", in register 59: 0x");
			Println(&huart1, buff);
#endif
			break;

			case TEST_CMD_6:			// cmd	0xAC
#ifdef _BUS_OUTPUT_UART
	// 	set flag_new_settings variable
				Println(&huart1, "\ncmd 0xAC.");
#endif
				break;

		default:
#ifdef _BUS_OUTPUT_UART
			if(debugMessage == MESSAGE_BUS)
			{
				Println(&huart1, "\ncmd fault.");
			}
#endif
			break;
		}
		uart->cntReceive = 0;
	}
#ifdef _BUS_OUTPUT_UART
	else
	{
		if(debugMessage == MESSAGE_BUS)
		{
			Println(&huart1, "\nno match address, port: ");
			itoa(uart->num, buff, 10);
			Println(&huart1, buff);
			itoa(uart->input_buff[0], buff, 16);
			Println(&huart1, "\nReceive address: 0x");
			Println(&huart1, buff);
			Println(&huart1, "\nmy address 0x");
			if(uart->num == 3)	itoa(1, buff, 16);
			else				itoa(myAddress, buff, 16);
			Println(&huart1, buff);
			Println(&huart1, "\ncountSettingsDelay: ");
			itoa(countSettingsDelay, buff, 10);
			Println(&huart1, buff);
		}
	}
#endif
}

void GetReportId(config_uart_t *uart)
{
	uart->output_buff[0] = DevNVRAM.config.AddressPP380;
	uart->output_buff[1] = REPORT_ID;
	uart->output_buff[2] = 14;
	uart->output_buff[3] = 0x22;
	uart->output_buff[4] = 0x53;
	uart->output_buff[5] = 0x79;
	uart->output_buff[6] = 0x67;
	uart->output_buff[7] = 0x6E;
	uart->output_buff[8] = 0x61;
	uart->output_buff[9] = 0x6C;
	uart->output_buff[10] = 0x5F;
	uart->output_buff[11] = 0x31;
	uart->output_buff[12] = 0x5F;
	uart->output_buff[13] = 0x33;
	uart->output_buff[14] = 0x38;
	uart->output_buff[15] = 0x30;
	uart->output_buff[16] = 0x22;
	CalculateCRC16(uart->output_buff, 17);
	UARTsend(uart, 19);
}

uint8_t WriteRegister(uint16_t addr, uint16_t val, uint8_t num)
{
	uint8_t		errcode;

	if(currAddress == 0)	return 0x97;
	errcode = 0;
	if(addr > REGISTERS-1)
	{
		addr = 0;
		errcode = 2;
	}
	/////********************* switch read only **********************/////
	switch(addr)
	{// read only registers
	case 2:			// ClockRAM
	case 3:			// ClockRAM
	case 4:			// ClockRAM
	case 5:			// ClockRAM
	case 6:			// ClockRAM
	case 7:			// ClockRAM
	case 8:			// ClockRAM
	case 16:		// ClockRAM, battery state
	case 29:		// DevVNRAM
	case 31:		// DevVNRAM
	case 32:		// DevVNRAM
	case 33:		// DevVNRAM
		val = *ptr_reg[addr];			// rewrite value for write
		errcode = 3;
		break;

	case 36:		// DevVNRAM, input state
	case 59:		// DevVNRAM, output state
		val = *ptr_reg[addr];			// rewrite value for write
		break;
/////////////////// end registers read only /////////////////////////////
	default:
		break;
	}
/////********************* switch mask read only *******************/////
	switch(addr)
	{ // mask for read only registers
	case 9:			// ClockRAM, state output
		if(val & 0x003F)
		{
			val = *ptr_reg[addr];			// rewrite value for write
			errcode = 3;
		}
		break;

	case 12:		// ClockRAM, state alarm
		if(val & 0xFFFE)
		{
			val = *ptr_reg[addr];			// rewrite value for write
			errcode = 3;
		}
		else				val &= 0x0001;
		break;

	default:
		break;
	}

/////********************* switch run command **********************/////
	if(errcode == 0)
	{
		switch(addr)
		{ // run command
		case 1:
			switch(num)
			{ // for stranger devices, test bit 13
				case 1:
				if(UART_1.mineStranger == STRANGER)
				{
					if(BIT_TEST(val, 11) == 0)		BIT_CLR(*ptr_reg[addr], 11);
					if(val & SET_STRANGER_MASK)
					{ // 13 bit
						UART_1.mineStranger = MINE;
						BIT_SET(*ptr_reg[addr], 14);
						BIT_CLR(*ptr_reg[addr], 13);
					}
					val = *ptr_reg[addr];
				}
				else
				{	// mine
					*ptr_reg[addr] = StatusRegProc(val, num);
				}
				break;

				case 2:
				if(UART_2.mineStranger == STRANGER)
				{
					if(BIT_TEST(val, 11) == 0)		BIT_CLR(*ptr_reg[addr], 11);
					if(val & SET_STRANGER_MASK)
					{ // 13 bit
						UART_2.mineStranger = MINE;
						BIT_SET(val, 15);
						BIT_CLR(val, 13);
					}
					val = *ptr_reg[addr];
				}
				else
				{	// mine
					*ptr_reg[addr] = StatusRegProc(val, num);
				}
				break;

				case 3:
					*ptr_reg[addr] = StatusRegProc(val, num);
				break;

				default:
				break;
			}
			break;

		case 9:
			if((BIT_TEST(*ptr_reg[addr], 11) == 0) && BIT_TEST(val, 11))
			{
				flagRunVLV = VALVE_ON;
			}
			if(BIT_TEST(*ptr_reg[addr], 11) && (BIT_TEST(val, 11) == 0))
			{
				flagRunVLV = VALVE_OFF;
			}
			*ptr_reg[addr] = val;		// write register
			break;

		case 10:
			TimeFromRegisters(val);		// (hour*256)+minut
#ifdef _BUS_OUTPUT_UART
			if(debugMessage == MESSAGE_BUS)
			{
				Println(&huart1, "\nSet time.");
			}
#endif
			break;

		case 11:
			*ptr_reg[addr] = val;		// write register
			DateFromRegisters(val);		// (year*512)+(month*32)+day
#ifdef _BUS_OUTPUT_UART
			if(debugMessage == MESSAGE_BUS)
			{
				Println(&huart1, "\nSet date.");
			}
#endif
			break;

		case 35: // input registers cmd
			InputRegistersCmd(val);
			InitInputPins();
			break;

		case 53:
			phaseNet.phaseOld = 0;
			*ptr_reg[addr] = val;		// write register
			break;

		case 58: // output registers cmd
			OutputRegistersCmd(val);
			InitOutputPins();
			break;

		case 69:	// test lines control
			SetTestLines(val);
			*ptr_reg[addr] = val;		// write register
			break;

		case 70:
			if((val & 0xFF) == 0)	val = 1;
			*ptr_reg[addr] = val & 0xFF;		// write register new address
			if((UART_1.mineStranger == STRANGER) && (UART_2.mineStranger == STRANGER))
			{
				myAddress = DevNVRAM.config.AddressPP380 & 0xFF;	// copy address for work
			}
			break;

		case 71:
			oldSpeed = *ptr_reg[addr];
			*ptr_reg[addr] = CheckBaudRate(val & 0x07FF);		// write register
			if((UART_1.mineStranger == STRANGER) && (UART_2.mineStranger == STRANGER))
			{
				flagReInstal = 1;
				countSettingsDelay = 0;
			}
			break;

		case 72:
			oldParam = *ptr_reg[addr];
			*ptr_reg[addr] = val & 0xFF;		// write register
			if((UART_1.mineStranger == STRANGER) && (UART_2.mineStranger == STRANGER))
			{
				flagReInstal = 1;
				countSettingsDelay = 0;
			}
			break;

		case 73:	// cmd archive
			ArchiveCommand(val);
			break;

		default:
			*ptr_reg[addr] = val;		// write register
			break;
		}
	}
	RefreshFlashData();
	return errcode;
}

uint16_t ReadRegisters(config_uart_t *uart)
{
	uint16_t ci, cb, cval;
	// read registers to output_buffer
	uart->startReg = (uart->input_buff[2]) << 8;
	uart->startReg |= uart->input_buff[3];
	uart->lenReg = (uart->input_buff[4]) << 8;
	uart->lenReg |= uart->input_buff[5];
	uart->output_buff[0] = uart->input_buff[0];
	uart->output_buff[1] = uart->input_buff[1];
	uart->output_buff[2] = 0;		// bytes counter
	cb = 3;							// index output_buff data
	for(ci=0; ci<(uart->lenReg); ci++)
	{
		cval = *ptr_reg[uart->startReg+ci];
		if((uart->num == 1) && ((uart->startReg+ci) == 1))	cval &= ANS_PORT1_MASK;
		if((uart->num == 2) && ((uart->startReg+ci) == 1))	cval &= ANS_PORT2_MASK;
		uart->output_buff[cb++] = (cval >> 8) & 0xFF;
		uart->output_buff[cb++] = cval & 0xFF;
	}
	uart->output_buff[2] = ci << 1;
	CalculateCRC16(uart->output_buff, cb);
	return cb+2;
}

uint16_t StatusRegProc(uint16_t val, uint8_t num)
{
	if((val & 0x0001))
	{ // start 3 sec. timer for test
		countTestDelay = COUNTTESTDELAY;
	}
	if((val & 0x0008) == 0)
	{ // flag for clear DIM1, DIM2
		ClockRAM.config.dim1_PP380 = 0;
		ClockRAM.config.dim2_PP380 = 0;
	}
	if((val & 0x0010) == 0x0010)
	{ // flag for reset default all param
		resetDefault = 1;
		FlashToRegisters();
		ReadRamToRegisters();
		val &= 0xFFEF;		// ~0x0010, reset bit
	}
	if((val & 0x4002) == 0x4002)
	{	 // test bits for mine devices
		countSettingsDelay = NEW_SETTINGS_TIMEOUT;
#ifdef _BUS_OUTPUT_UART
		if(debugMessage == MESSAGE_BUS)
		{
			Println(&huart1, "\nset bit new settings for UART_1");
		}
#endif
	}
	if((val & 0x8004) == 0x8004)
	{ // start timer for new settings
		countSettingsDelay = NEW_SETTINGS_TIMEOUT;
#ifdef _BUS_OUTPUT_UART
		if(debugMessage == MESSAGE_BUS)
		{
			Println(&huart1, "\nset bit new settings for UART_2");
		}
#endif
	}
#ifdef _BUS_OUTPUT_UART
	if(debugMessage == MESSAGE_BUS)
	{
		if((UART_1.mineStranger == STRANGER) && (val & 0x0002))
		{
			Println(&huart1, "\nerror set bit new settings for UART_1");
		}
		if((UART_2.mineStranger == STRANGER) && (val & 0x0004))
		{
			Println(&huart1, "\nerror set bit new settings for UART_2");
		}
	}
#endif
	if(val & 0x0040)
	{ // soft reset all system
#ifdef _BUS_OUTPUT_UART
	if(debugMessage == MESSAGE_BUS)
	{
		Println(&huart1, "\nSYSTEM RESET...");
	}
#endif
		HAL_NVIC_SystemReset();
	}
	if(UART_1.mineStranger == MINE)
	{
		BIT_SET(val, 14);
		if(BIT_TEST(val, 13))
		{
			BIT_CLR(val, 13);
#ifdef _BUS_OUTPUT_UART
			if(debugMessage == MESSAGE_BUS)
			{
				Println(&huart1, "\nbit 13 error setting, port 1");
			}
#endif
		}
	}
	if(UART_2.mineStranger == MINE)
	{
		BIT_SET(val, 15);
#ifdef _BUS_OUTPUT_UART
			if(debugMessage == MESSAGE_BUS)
			{
				Println(&huart1, "\nbit 13 error setting, port 2");
			}
#endif
	}
	return val;
}

void UARTsend(config_uart_t *uart, uint16_t len)
{
	switch(uart->num)
	{
	default:
	case 0:
#ifdef _BUS_OUTPUT_UART
		if(debugMessage == MESSAGE_BUS)
		{
			Println(&huart1, "\nNot define output UART port.");
		}
#endif
		break;
	case 1:
		HAL_GPIO_WritePin(DIR1_GPIO_Port, DIR1_Pin, GPIO_PIN_SET);
		HAL_UART_Transmit(&huart1, uart->output_buff, len, UART_TIMEOUT);
		HAL_GPIO_WritePin(DIR1_GPIO_Port, DIR1_Pin, GPIO_PIN_RESET);
		break;
	case 2:
		HAL_GPIO_WritePin(DIR2_GPIO_Port, DIR2_Pin, GPIO_PIN_SET);
		HAL_UART_Transmit(&huart2, uart->output_buff, len, UART_TIMEOUT);
		HAL_GPIO_WritePin(DIR2_GPIO_Port, DIR2_Pin, GPIO_PIN_RESET);
		break;
	case 3:
		HAL_UART_Transmit(&huart3, uart->output_buff, len, UART_TIMEOUT);
		break;
	}
}

void InitD(input_t *dd, inFlash_t *df, uint16_t mask)
{// bit5-Type, bit6-Delay, bit7-Name
	uint8_t  refresh;

	refresh = 0;
	if((BIT_TEST(mask, 5)) || (BIT_TEST(mask, 6)))
	{
		df->CfgTypeDelay = InputCmd.InputDelay;
		refresh++;
	}
	dd->type = df->CfgTypeDelay & 0x03;
	dd->delay = 0;
	if(dd->type == PINTYPE_NO)		dd->state = 1;
	if(dd->type == PINTYPE_NC)		dd->state = 0;
	if(BIT_TEST(mask, 7))
	{
		SetInputName(df->Name);
		refresh++;
	}
	if(refresh)			RefreshFlashData();			// write data to flash memory
}

void GetInitD1(void)
{
	InputCmd.InputDelay = DevNVRAM.config.DF1.CfgTypeDelay;
	GetInputName(DevNVRAM.config.DF1.Name);
}

void GetInitD2(void)
{
	InputCmd.InputDelay = DevNVRAM.config.DF2.CfgTypeDelay;
	GetInputName(DevNVRAM.config.DF2.Name);
}

void GetInitD3(void)
{
	InputCmd.InputDelay = DevNVRAM.config.DF3.CfgTypeDelay;
	GetInputName(DevNVRAM.config.DF3.Name);
}

void GetInitD4(void)
{
	InputCmd.InputDelay = DevNVRAM.config.DF4.CfgTypeDelay;
	GetInputName(DevNVRAM.config.DF4.Name);
}

void GetInitD5(void)
{
	InputCmd.InputDelay = DevNVRAM.config.DF5.CfgTypeDelay;
	GetInputName(DevNVRAM.config.DF5.Name);
}

void GetInitD6(void)
{
	InputCmd.InputDelay = DevNVRAM.config.DF6.CfgTypeDelay;
	GetInputName(DevNVRAM.config.DF6.Name);
}

void GetInitD7(void)
{
	InputCmd.InputDelay = DevNVRAM.config.DF7.CfgTypeDelay;
	GetInputName(DevNVRAM.config.DF7.Name);
}

void GetInitD8(void)
{
	InputCmd.InputDelay = DevNVRAM.config.DF8.CfgTypeDelay;
	GetInputName(DevNVRAM.config.DF8.Name);
}

void GetInitD9(void)
{
	InputCmd.InputDelay = DevNVRAM.config.DF9.CfgTypeDelay;
	GetInputName(DevNVRAM.config.DF9.Name);
}

void GetInitD10(void)
{
	InputCmd.InputDelay = DevNVRAM.config.DF10.CfgTypeDelay;
	GetInputName(DevNVRAM.config.DF10.Name);
}

void GetInitD11(void)
{
	InputCmd.InputDelay = DevNVRAM.config.DF11.CfgTypeDelay;
	GetInputName(DevNVRAM.config.DF11.Name);
}

void GetInitD12(void)
{
	InputCmd.InputDelay = DevNVRAM.config.DF12.CfgTypeDelay;
	GetInputName(DevNVRAM.config.DF12.Name);
}

void GetInitD13(void)
{
	InputCmd.InputDelay = DevNVRAM.config.DF13.CfgTypeDelay;
	GetInputName(DevNVRAM.config.DF13.Name);
}

void GetInitD14(void)
{
	InputCmd.InputDelay = DevNVRAM.config.DF14.CfgTypeDelay;
	GetInputName(DevNVRAM.config.DF14.Name);
}

void GetInitD15(void)
{
	InputCmd.InputDelay = DevNVRAM.config.DF15.CfgTypeDelay;
	GetInputName(DevNVRAM.config.DF15.Name);
}

void GetInitD16(void)
{
	InputCmd.InputDelay = DevNVRAM.config.DF16.CfgTypeDelay;
	GetInputName(DevNVRAM.config.DF16.Name);
}

// GPIO_PinState HAL_GPIO_ReadPin(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin)
void TestD(input_t *DP , inFlash_t *DF, uint16_t bit, GPIO_TypeDef *GPIOx, uint16_t GPIO_Pin)
{	// HAL_GPIO_ReadPin(D1_GPIO_Port, D1_Pin)
	if(DP->state != HAL_GPIO_ReadPin(GPIOx, GPIO_Pin))
	{
		DP->state = HAL_GPIO_ReadPin(GPIOx, GPIO_Pin);
		DP->delay = DF->CfgTypeDelay >> 2;
		if(DP->delay == 0)		DP->delay = 1;
	}
	if(DP->delay == 0)
	{
		if(((DP->state == 0) && (DP->type == PINTYPE_NO)) || ((DP->state == 1) && (DP->type == PINTYPE_NC)))
		{
			if(BIT_TEST(ClockRAM.config.di1_PP380, bit) == 0)
			{
				BIT_SET(ClockRAM.config.di1_PP380, bit);
			}
		}
	}
	if(((DP->state == 1) && (DP->type == PINTYPE_NO)) || ((DP->state == 0) && (DP->type == PINTYPE_NC)) || (DP->type == PINTYPE_OFF))
	{
		if(BIT_TEST(ClockRAM.config.di1_PP380, bit))
		{
			BIT_SET(ClockRAM.config.dim1_PP380, bit);
			BIT_CLR(ClockRAM.config.di1_PP380, bit);
		}
	}
}

void TestOVP(void)
{// HAL_GPIO_ReadPin(OVP_GPIO_Port, OVP_Pin)

	if(OVP.type == 0)
	{	// no phase 1
		if(BIT_TEST(ClockRAM.config.di2_PP380, 8))
		{
			BIT_CLR(ClockRAM.config.di2_PP380, 8);
			BIT_SET(ClockRAM.config.dim2_PP380, 8);
		}
		OVP.delay = 0;
	}
	if(OVP.type == 1)
	{
		if(HAL_GPIO_ReadPin(OVP_GPIO_Port, OVP_Pin))
		{ // over_voltage
			OVP.delay++;
		}
		if(!HAL_GPIO_ReadPin(OVP_GPIO_Port, OVP_Pin))
		{
			if(BIT_TEST(ClockRAM.config.di2_PP380, 8))
			{
				BIT_CLR(ClockRAM.config.di2_PP380, 8);
				BIT_SET(ClockRAM.config.dim2_PP380, 8);
			}
			OVP.delay = 0;
		}
	}
	if(OVP.delay > OVP_DELAY)
	{
		BIT_SET(ClockRAM.config.di2_PP380, 8);
	}
}

void TestLines(void)
{
	if(UART_1.cntTestLine == 1)
	{
		if(UART_1.tstLine == 1 && (!BIT_TEST(ClockRAM.config.di2_PP380, 13)))
		{
			BIT_SET(ClockRAM.config.di2_PP380, 13);
			UART_1.cntTestLine = 0;
		}
		UART_1.mineStranger = STRANGER;
		BIT_CLR(ClockRAM.config.status_PP380, 14);
#ifdef _BUS_OUTPUT_UART
		if(debugMessage == MESSAGE_BUS)
		{
			Println(&huart1, "\nUART 1 set stranger");
			if(BIT_TEST(ClockRAM.config.status_PP380, 15))
			{
				Println(&huart1, "\nUART 2 set mine");
			}
		}
#endif
	}
	if(UART_1.cntTestLine > 2)
	{
		if(BIT_TEST(ClockRAM.config.di2_PP380, 13))
		{
			BIT_SET(ClockRAM.config.dim2_PP380, 13);
			BIT_CLR(ClockRAM.config.di2_PP380, 13);
		}
		if(UART_1.mineStranger == MINE)
		{
			BIT_SET(ClockRAM.config.status_PP380, 14);
		}
	}
	if((UART_2.cntTestLine == 1))
	{
		if(UART_2.tstLine == 1 && (!BIT_TEST(ClockRAM.config.di2_PP380, 14)))
		{
			BIT_SET(ClockRAM.config.di2_PP380, 14);
			UART_2.cntTestLine = 0;
		}
		UART_2.mineStranger = STRANGER;
		BIT_CLR(ClockRAM.config.status_PP380, 15);
#ifdef _BUS_OUTPUT_UART
		if(debugMessage == MESSAGE_BUS)
		{
			if(BIT_TEST(ClockRAM.config.status_PP380, 14))
			{
				Println(&huart1, "\nUART 1 set mine");
			}
			Println(&huart1, "\nUART 2 set stranger");
		}
#endif
	}
	if(UART_2.cntTestLine > 2)
	{
		if(BIT_TEST(ClockRAM.config.di2_PP380, 14))
		{
			BIT_SET(ClockRAM.config.dim2_PP380, 14);
			BIT_CLR(ClockRAM.config.di2_PP380, 14);
		}
		if(UART_2.mineStranger == MINE)
		{
			BIT_SET(ClockRAM.config.status_PP380, 15);
		}
	}
	if((UART_3.cntTestLine == 1) && (!BIT_TEST(ClockRAM.config.di2_PP380, 15)) && (UART_3.tstLine == 1))
	{
		BIT_SET(ClockRAM.config.di2_PP380, 15);
		UART_3.cntTestLine = 0;
	}
	if((UART_3.cntTestLine > 2) && (BIT_TEST(ClockRAM.config.di2_PP380, 15)))
	{
		BIT_SET(ClockRAM.config.dim2_PP380, 15);
		BIT_CLR(ClockRAM.config.di2_PP380, 15);
	}
}

void SetTestLines(uint16_t val)
{
	if(val & 0x0001)
	{
		UART_1.tstLine = 1;
		UART_1.cntTestLine = TEST_LINE_TIME;
	}
	if((val & 0x0001) == 0)
	{
		UART_1.tstLine = 0;
		if(BIT_TEST(ClockRAM.config.di2_PP380, 13))
		{
			BIT_SET(ClockRAM.config.dim2_PP380, 13);
			BIT_CLR(ClockRAM.config.di2_PP380, 13);
		}
	}
	if(val & 0x0002)
	{
		UART_2.tstLine = 1;
		UART_2.cntTestLine = TEST_LINE_TIME;
	}
	if((val & 0x0002) == 0)
	{
		UART_2.tstLine = 0;
		if(BIT_TEST(ClockRAM.config.di2_PP380, 14))
		{
			BIT_SET(ClockRAM.config.dim2_PP380, 14);
			BIT_CLR(ClockRAM.config.di2_PP380, 14);
		}
	}
}

void InputRegistersCmd(uint16_t val)
{ //	val & 0x001F -> N-input (16 all)
	if(val & 0x8000)
	{ // write settings
		// InputRegistersWrite(val);
		sequenceCmd[0] = 1;   		// sequence flag set
		sequenceCmd[1] = 0x23;   	// sequence input address set
		sequenceCmd[2] = val;   	// sequence value set
	}
	else
	{ // reading settings
		InputRegistersRead(val);
	}
}

void InputRegistersWrite(uint16_t val)
{
	switch(val & 0x001F)
	{
	case 1:
		InitD(&D1, &DevNVRAM.config.DF1, val & MASK_REG_INPUT);
		break;
	case 2:
		InitD(&D2, &DevNVRAM.config.DF2, val & MASK_REG_INPUT);
		break;
	case 3:
		InitD(&D3, &DevNVRAM.config.DF3, val & MASK_REG_INPUT);
		break;
	case 4:
		InitD(&D4, &DevNVRAM.config.DF4, val & MASK_REG_INPUT);
		break;
	case 5:
		InitD(&D5, &DevNVRAM.config.DF5, val & MASK_REG_INPUT);
		break;
	case 6:
		InitD(&D6, &DevNVRAM.config.DF6, val & MASK_REG_INPUT);
		break;
	case 7:
		InitD(&D7, &DevNVRAM.config.DF7, val & MASK_REG_INPUT);
		break;
	case 8:
		InitD(&D8, &DevNVRAM.config.DF8, val & MASK_REG_INPUT);
		break;
	case 9:
		InitD(&D9, &DevNVRAM.config.DF9, val & MASK_REG_INPUT);
		break;
	case 10:
		InitD(&D10, &DevNVRAM.config.DF10, val & MASK_REG_INPUT);
		break;
	case 11:
		InitD(&D11, &DevNVRAM.config.DF11, val & MASK_REG_INPUT);
		break;
	case 12:
		InitD(&D12, &DevNVRAM.config.DF12, val & MASK_REG_INPUT);
		break;
	case 13:
		InitD(&D13, &DevNVRAM.config.DF13, val & MASK_REG_INPUT);
		break;
	case 14:
		InitD(&D14, &DevNVRAM.config.DF14, val & MASK_REG_INPUT);
		break;
	case 15:
		InitD(&D15, &DevNVRAM.config.DF15, val & MASK_REG_INPUT);
		break;
	case 16:
		InitD(&D16, &DevNVRAM.config.DF16, val & MASK_REG_INPUT);
		break;
	default:
		break;
	}
}

void InputRegistersRead(uint16_t val)
{
	switch(val & 0x001F)
	{
	case 1:
		GetInitD1();
		break;
	case 2:
		GetInitD2();
		break;
	case 3:
		GetInitD3();
		break;
	case 4:
		GetInitD4();
		break;
	case 5:
		GetInitD5();
		break;
	case 6:
		GetInitD6();
		break;
	case 7:
		GetInitD7();
		break;
	case 8:
		GetInitD8();
		break;
	case 9:
		GetInitD9();
		break;
	case 10:
		GetInitD10();
		break;
	case 11:
		GetInitD11();
		break;
	case 12:
		GetInitD12();
		break;
	case 13:
		GetInitD13();
		break;
	case 14:
		GetInitD14();
		break;
	case 15:
		GetInitD15();
		break;
	case 16:
		GetInitD16();
		break;
	default:
		break;
	}
}

void OutputRegistersCmd(uint16_t val)
{ //	val & 0x001F -> N-output (6 all)
	if(val & 0x8000)
	{ // write settings
		// OutputRegistersWrite(val);
		sequenceCmd[0] = 1;   		// sequence flag set
		sequenceCmd[1] = 0x3A;   	// sequence output address set
		sequenceCmd[2] = val;   	// sequence value set
	}
	else
	{ // read settings
		OutputRegistersRead(val);
	}
}

void OutputRegistersWrite(uint16_t val)
{
	switch(val & 0x001F)
	{
	case 1:
		InitRele1(val & MASK_REG_OUTPUT);
		break;
	case 2:
		InitRele2(val & MASK_REG_OUTPUT);
		break;
	case 3:
		InitRele3(val & MASK_REG_OUTPUT);
		break;
	case 4:
		InitRele4(val & MASK_REG_OUTPUT);
		break;
	case 5:
		InitRele5(val & MASK_REG_OUTPUT);
		break;
	case 6:
		InitValve(val & MASK_VLV_OUTPUT); // no change name
		break;
	default:
		break;
	}
}

void OutputRegistersRead(uint16_t val)
{
	switch(val & 0x001F)
	{
	case 1:
		GetInitRele1();
		break;
	case 2:
		GetInitRele2();
		break;
	case 3:
		GetInitRele3();
		break;
	case 4:
		GetInitRele4();
		break;
	case 5:
		GetInitRele5();
		break;
	case 6:
		GetInitValve();
		break;
	default:
		break;
	}
}

void RunSequenceCmd(void)
{
	if(sequenceCmd[0] == 0)			return;
	else
	{
		switch (sequenceCmd[1])
		{ // sequenceCmd[2] => val
		case 35:	// 0x23 input cmd register
			InputRegistersWrite(sequenceCmd[2]);
			if(BIT_TEST(sequenceCmd[2], 7))
			{
				BIT_SET(InputCmd.InputsState, ((sequenceCmd[2] & 0x001F) - 1));
			}
#ifdef _BUS_OUTPUT_UART
			if(debugMessage == MESSAGE_BUS)
			{
				if(InputCmd.InputsState)
				{
					Println(&huart1, "\nchange input name, input state: 0x");
					itoa(InputCmd.InputsState, buff, 16);
					Println(&huart1, buff);
				}
			}
#endif
			break;

		case 58:	// 0x3A output cmd register
			OutputRegistersWrite(sequenceCmd[2]);
			if(BIT_TEST(sequenceCmd[2], 5))
			{ // change name (output - 5 bit)
				BIT_SET(OutputCmd.OutputState, ((sequenceCmd[2] & 0x0007) - 1));
			}
			if((sequenceCmd[2] & 0x0406) == 0x0406)
			{ // change mask (mask - 10 bit) for klapan (6-st number)
				BIT_SET(OutputCmd.OutputState, 5);
			}
#ifdef _BUS_OUTPUT_UART
			if(debugMessage == MESSAGE_BUS)
			{
				if(OutputCmd.OutputState)
				{
					Println(&huart1, "\nchange output name, output state: 0x");
					itoa(OutputCmd.OutputState, buff, 16);
					Println(&huart1, buff);
				}
			}
#endif
			break;

		default:
			break;
		}
		sequenceCmd[0] = 0;
	}
}

void ArchiveCommand(uint16_t value)
{
	uint16_t param, flags, cv;

#ifdef _BUS_OUTPUT_UART
	char buf[8];
	uint16_t  cn;
#endif

	param = value & 0x01FF;
	flags = value >> 9;

	switch(flags)
	{
	case 0x01:		// 0x01, read all archiveYear
		archiveEeAddrPoint = (ClockRAM.config.eeAddress + ARCHIVE_MSG_LEN);
		if(archiveEeAddrPoint > MAX_ADDR)		archiveEeAddrPoint = MAX_ADDR;
#ifdef _BUS_OUTPUT_UART
			if(debugMessage == MESSAGE_BUS)
			{
				Println(&huart1, "\ncreated dump eeprom: 0x");
				itoa(archiveEeAddrPoint, buf, 16);
				Println(&huart1, buf);
				Println(&huart1, " ... 0x");
				itoa(MAX_ADDR, buf, 16);
				Println(&huart1, buf);
			}
#endif
		if(param == 0)
		{
			archiveCntYears = ArchiveReadYears(archiveArrYears, ARCHIVE_PARAM_MAX, archiveEeAddrPoint); // archiveRez
			*ptr_reg[ARCHIVE_INDEX-1] = value | archiveCntYears;
			archiveIndexYears = 0;
			for(cv=0; cv<ARCHIVE_PARAM_MAX; cv++)
			{
				if(cv == archiveCntYears)		break;
				else							*ptr_reg[ARCHIVE_INDEX+cv] = archiveArrYears[cv];
			}
		}
		else
		{
			archiveCntYears = 0;
#ifdef _BUS_OUTPUT_UART
			if(debugMessage == MESSAGE_BUS)
			{
				Println(&huart1, "\ncmd 0x02, incorrect, parameter not zero");
			}
#endif
		}
#ifdef _BUS_OUTPUT_UART
		if(debugMessage == MESSAGE_BUS)
		{
			if(archiveCntYears)
			{
				Println(&huart1, "\ncmd 0x02, years: ");
				itoa(archiveCntYears, buf, 10);
				Println(&huart1, buf);
				for(cn=0; cn<archiveCntYears; cn++)
				{
					Println(&huart1, "\nyear[");
					itoa(cn, buf, 10);
					Println(&huart1, buf);
					Println(&huart1, "] = ");
					itoa(archiveArrYears[cn], buf, 10);
					Println(&huart1, buf);
				}
			}
			else
			{
				Println(&huart1, "\nnot years");
			}
		}
#endif
		break;

	case 0x21:		// 0x21, select year
		if(param < archiveCntYears)
		{
			archiveIndexYears = param;
			archiveYear = archiveArrYears[archiveIndexYears];
	//	case 0x02:		// 0x02, Month
			archiveCntMonts = ArchiveReadMonts(archiveArrMonts, archiveYear, ARCHIVE_PARAM_MAX, archiveEeAddrPoint);
			archiveIndexMonts = 0;
			value =  value & 0xFE00;				// clear param
			*ptr_reg[ARCHIVE_INDEX-1] =  value | archiveCntMonts;
			for(cv=0; cv<ARCHIVE_PARAM_MAX; cv++)
			{
				if(cv == archiveCntMonts)		break;
				else							*ptr_reg[ARCHIVE_INDEX+cv] = archiveArrMonts[cv];
			}
		}
		else
		{
#ifdef _BUS_OUTPUT_UART
			if(debugMessage == MESSAGE_BUS)
			{
				Println(&huart1, "\ncmd 0x42, index incorrect");
			}
#endif
		}
#ifdef _BUS_OUTPUT_UART
		if(debugMessage == MESSAGE_BUS)
		{
			Println(&huart1, "\ncmd 0x42, index year: ");
			itoa(archiveIndexYears, buf, 10);
			Println(&huart1, buf);
			Println(&huart1, ", year: 20");
			if(archiveYear < 10)  Println(&huart1, "0");
			itoa(archiveYear, buf, 10);
			Println(&huart1, buf);
			if(archiveCntMonts)
			{
				Println(&huart1, "\nmonths: ");
				itoa(archiveCntMonts, buf, 10);
				Println(&huart1, buf);
				for(cn=0; cn<archiveCntMonts; cn++)
				{
					Println(&huart1, "\nmonth[");
					itoa(cn, buf, 10);
					Println(&huart1, buf);
					Println(&huart1, "] = ");
					itoa(archiveArrMonts[cn], buf, 10);
					Println(&huart1, buf);
				}
			}
			else
			{
				Println(&huart1, "\nnot months");
			}
		}
#endif
		break;

	case 0x22:		// 0x22, select archiveMonth
		if(param < archiveCntMonts)
		{
		archiveIndexMonts = param;
		archiveMonth = archiveArrMonts[archiveIndexMonts];
		archiveYear = archiveArrYears[archiveIndexYears];
//	case 0x04:		// 0x04, Day
			if(archiveMonth != 0)
			{
				archiveCntDays = ArchiveReadDays(archiveArrDays, archiveYear, archiveMonth, 32, archiveEeAddrPoint);
				archiveIndexDays = 0;
				value = value & 0xFE00;				// clear param
				*ptr_reg[ARCHIVE_INDEX-1] =  value | archiveCntDays;
				for(cv=0; cv<ARCHIVE_PARAM_MAX; cv++)
				{
					if(cv == archiveCntDays)		break;
					else							*ptr_reg[ARCHIVE_INDEX+cv] = archiveArrDays[cv];
				}
			}
		}
		else
		{
#ifdef _BUS_OUTPUT_UART
			if(debugMessage == MESSAGE_BUS)
			{
				Println(&huart1, "\ncmd 0x44, index incorrect");
			}
#endif
		}
#ifdef _BUS_OUTPUT_UART
		if(debugMessage == MESSAGE_BUS)
		{
			Println(&huart1, "\ncmd 0x44, index year: ");
			itoa(archiveIndexYears, buf, 10);
			Println(&huart1, buf);
			Println(&huart1, ", year: 20");
			if(archiveYear < 10) Println(&huart1, "0");
			itoa(archiveYear, buf, 10);
			Println(&huart1, buf);
			Println(&huart1, ", index month: ");
			itoa(archiveIndexMonts, buf, 10);
			Println(&huart1, buf);
			Println(&huart1, ", month: ");
			itoa(archiveMonth, buf, 10);
			Println(&huart1, buf);
			if(archiveCntDays)
			{
				Println(&huart1, "\ndays: ");
				itoa(archiveCntDays, buf, 10);
				Println(&huart1, buf);
				for(cn=0; cn<archiveCntDays; cn++)
				{
					Println(&huart1, "\nday[");
					itoa(cn, buf, 10);
					Println(&huart1, buf);
					Println(&huart1, "] = ");
					itoa(archiveArrDays[cn], buf, 10);
					Println(&huart1, buf);
				}
			}
			else
			{
				Println(&huart1, "\nnot days");
			}
		}
#endif
		break;

	case 0x24:		// 0x24, select archiveDay
		if(param < archiveCntDays)
		{
			archiveIndexDays = param;
			archiveDay = archiveArrDays[archiveIndexDays];
			archiveMonth = archiveArrMonts[archiveIndexMonts];
			archiveYear = archiveArrYears[archiveIndexYears];
	//	case 0x08:		// 0x08, event
			archiveCntEvents = ArchiveReadEvents(archiveArrEvents, archiveYear, archiveMonth, archiveDay, (ARCHIVE_PARAM_MAX*15)-6, archiveEeAddrPoint);
			archiveIndexEvents = 0;
			value = value & 0xFE00;				// clear param
			*ptr_reg[ARCHIVE_INDEX-1] =  value | (archiveCntEvents/3);
			for(cv=0; cv<ARCHIVE_PARAM_MAX; cv++)
			{
				if(cv == archiveCntEvents)			break;
				else								*ptr_reg[ARCHIVE_INDEX+cv] = archiveArrEvents[cv];
			}
		}
		else
		{
#ifdef _BUS_OUTPUT_UART
			if(debugMessage == MESSAGE_BUS)
			{
				Println(&huart1, "\ncmd 0x48, index incorrect");
			}
#endif
		}
#ifdef _BUS_OUTPUT_UART
		if(debugMessage == MESSAGE_BUS)
		{
			Println(&huart1, "\ncmd 0x48, index year: ");
			itoa(archiveIndexYears, buf, 10);
			Println(&huart1, buf);
			Println(&huart1, ", year: 20");
			if(archiveYear < 10) Println(&huart1, "0");
			itoa(archiveYear, buf, 10);
			Println(&huart1, buf);
			Println(&huart1, ", index month: ");
			itoa(archiveIndexMonts, buf, 10);
			Println(&huart1, buf);
			Println(&huart1, ", month: ");
			itoa(archiveMonth, buf, 10);
			Println(&huart1, buf);
			Println(&huart1, ", index day: ");
			itoa(archiveIndexDays, buf, 10);
			Println(&huart1, buf);
			Println(&huart1, ", day: ");
			itoa(archiveDay, buf, 10);
			Println(&huart1, buf);
			if(archiveCntEvents)
			{
				uint8_t tmp;
				tmp = archiveCntEvents/3;
				Println(&huart1, ", events: ");
				itoa(tmp, buf, 10);
				Println(&huart1, buf);
				for(cn=0; cn<archiveCntEvents; cn+=3)
				{
					tmp = archiveArrEvents[cn] >> 8;
					Println(&huart1, "\n  ");
					itoa(tmp, buf, 10);
					if(strlen(buf) == 1)	Println(&huart1, "0");
					Println(&huart1, buf);
					Println(&huart1, ":");
					tmp = archiveArrEvents[cn] & 0xFF;
					itoa(tmp, buf, 10);
					if(strlen(buf) == 1)	Println(&huart1, "0");
					Println(&huart1, buf);
					tmp = archiveArrEvents[cn+1] >> 8;
					Println(&huart1, ", T*C:");
					itoa(tmp, buf, 10);
					Println(&huart1, buf);
					Println(&huart1, ", st:");
					tmp = archiveArrEvents[cn+1] & 0x0080;
					if(tmp)		Println(&huart1, "1-");
					else		Println(&huart1, "0-");
					tmp = archiveArrEvents[cn+1] & 0x007F;
					itoa(tmp, buf, 10);
					Println(&huart1, buf);
					Println(&huart1, ", Ubat:");
					tmp = archiveArrEvents[cn+2] >> 8;
					itoa(tmp, buf, 10);
					Println(&huart1, buf);
					Println(&huart1, ", Uin:");
					tmp = archiveArrEvents[cn+2] & 0xFF;
					itoa(tmp, buf, 10);
					Println(&huart1, buf);
				}
			}
			else
			{
				Println(&huart1, "\nnot events");
			}
		}
#endif
		break;

	case 0x14:		// 0x14, day bask0_front1
		if(param > archiveCntDays-1)		param = archiveCntDays-1;
		archiveIndexDays = param;
		for(cv=0; cv<ARCHIVE_PARAM_MAX; cv++)
		{ //
			if(archiveIndexDays+cv >= archiveCntDays)		break;
			else											*ptr_reg[ARCHIVE_INDEX+cv] = archiveArrDays[archiveIndexDays+cv];
		}
		value = archiveCntDays - param;
		value |= (flags << 9);
		*ptr_reg[ARCHIVE_INDEX-1] = value;		// write register
#ifdef _BUS_OUTPUT_UART
		if(debugMessage == MESSAGE_BUS)
		{
			Println(&huart1, "\ncmd 0x28, set index day: ");
			itoa(archiveIndexDays, buf, 10);
			Println(&huart1, buf);
			Println(&huart1, ", current day: ");
			itoa(archiveArrDays[archiveIndexDays], buf, 10);
			Println(&huart1, buf);
		}
#endif
		break;

	case 0x12:		// 0x12, month bask0_front1
		if(param > archiveCntMonts-1)		param = archiveCntMonts-1;
		archiveIndexMonts = param;
		for(cv=0; cv<ARCHIVE_PARAM_MAX; cv++)
		{ //
			if(archiveIndexMonts+cv >= archiveCntMonts)		break;
			else											*ptr_reg[ARCHIVE_INDEX+cv] = archiveArrMonts[archiveIndexMonts+cv];
		}
		value = archiveCntMonts - param;
		value |= (flags << 9);
		*ptr_reg[ARCHIVE_INDEX-1] = value;		// write register
#ifdef _BUS_OUTPUT_UART
		if(debugMessage == MESSAGE_BUS)
		{
			Println(&huart1, "\ncmd 0x24, set index month: ");
			itoa(archiveIndexMonts, buf, 10);
			Println(&huart1, buf);
			Println(&huart1, ", current month: ");
			itoa(archiveArrMonts[archiveIndexMonts], buf, 10);
			Println(&huart1, buf);
		}
#endif
		break;

	case 0x11:		// 0x11, year bask0_front1
		if(param > archiveCntYears-1)		param = archiveCntYears-1;
		archiveIndexYears = param;
		for(cv=0; cv<ARCHIVE_PARAM_MAX; cv++)
		{ //
			if(archiveIndexYears+cv >= archiveCntYears)		break;
			else											*ptr_reg[ARCHIVE_INDEX+cv] = archiveArrYears[archiveIndexYears+cv];
		}
		value = archiveCntYears - param;
		value |= (flags << 9);
		*ptr_reg[ARCHIVE_INDEX-1] = value;		// write register
#ifdef _BUS_OUTPUT_UART
		if(debugMessage == MESSAGE_BUS)
		{
			Println(&huart1, "\ncmd 0x22, set index year: ");
			itoa(archiveIndexYears, buf, 10);
			Println(&huart1, buf);
			Println(&huart1, ", current year: 20");
			if(archiveArrYears[archiveIndexYears] < 10) Println(&huart1, "0");
			itoa(archiveArrYears[archiveIndexYears], buf, 10);
			Println(&huart1, buf);
		}
#endif
		break;

	case 0x18:		// 0x18, event bask0_front1
		if(param > ((archiveCntEvents/3)-1))		param = (archiveCntEvents/3)-1;
		archiveIndexEvents = param * 3;
		for(cv=0; cv<ARCHIVE_PARAM_MAX; cv++)
		{
			if(archiveIndexEvents+cv >= archiveCntEvents)		break;
			else												*ptr_reg[ARCHIVE_INDEX+cv] = archiveArrEvents[archiveIndexEvents+cv];
		}
		value = (archiveCntEvents/3) - param;
		value |= (flags << 9);
		*ptr_reg[ARCHIVE_INDEX-1] = value;		// write register
#ifdef _BUS_OUTPUT_UART
		if(debugMessage == MESSAGE_BUS)
		{
			Println(&huart1, "\ncmd 0x30, set index event");
		}
#endif
		break;

	case 0x40:
		Println(&huart1, "\nClear archive begin.");
		cv = ClearEEprom();
		Println(&huart1, "\nErrors clear: ");
		itoa(cv, buff, 10);
		Println(&huart1, buff);
		Println(&huart1, "\nClear archive end.");
		break;

	default:
		break;
	}
}

#ifdef _BUS_OUTPUT_UART
void ArchiveDebug(uint16_t year, uint16_t month, uint16_t day)
{
	uint16_t rez[256], cnt, cn;
	char     buf[32];

	if(debugMessage == MESSAGE_BUS)
	{
		cnt = ArchiveReadYears(rez, 32, archiveEeAddrPoint);
		if(cnt)
		{
			Println(&huart1, "\nyears: ");
			itoa(cnt, buf, 10);
			Println(&huart1, buf);
			for(cn=0; cn<cnt; cn++)
			{
				Println(&huart1, "\nyear[");
				itoa(cn, buf, 10);
				Println(&huart1, buf);
				Println(&huart1, "] = ");
				itoa(rez[cn], buf, 10);
				Println(&huart1, buf);
			}
			archiveYear = rez[0];
		}
		else
		{
			Println(&huart1, "\nnot years");
		}
		cnt = ArchiveReadMonts(rez, year, 32, archiveEeAddrPoint);
		if(cnt)
		{
			Println(&huart1, "\nfor year 20");
			itoa(year, buf, 10);
			Println(&huart1, buf);
			Println(&huart1, ", monts: ");

			itoa(cnt, buf, 10);
			Println(&huart1, buf);
			for(cn=0; cn<cnt; cn++)
			{
				Println(&huart1, "\n mont[");
				itoa(cn, buf, 10);
				Println(&huart1, buf);
				Println(&huart1, "] = ");
				itoa(rez[cn], buf, 10);
				Println(&huart1, buf);
			}
		}
		else
		{
			Println(&huart1, "\nnot monts in year 20");
			itoa(year, buf, 10);
			Println(&huart1, buf);
		}
		if(month)	cnt = ArchiveReadDays(rez, year, month, 32, archiveEeAddrPoint);
		else		cnt = 0;
		if(cnt)
		{
			Println(&huart1, "\nfor year 20");
			itoa(year, buf, 10);
			Println(&huart1, buf);
			Println(&huart1, ", monts ");
			itoa(month, buf, 10);
			Println(&huart1, buf);
			Println(&huart1, ", days ");

			itoa(cnt, buf, 10);
			Println(&huart1, buf);
			for(cn=0; cn<cnt; cn++)
			{
				Println(&huart1, "\n day[");
				itoa(cn, buf, 10);
				Println(&huart1, buf);
				Println(&huart1, "] = ");
				itoa(rez[cn], buf, 10);
				Println(&huart1, buf);
			}
		}
		else
		{
			Println(&huart1, "\nnot days in monts ");
			itoa(month, buf, 10);
			Println(&huart1, buf);
			Println(&huart1, " of year 20");
			itoa(year, buf, 10);
			Println(&huart1, buf);
		}
		if(day)		cnt = ArchiveReadEvents(rez, year, month, day, 250, archiveEeAddrPoint);
		else		cnt = 0;
		Println(&huart1, "\nfor year 20");
		itoa(year, buf, 10);
		Println(&huart1, buf);
		Println(&huart1, ", month ");
		itoa(month, buf, 10);
		Println(&huart1, buf);
		Println(&huart1, ", day ");
		itoa(day, buf, 10);
		Println(&huart1, buf);
		Println(&huart1, ", events: ");
		if(cnt)
		{
			uint8_t tmp;
			tmp = cnt/3;
			itoa(tmp, buf, 10);
			Println(&huart1, buf);
			for(cn=0; cn<cnt; cn+=3)
			{
				tmp = rez[cn] >> 8;
				Println(&huart1, "\n  ");
				itoa(tmp, buf, 10);
				if(strlen(buf) == 1)	Println(&huart1, "0");
				Println(&huart1, buf);
				Println(&huart1, ":");
				tmp = rez[cn] & 0xFF;
				itoa(tmp, buf, 10);
				if(strlen(buf) == 1)	Println(&huart1, "0");
				Println(&huart1, buf);
				tmp = rez[cn+1] >> 8;
				Println(&huart1, ", T*C:");
				itoa(tmp, buf, 10);
				Println(&huart1, buf);
				Println(&huart1, ", st:");
				tmp = rez[cn+1] & 0x0080;
				if(tmp)		Println(&huart1, "1-");
				else		Println(&huart1, "0-");
				tmp = rez[cn+1] & 0x007F;
				itoa(tmp, buf, 10);
				Println(&huart1, buf);
				Println(&huart1, ", Ubat:");
				tmp = rez[cn+2] >> 8;
				itoa(tmp, buf, 10);
				Println(&huart1, buf);
				Println(&huart1, ", Uin:");
				tmp = rez[cn+2] & 0xFF;
				itoa(tmp, buf, 10);
				Println(&huart1, buf);
			}
		}
		else
		{
			Println(&huart1, "\nnot events");
		}
	}
}
#endif

uint16_t ArchiveReadEvents(uint16_t *events, uint8_t year, uint8_t month, uint8_t day, uint16_t max_len, uint16_t dump_addr)
{
	uint16_t ci, cj, tval, yearmonday;
	uint8_t  val[ARCHIVE_MSG_LEN+1];

	yearmonday = (year << 9) | (month << 5) | day;
	cj = 0;
	for(ci=dump_addr; ci<MAX_ADDR; ci += ARCHIVE_MSG_LEN)
	{ // read primary value
		HAL_I2C_Mem_Read(&hi2c1, MEM_ADDR, ci, I2C_MEMADD_SIZE_16BIT, val, ARCHIVE_MSG_LEN, TIMEOUT_I2C);
		tval = (val[0] << 8) | val[1]; // ci
		if(yearmonday == tval)
		{
			events[cj++] = (val[2] << 8) | val[3];      // cj+1
			events[cj++] = (val[4] << 8) | val[5];      // cj+2
			events[cj++] = (val[6] << 8) | val[7];      // cj+3
			if(cj > max_len)	ci = MAX_ADDR;			// break, break
		}
	}
	return cj;
}

uint16_t ArchiveReadDays(uint16_t *days, uint8_t year, uint8_t month, uint8_t max_len, uint16_t dump_addr)
{ // days
	uint16_t ci, cj, cy, ck, tval, yearmon;
	uint8_t  val[ARCHIVE_MSG_LEN];

	yearmon = year * 512;
	yearmon = yearmon  | (month * 32);
	ck = 0;
	for(ci=dump_addr; ci<MAX_ADDR; ci += ARCHIVE_MSG_LEN)
	{ // read primary value
		HAL_I2C_Mem_Read(&hi2c1, MEM_ADDR, ci, I2C_MEMADD_SIZE_16BIT, val, ARCHIVE_MSG_LEN, TIMEOUT_I2C);
		tval = (val[0] << 8) | val[1]; // ci
		if(yearmon == (tval & 0xFFE0))
		{
			days[0] = tval & 0x001F;      // ci
			for(cj=1; cj<max_len; cj++)
			{
				days[cj] = 0;
				ck++;
			}
			ci = MAX_ADDR;
		}
	}
	if((ck) && (days[0] != 0))		cy = 1;
	else							return 0;
	for(ci=dump_addr; ci<MAX_ADDR; ci += ARCHIVE_MSG_LEN)
	{
		HAL_I2C_Mem_Read(&hi2c1, MEM_ADDR, ci, I2C_MEMADD_SIZE_16BIT, val, ARCHIVE_MSG_LEN, TIMEOUT_I2C);
		tval = (val[0] << 8) | val[1]; // ci
		if(yearmon == (tval & 0xFFE0))	 // val[0], val[1] - ci
		{
			tval = tval & 0x001F;          // ci
			ck = 0;
			for(cj=0; cj<cy; cj++)
			{
				if(days[cj] == tval)		ck++;
			}
			if(ck == 0)
			{
				days[cy++] = tval;
				if(cy > max_len)	break;
			}
			if(cy > max_len)	break;
		}
		if(cy > max_len)	break;
	}
	return cy;
}

uint16_t ArchiveReadMonts(uint16_t *monts, uint8_t year, uint8_t max_len, uint16_t dump_addr)
{ // years
	uint16_t ci, cj, cy, ck, tval;
	uint8_t  val[ARCHIVE_MSG_LEN];

	ck = 0;
	for(ci=dump_addr; ci<MAX_ADDR; ci += ARCHIVE_MSG_LEN)
	{ // read primary value
		HAL_I2C_Mem_Read(&hi2c1, MEM_ADDR, ci, I2C_MEMADD_SIZE_16BIT, val, ARCHIVE_MSG_LEN, TIMEOUT_I2C);
		tval = (val[0] << 8) | val[1]; // ci
		if(year == (tval >> 9))
		{ // store 1-st value, and clear array
			monts[0] = tval & 0xFFE0;      // ci
			for(cj=1; cj<max_len; cj++)
			{
				monts[cj] = 0;
				ck++;				// set indicator
			}
			ci = MAX_ADDR;	// break;
		}
	}
	if((ck)	&& (monts[0] != 0))	cy = 1;
	else						return 0;
	for(ci=dump_addr; ci<MAX_ADDR; ci += ARCHIVE_MSG_LEN)
	{
		HAL_I2C_Mem_Read(&hi2c1, MEM_ADDR, ci, I2C_MEMADD_SIZE_16BIT, val, ARCHIVE_MSG_LEN, TIMEOUT_I2C);
		tval = (val[0] << 8) | val[1]; // ci
		if(year == (tval >> 9))	 // val[0], val[1] - ci
		{
			tval = tval & 0xFFE0;          // ci
			ck = 0;
			for(cj=0; cj<cy; cj++)
			{
				if(monts[cj] == tval)		ck++;
			}
			if(ck == 0)
			{
				monts[cy++] = tval;
				if(cy > max_len)	break;
			}
			if(cy > max_len)	break;
		}
		if(cy > max_len)	break;
	}
	for(ci=0; ci<cy; ci++)
	{
		monts[ci] = monts[ci] >> 5;
		monts[ci] &= 0x000F;
	}
	return cy;
}

uint16_t ArchiveReadYears(uint16_t *years, uint8_t max_len, uint16_t dump_addr)
{ // years
	uint16_t ci, cj, cy, ck;
	uint8_t  val[ARCHIVE_MSG_LEN];

	ck = 0;
	for(ci=dump_addr; ci<MAX_ADDR; ci += ARCHIVE_MSG_LEN)
	{ // read primary value
		HAL_I2C_Mem_Read(&hi2c1, MEM_ADDR, ci, I2C_MEMADD_SIZE_16BIT, val, ARCHIVE_MSG_LEN, TIMEOUT_I2C);
		if(val[0] != 0xFF)
		{
			years[0] = val[0] >> 1; // ci
			for(cj=1; cj<max_len; cj++)
			{
				years[cj] = 0;
				ck++;
			}
			ci = MAX_ADDR;
		}
	}
	if(ck)		cy = 1;
	else		return 0;
	for(ci=dump_addr; ci<MAX_ADDR; ci += ARCHIVE_MSG_LEN)
	{
		HAL_I2C_Mem_Read(&hi2c1, MEM_ADDR, ci, I2C_MEMADD_SIZE_16BIT, val, ARCHIVE_MSG_LEN, TIMEOUT_I2C);
		if(val[0] != 0xFF)	 // val[0] - ci
		{
			ck = 0;
			for(cj=0; cj<cy; cj++)
			{
				if(years[cj] == (val[0] >> 1))		ck++;
			}
			if(ck == 0)
			{
				years[cy++] = val[0] >> 1;
				if(cy > max_len)	break;
			}
			if(cy > max_len)	break;
		}
		if(cy > max_len)	break;
	}
	return cy;
}

void InitArchive(void)
{
	InitEEPROM();
	archiveYear = 0;
	archiveMonth = 0;
	archiveDay = 0;
	archiveIndexYears = 0;
	archiveIndexMonts = 0;
	archiveIndexDays = 0;
	archiveIndexEvents = 0;
	archiveCntYears = 0;
	archiveCntMonts = 0;
	archiveCntDays = 0;
	archiveCntEvents = 0;
	memset(archiveArrYears, 0, sizeof(archiveArrYears));
	memset(archiveArrMonts, 0, sizeof(archiveArrMonts));
	memset(archiveArrDays, 0, sizeof(archiveArrDays));
	memset(archiveArrEvents, 0, sizeof(archiveArrEvents));
}

void InitEEPROM(void)
{
	uint8_t buf[8];
	uint16_t ee_addr;

	HAL_I2C_Mem_Read(&hi2c1, MEM_ADDR, CURR_ADDR, I2C_MEMADD_SIZE_16BIT, buf, 2, TIMEOUT_I2C);
	ee_addr = buf[0] << 8;
	ee_addr |= buf[1];
	if(ee_addr > MAX_ADDR)	ee_addr = MAX_ADDR;
	ClockRAM.config.eeAddress = ee_addr;
}

void NextAddrEEPROM(void)
{
	uint8_t buf[4];

	if(ClockRAM.config.eeAddress >= ARCHIVE_MSG_LEN)  ClockRAM.config.eeAddress -= ARCHIVE_MSG_LEN;
	else											  ClockRAM.config.eeAddress = MAX_ADDR;
	buf[0] = (uint8_t)(ClockRAM.config.eeAddress >> 8);
	buf[1] = (uint8_t)ClockRAM.config.eeAddress;
	HAL_I2C_Mem_Write(&hi2c1, MEM_ADDR, CURR_ADDR, I2C_MEMADD_SIZE_16BIT, buf, 2, TIMEOUT_I2C);
	HAL_Delay(TIMEOUT_I2C);
}

uint16_t ClearEEprom(void)
{ // ret-0 clear ok, ret-n clear error
	uint16_t result, addr;
	uint8_t  buf[32], read[32];

	result = 0;
	addr = 0;
	memset(buf, 0xFF, 32);

	while(addr < MAX_ADDR)
	{
		HAL_I2C_Mem_Write(&hi2c1, MEM_ADDR, addr, I2C_MEMADD_SIZE_16BIT, buf, 32, TIMEOUT_I2C);
		HAL_Delay(TIMEOUT_I2C);
		HAL_I2C_Mem_Read(&hi2c1, MEM_ADDR, addr, I2C_MEMADD_SIZE_16BIT, read, 32, TIMEOUT_I2C);
		if(memcmp(buf, read, 32))		result++;
		addr += 32;
	}
	buf[0] = (uint8_t)(MAX_ADDR >> 8);
	buf[1] = (uint8_t)MAX_ADDR;
	ClockRAM.config.eeAddress = MAX_ADDR;
	HAL_I2C_Mem_Write(&hi2c1, MEM_ADDR, CURR_ADDR, I2C_MEMADD_SIZE_16BIT, buf, 2, TIMEOUT_I2C);
	HAL_Delay(TIMEOUT_I2C);
	return result;
}

uint16_t CalculateCRC16(uint8_t * line, uint8_t len)
{
    uint8_t  i, j, tmp;
    uint16_t CRC16;

    CRC16 = 0xFFFF; // CRC - начальное значение
    for (i = 0; i < len; i++)
    {
        CRC16 ^= line[i];
        for (j = 0; j < 8; j++)
        {
            tmp = (uint8_t)(CRC16 & 0x0001);
            CRC16 >>= 1;
            if (tmp == 1)
            {
                CRC16 ^= 0xA001; // тоже или полиномиальный
            }
        }
    }
    line[i++] = CRC16;
    line[i++] = (CRC16 >> 8);
	return CRC16;
}

void SetInputName(uint8_t *name)
{ // from registers to input N
	name[0] = InputCmd.InputName1 & 0xFF;
	name[1] = InputCmd.InputName1 >> 8;
	name[2] = InputCmd.InputName2 & 0xFF;
	name[3] = InputCmd.InputName2 >> 8;
	name[4] = InputCmd.InputName3 & 0xFF;
	name[5] = InputCmd.InputName3 >> 8;
	name[6] = InputCmd.InputName4 & 0xFF;
	name[7] = InputCmd.InputName4 >> 8;
	name[8] = InputCmd.InputName5 & 0xFF;
	name[9] = InputCmd.InputName5 >> 8;
	name[10] = InputCmd.InputName6 & 0xFF;
	name[11] = InputCmd.InputName6 >> 8;
	name[12] = InputCmd.InputName7 & 0xFF;
	name[13] = InputCmd.InputName7 >> 8;
	name[14] = InputCmd.InputName8 & 0xFF;
	name[15] = InputCmd.InputName8 >> 8;
	name[16] = InputCmd.InputName9 & 0xFF;
	name[17] = InputCmd.InputName9 >> 8;
	name[18] = InputCmd.InputName10 & 0xFF;
	name[19] = InputCmd.InputName10 >> 8;
}

void GetInputName(uint8_t *name)
{ // from input N to registers
	InputCmd.InputName1 = name[1] << 8;
	InputCmd.InputName1 |= name[0];
	InputCmd.InputName2 = name[3] << 8;
	InputCmd.InputName2 |= name[2];
	InputCmd.InputName3 = name[5] << 8;
	InputCmd.InputName3 |= name[4];
	InputCmd.InputName4 = name[7] << 8;
	InputCmd.InputName4 |= name[6];
	InputCmd.InputName5 = name[9] << 8;
	InputCmd.InputName5 |= name[8];
	InputCmd.InputName6 = name[11] << 8;
	InputCmd.InputName6 |= name[10];
	InputCmd.InputName7 = name[13] << 8;
	InputCmd.InputName7 |= name[12];
	InputCmd.InputName8 = name[15] << 8;
	InputCmd.InputName8 |= name[14];
	InputCmd.InputName9 = name[17] << 8;
	InputCmd.InputName9 |= name[16];
	InputCmd.InputName10 = name[19] << 8;
	InputCmd.InputName10 |= name[18];
}

void SetOutputName(uint8_t *name)
{ // from registers to output N
	name[0] = OutputCmd.OutputName1 & 0xFF;
	name[1] = OutputCmd.OutputName1 >> 8;
	name[2] = OutputCmd.OutputName2 & 0xFF;
	name[3] = OutputCmd.OutputName2 >> 8;
	name[4] = OutputCmd.OutputName3 & 0xFF;
	name[5] = OutputCmd.OutputName3 >> 8;
	name[6] = OutputCmd.OutputName4 & 0xFF;
	name[7] = OutputCmd.OutputName4 >> 8;
	name[8] = OutputCmd.OutputName5 & 0xFF;
	name[9] = OutputCmd.OutputName5 >> 8;
}

void GetOutputName(uint8_t *name)
{ // from output N to registers
	OutputCmd.OutputName1 = name[1] << 8;
	OutputCmd.OutputName1 |= name[0];
	OutputCmd.OutputName2 = name[3] << 8;
	OutputCmd.OutputName2 |= name[2];
	OutputCmd.OutputName3 = name[5] << 8;
	OutputCmd.OutputName3 |= name[4];
	OutputCmd.OutputName4 = name[7] << 8;
	OutputCmd.OutputName4 |= name[6];
	OutputCmd.OutputName5 = name[9] << 8;
	OutputCmd.OutputName5 |= name[8];
}

void USART1_Init(uint32_t speed, uint32_t dt, uint32_t stop, uint32_t parity)
{ // speed, data, stop, parity
	huart1.Instance = USART1;
	huart1.Init.BaudRate = speed;
	huart1.Init.WordLength = dt;
	huart1.Init.Parity = parity;
	huart1.Init.StopBits = stop;
	huart1.Init.Mode = UART_MODE_TX_RX;
	huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
	huart1.Init.OverSampling = UART_OVERSAMPLING_16;
	huart1.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
	huart1.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
	if (HAL_UART_Init(&huart1) != HAL_OK)
	{
		errorInitUART1++;
		Error_Handler();
		return;
	}

	errorInitUART1 = 0;
	USART1->CR1 |= USART_CR1_RXNEIE;
	UART_1.input_buff[0] = USART1->RDR;
	HAL_GPIO_WritePin(DIR1_GPIO_Port, DIR1_Pin, GPIO_PIN_RESET);

	WaitPeriod = (uint16_t)(WAIT_BASE / speed / 100);
	if(WaitPeriod < WAIT_PERIOD_MIN)		WaitPeriod = WAIT_PERIOD_MIN;

	UART_1.cntReceive = 0;
	UART_1.dataReady = 0;
	UART_1.dataOver = 0;
	UART_1.waitTimer = 0;
	UART_1.cntTestLine = TEST_LINE_TIME;
	UART_1.tstLine = 0;
}

void USART2_Init(uint32_t speed, uint32_t dt, uint32_t stop, uint32_t parity)
{ // speed, data, stop, parity
	huart2.Instance = USART2;
	huart2.Init.BaudRate = speed;
	huart2.Init.WordLength = dt;
	huart2.Init.Parity = parity;
	huart2.Init.StopBits = stop;
	huart2.Init.Mode = UART_MODE_TX_RX;
	huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
	huart2.Init.OverSampling = UART_OVERSAMPLING_16;
	huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
	huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
	if (HAL_UART_Init(&huart2) != HAL_OK)
	{
		errorInitUART2++;
	    Error_Handler();
	    return;
	}

	errorInitUART2 = 0;
	USART2->CR1 |= USART_CR1_RXNEIE;
	UART_2.input_buff[0] = USART2->RDR;
	HAL_GPIO_WritePin(DIR2_GPIO_Port, DIR2_Pin, GPIO_PIN_RESET);

	WaitPeriod = (uint16_t)(WAIT_BASE / speed / 100);
	if(WaitPeriod < WAIT_PERIOD_MIN)		WaitPeriod = WAIT_PERIOD_MIN;

	UART_2.cntReceive = 0;
	UART_2.dataReady = 0;
	UART_2.dataOver = 0;
	UART_2.waitTimer = 0;
	UART_2.cntTestLine = TEST_LINE_TIME;
	UART_2.tstLine = 0;
}

void USART3_Init(void)
{
	  huart3.Instance = USART3;
	  huart3.Init.BaudRate = DEFAULT_BAUD_RATE * 100;
	  huart3.Init.WordLength = UART_WORDLENGTH_8B;
	  huart3.Init.StopBits = UART_STOPBITS_1;
	  huart3.Init.Parity = UART_PARITY_NONE;
	  huart3.Init.Mode = UART_MODE_TX_RX;
	  huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;
	  huart3.Init.OverSampling = UART_OVERSAMPLING_16;
	  huart3.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
	  huart3.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
	  if (HAL_UART_Init(&huart3) != HAL_OK)
	  {
	    Error_Handler();
	  }

	USART3->CR1 |= USART_CR1_RXNEIE;
	UART_3.input_buff[0] = USART3->RDR;

	WaitPeriod = (uint16_t)(WAIT_BASE / DevNVRAM.config.BaudRate);
	if(WaitPeriod < WAIT_PERIOD_MIN)		WaitPeriod = WAIT_PERIOD_MIN;

	UART_3.cntReceive = 0;
	UART_3.dataReady = 0;
	UART_3.dataOver = 0;
	UART_3.waitTimer = 0;
	UART_3.cntTestLine = TEST_LINE_TIME;
	UART_3.tstLine = 1;			// for PI382
}

void Ports_1_2_ReInit(void)
{
	uint32_t speed;
	uint32_t dt;
	uint32_t stop;
	uint32_t parity;

	oldSpeed = DevNVRAM.config.BaudRate;
	oldParam = DevNVRAM.config.BitsConfig;
	speed = oldSpeed * 100;
	dt = oldParam & 0x0003;
	stop = (oldParam >> 2) & 0x0003;
	parity = (oldParam >> 4) & 0x0003;
	HAL_UART_DeInit(&huart2);
	USART2_Init(speed, bitsData[dt], bitsStop[stop], bitsParity[parity]);
	HAL_UART_DeInit(&huart1);
	USART1_Init(speed, bitsData[dt], bitsStop[stop], bitsParity[parity]);
#ifdef _BUS_OUTPUT_UART
	if(debugMessage == MESSAGE_BUS)
	{
		Println(&huart1, "\nset new ports settings");
		Println(&huart1, "\nspeed: ");
		itoa(speed, buff, 10);
		Println(&huart1, buff);
		Println(&huart1, " bod, param: 0x");
		itoa(oldParam, buff, 16);
		Println(&huart1, buff);
		Println(&huart1, ", data - ");
		itoa(dt, buff, 10);
		Println(&huart1, buff);
		Println(&huart1, ", stop - ");
		itoa(stop, buff, 10);
		Println(&huart1, buff);
		Println(&huart1, ", parity -");
		itoa(parity, buff, 10);
		Println(&huart1, buff);
		itoa(errorInitUART1, buff, 10);
		Println(&huart1, "\nerrorInitUART1: ");
		Println(&huart1, buff);
		itoa(errorInitUART2, buff, 10);
		Println(&huart1, ", errorInitUART2: ");
		Println(&huart1, buff);
	}
#endif
}

uint16_t CheckBaudRate(uint16_t speed)
{
	if(speed == baudRates[0])			return baudRates[0];	//  4800	0x0030
	else if(speed == baudRates[1])		return baudRates[1];	//	9600	0x0060
	else if(speed == baudRates[2])		return baudRates[2];	//  19200	0x00C0
	else if(speed == baudRates[3])		return baudRates[3];	//	38400	0x0180
	else if(speed == baudRates[4])		return baudRates[4];	//	57600	0x0240
	else if(speed == baudRates[5])		return baudRates[5];	//	115200	0x0480
	else								return baudRates[1];	//	9600	0x0060
}

/// debug function
#ifdef _BUS_OUTPUT_UART
void TestStatus01(void)
{
	if(regState != ClockRAM.config.status_PP380)
	{
		regState = ClockRAM.config.status_PP380;
		Println(&huart1, "\nchange status, new value: 0x");
		itoa(regState, buff,16);
		Println(&huart1, buff);
	}
}
#endif

void IndexingRegisters(void)
{
	ClockRAM.config.status_PP380 = 0;
	ClockRAM.config.status_PP380 &= INIT_STATUS;
	ptr_reg[0] = &ClockRAM.config.Rezerv;
	ptr_reg[1] = &ClockRAM.config.status_PP380;
	ptr_reg[2] = &ClockRAM.config.di1_PP380;
	ptr_reg[3] = &ClockRAM.config.di2_PP380;
	ptr_reg[4] = &ClockRAM.config.dim1_PP380;
	ptr_reg[5] = &ClockRAM.config.dim2_PP380;
	ptr_reg[6] = &ClockRAM.config.Temperature;
	ptr_reg[7] = &ClockRAM.config.u_input;
	ptr_reg[8] = &ClockRAM.config.u_battery;
	ptr_reg[9] = &ClockRAM.config.output_switch_PP380;
	ptr_reg[10] = &ClockRAM.config.time_PP380;
	ptr_reg[11] = &ClockRAM.config.date_PP380;
	ptr_reg[12] = &ClockRAM.config.alarm_cmd;
	ptr_reg[13] = &DevNVRAM.config.AlarmParam1;
	ptr_reg[14] = &DevNVRAM.config.AlarmParam2;
	ptr_reg[15] = &DevNVRAM.config.AlarmParam3;
	ptr_reg[16] = &ClockRAM.config.battery_state;
	ptr_reg[17] = &DevNVRAM.config.VoltageBatteryFull;
	ptr_reg[18] = &DevNVRAM.config.VoltageBatteryCharge;
	ptr_reg[19] = &DevNVRAM.config.VoltageBatteryDischarge;
	ptr_reg[20] = &DevNVRAM.config.VoltageBatteryOff;
	ptr_reg[21] = &DevNVRAM.config.VoltageBatteryGood;
	ptr_reg[22] = &DevNVRAM.config.VoltageBatteryFault;
	ptr_reg[23] = &DevNVRAM.config.TimeBatteryPrecharge;
	ptr_reg[24] = &DevNVRAM.config.TimeBatteryTest;
	ptr_reg[25] = &DevNVRAM.config.TimeBatteryCheck;
	ptr_reg[26] = &DevNVRAM.config.TimeBatteryLimit;
	ptr_reg[27] = &DevNVRAM.config.TimeBatteryHealth;
	ptr_reg[28] = &DevNVRAM.config.PrechargeCycles;
	ptr_reg[29] = &DevNVRAM.config.VersionPP380;
	ptr_reg[30] = &DevNVRAM.config.DeviceType;
	ptr_reg[31] = &DevNVRAM.config.ReleaseDate;
	ptr_reg[32] = &DevNVRAM.config.SerialNumber1;
	ptr_reg[33] = &DevNVRAM.config.SerialNumber2;
	ptr_reg[34] = &DevNVRAM.sector.cntWrite;
	ptr_reg[35] = &InputCmd.InputsCMD;
	ptr_reg[36] = &InputCmd.InputsState;
	ptr_reg[37] = &InputCmd.InputDelay;
	ptr_reg[38] = &InputCmd.InputName1;
	ptr_reg[39] = &InputCmd.InputName2;
	ptr_reg[40] = &InputCmd.InputName3;
	ptr_reg[41] = &InputCmd.InputName4;
	ptr_reg[42] = &InputCmd.InputName5;
	ptr_reg[43] = &InputCmd.InputName6;
	ptr_reg[44] = &InputCmd.InputName7;
	ptr_reg[45] = &InputCmd.InputName8;
	ptr_reg[46] = &InputCmd.InputName9;
	ptr_reg[47] = &InputCmd.InputName10;
	ptr_reg[48] = &DevNVRAM.config.LowTemperature;
	ptr_reg[49] = &DevNVRAM.config.LowHysteresys;
	ptr_reg[50] = &DevNVRAM.config.HighTemperature;
	ptr_reg[51] = &DevNVRAM.config.HighHysteresis;
	ptr_reg[52] = &DevNVRAM.config.FaultControl;
	ptr_reg[53] = &DevNVRAM.config.DelayNetSensor;
	ptr_reg[54] = &DevNVRAM.config.VoltageLevelInput;
	ptr_reg[55] = &DevNVRAM.config.VoltageInputHysteresis;
	ptr_reg[56] = &DevNVRAM.config.VoltageLevelBattery;
	ptr_reg[57] = &DevNVRAM.config.VoltageBatteryHysteresis;
	ptr_reg[58] = &OutputCmd.OutputsCMD;
	ptr_reg[59] = &OutputCmd.OutputState;
	ptr_reg[60] = &OutputCmd.OutputName1;
	ptr_reg[61] = &OutputCmd.OutputName2;
	ptr_reg[62] = &OutputCmd.OutputName3;
	ptr_reg[63] = &OutputCmd.OutputName4;
	ptr_reg[64] = &OutputCmd.OutputName5;
	ptr_reg[65] = &OutputCmd.OutputType;
	ptr_reg[66] = &OutputCmd.OutputMask0_15;
	ptr_reg[67] = &OutputCmd.OutputMask16_31;
	ptr_reg[68] = &OutputCmd.OutputMask32_47;
	ptr_reg[69] = &ClockRAM.config.LineTest;
	ptr_reg[70] = &DevNVRAM.config.AddressPP380;
	ptr_reg[71] = &DevNVRAM.config.BaudRate;
	ptr_reg[72] = &DevNVRAM.config.BitsConfig;
	ptr_reg[73] = &ArchiveCmd.ArchiveCMD;
	ptr_reg[74] = &ArchiveCmd.ArchiveParam1;
	ptr_reg[75] = &ArchiveCmd.ArchiveParam2;
	ptr_reg[76] = &ArchiveCmd.ArchiveParam3;
	ptr_reg[77] = &ArchiveCmd.ArchiveParam4;
	ptr_reg[78] = &ArchiveCmd.ArchiveParam5;
	ptr_reg[79] = &ArchiveCmd.ArchiveParam6;
	ptr_reg[80] = &ArchiveCmd.ArchiveParam7;
	ptr_reg[81] = &ArchiveCmd.ArchiveParam8;
	ptr_reg[82] = &ArchiveCmd.ArchiveParam9;
	ptr_reg[83] = &ArchiveCmd.ArchiveParam10;
	ptr_reg[84] = &ArchiveCmd.ArchiveParam11;
	ptr_reg[85] = &ArchiveCmd.ArchiveParam12;
	ptr_reg[86] = &ArchiveCmd.ArchiveParam13;
	ptr_reg[87] = &ArchiveCmd.ArchiveParam14;
	ptr_reg[88] = &ArchiveCmd.ArchiveParam15;
	ptr_reg[89] = &ArchiveCmd.ArchiveParam16;
	ptr_reg[90] = &ArchiveCmd.ArchiveParam17;
	ptr_reg[91] = &ArchiveCmd.ArchiveParam18;
	ptr_reg[92] = &ClockRAM.config.Rezerv;
	sequenceCmd[0] = 0;                           // flag sequence = 0;
}


