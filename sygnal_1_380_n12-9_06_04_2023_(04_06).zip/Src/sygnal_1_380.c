#include <stdlib.h>
#include "main.h"
#include "string.h"
#include "sygnal_1_380.h"
#include "sygnal_1_380_zu.h"
#include "sygnal_1_380_bus.h"

ohrFlags ohrLedFlags;
ohrFlags ohrBuzzerFlags;
extern char buff[8];

void Initialize(void)
{
    Sygnalization(SYGNAL_MODE_OFF);
    countAlarmCycles = 0;
    timerAlarm = 0;
    waitAlarm = 0;
    BeginOhr();
#ifdef _SECURITY_OUTPUT_UART
    Println(&huart1, "\nHello Sygnal_1_380!");
#endif
}

void BeginOhr(void)
{
	switch(ClockRAM.config.alarm_cmd)
	{
		case 0x21:
		ohrState = OHR_GO_ALARM;
		break;

		default:
		ohrState = OHR_GO_ACTIVE;
		break;
	}
	oldControlPin = HAL_GPIO_ReadPin(SEC_GPIO_Port, SEC_Pin);
#ifdef _SECURITY_OUTPUT_UART
	if(ReadControlOhr() == CONTROL_OHR_ACTIVE)
	{
		Println(&huart1, "\nSecurity control ACTIVE.");
	}
	else
	{
		Println(&huart1, "\nSecurity control OFF.");
	}
	if(ReadSensorOhr() == SENSOR_OHR_OPEN)
	{
		Println(&huart1, "\nSecurity door is open.");
	}
	else
	{
		Println(&huart1, "\nSecurity door is close.");
	}
#endif
}

void RunOhr(void)
{
	switch(ohrState)
	{

	case OHR_ALARM:
		ClockRAM.config.alarm_cmd &= 0x0001;
		BIT_SET(ClockRAM.config.alarm_cmd, 5);		// 5 - trevoga
		BIT_SET(ClockRAM.config.di1_PP380, 7);		// 7 - trevoga in register
		if(timerAlarm)	timerAlarm--;
		if(timerAlarm == 1)
		{
			countAlarmCycles++;
#ifdef _SECURITY_OUTPUT_UART
			Println(&huart1, "\nCount alarm cycles: ");
			itoa(countAlarmCycles, buff, 10);
			Println(&huart1, buff);
#endif
			if(countAlarmCycles > 50000)	countAlarmCycles = 50000;
			if(countAlarmCycles == DevNVRAM.config.AlarmParam3)
			{
				Sygnalization(SYGNAL_MODE_LEDI3_BUZ0);
#ifdef _SECURITY_OUTPUT_UART
				Println(&huart1, "\nBuzzer OFF.");
#endif
			}
			if(ReadSensorOhr() == SENSOR_OHR_OPEN)
			{
				timerAlarm = DevNVRAM.config.AlarmParam2;
			}
			if(ReadSensorOhr() == SENSOR_OHR_CLOSE)
			{
				timerAlarm = 0;
				ohrState = OHR_GO_ACTIVE;
			}
		}
		if(ReadControlOhr() == CONTROL_OHR_OFF)
		{
			ohrState = OHR_GO_OFF;
			countAlarmCycles = 0;
			timerAlarm = 0;
		}
		break;

	case OHR_GO_ALARM:
		timerAlarm = DevNVRAM.config.AlarmParam2;
		Sygnalization(SYGNAL_MODE_LEDI3_BUZ0);
		ohrState = OHR_ALARM;
#ifdef _SECURITY_OUTPUT_UART
		Println(&huart1, "\nSecurity OHR_GO_ALARM.");
#endif
		break;

	case OHR_ACTIVE:
		ClockRAM.config.alarm_cmd &= 0x0001;
		BIT_SET(ClockRAM.config.alarm_cmd, 3);		// 3 - ohrana
		if(BIT_TEST(ClockRAM.config.di1_PP380, 7))
		{	// 7 - trevoga in register
			BIT_CLR(ClockRAM.config.di1_PP380, 7);		// 7 - trevoga in register
			BIT_SET(ClockRAM.config.dim1_PP380, 7);		// 7 - trevoga in register
		}
		if(ReadControlOhr() == CONTROL_OHR_OFF)
		{
			ohrState = OHR_GO_OFF;
		}
		if(ReadControlOhr() == CONTROL_OHR_ACTIVE)
		{
			if(ReadSensorOhr() == SENSOR_OHR_OPEN)
			{
				Sygnalization(SYGNAL_MODE_LEDI2_BUZI2);
				ohrState = OHR_WAIT_ALARM;
				waitAlarm = DevNVRAM.config.AlarmParam1;
#ifdef _SECURITY_OUTPUT_UART
				Println(&huart1, "\nSecurity OHR_WAIT_ALARM.");
#endif
			}
		}
		break;

	case OHR_GO_ACTIVE:
		Sygnalization(SYGNAL_MODE_LED1_BUZ0);
		ohrState = OHR_ACTIVE;
		countAlarmCycles = 0;
#ifdef _SECURITY_OUTPUT_UART
		Println(&huart1, "\nSecurity OHR_GO_ACTIVE.");
#endif
		break;

	case OHR_WAIT_ALARM:
		ClockRAM.config.alarm_cmd &= 0x0001;
		BIT_SET(ClockRAM.config.alarm_cmd, 4);		// 4 - snyatie s ohrany
		if(BIT_TEST(ClockRAM.config.di1_PP380, 7))
		{	// 7 - trevoga in register
			BIT_CLR(ClockRAM.config.di1_PP380, 7);		// 7 - trevoga in register
			BIT_SET(ClockRAM.config.dim1_PP380, 7);		// 7 - trevoga in register
		}
		if(waitAlarm)	waitAlarm--;
		if(waitAlarm == 1)
		{
			waitAlarm = 0;
			ohrState = OHR_GO_ALARM;
		}
		if(ReadControlOhr() == CONTROL_OHR_OFF)
		{
			waitAlarm = 0;
			ohrState = OHR_GO_OFF;
		}
		break;

	case OHR_OFF:
		ClockRAM.config.alarm_cmd &= 0x0001;
		BIT_SET(ClockRAM.config.alarm_cmd, 1);		// 1 - snyato
		if(BIT_TEST(ClockRAM.config.di1_PP380, 7))
		{	// 7 - trevoga in register
			BIT_CLR(ClockRAM.config.di1_PP380, 7);		// 7 - trevoga in register
			BIT_SET(ClockRAM.config.dim1_PP380, 7);		// 7 - trevoga in register
		}
		if(ReadControlOhr() == CONTROL_OHR_ACTIVE)
		{
			Sygnalization(SYGNAL_MODE_LEDI1_BUZI1);
			ohrState = OHR_WAIT_SENSOR_OPEN;
#ifdef _SECURITY_OUTPUT_UART
			Println(&huart1, "\nSecurity OHR_WAIT_SENSOR_OPEN.");
#endif
		}
		break;

	case OHR_GO_OFF:
		ohrState = OHR_OFF;
		Sygnalization(SYGNAL_MODE_OFF);
#ifdef _SECURITY_OUTPUT_UART
		Println(&huart1, "\nSecurity OHR_GO_OFF.");
#endif
		break;

	case OHR_WAIT_SENSOR_OPEN:
		ClockRAM.config.alarm_cmd &= 0x0001;
		BIT_SET(ClockRAM.config.alarm_cmd, 2);		// 2 - postanovka
		if(BIT_TEST(ClockRAM.config.di1_PP380, 7))
		{	// 7 - trevoga in register
			BIT_CLR(ClockRAM.config.di1_PP380, 7);		// 7 - trevoga in register
			BIT_SET(ClockRAM.config.dim1_PP380, 7);		// 7 - trevoga in register
		}
		if(ReadSensorOhr() == SENSOR_OHR_OPEN)
		{
			ohrState = OHR_WAIT_SENSOR_CLOSE;
#ifdef _SECURITY_OUTPUT_UART
			Println(&huart1, "\nSecurity OHR_WAIT_SENSOR_CLOSE.");
#endif
		}
		if(ReadControlOhr() == CONTROL_OHR_OFF)
		{
			ohrState = OHR_GO_OFF;
		}
		break;

	case OHR_WAIT_SENSOR_CLOSE:
		ClockRAM.config.alarm_cmd &= 0x0001;
		BIT_SET(ClockRAM.config.alarm_cmd, 2);		// 2 - postanovka
		if(BIT_TEST(ClockRAM.config.di1_PP380, 7))
		{	// 7 - trevoga in register
			BIT_CLR(ClockRAM.config.di1_PP380, 7);		// 7 - trevoga in register
			BIT_SET(ClockRAM.config.dim1_PP380, 7);		// 7 - trevoga in register
		}
		if(ReadSensorOhr() == SENSOR_OHR_CLOSE)
		{
			ohrState = OHR_GO_ACTIVE;
		}
		if(ReadControlOhr() == CONTROL_OHR_OFF)
		{
			ohrState = OHR_GO_OFF;
		}
		break;

	default:
		break;
	}
}

void Sygnalization(int mode)
{
	switch(mode)
	{
	case SYGNAL_MODE_LEDI1_BUZI1:
		ohrLedFlags.stepCount = PULSE_1_OHR;
		ohrBuzzerFlags.stepCount = PULSE_1_OHR;
		ohrLedFlags.inUse = 1;	     // on led
		ohrBuzzerFlags.inUse = 1;	 // on buzzer
		sygnalisationMode--;
		break;

	case SYGNAL_MODE_LED1_BUZ0:
		ohrLedFlags.stepCount = ALWAYS_ON_OHR;
		ohrLedFlags.inUse = 1;	     // on led
		ohrBuzzerFlags.inUse = 0;	 // off buzzer
		sygnalisationMode--;
		break;

	case SYGNAL_MODE_LEDI2_BUZI2:
		ohrLedFlags.stepCount = PULSE_2_OHR;
		ohrLedFlags.countCycles = COUNT_CYCLES_P2;		// begin cycles
		ohrBuzzerFlags.stepCount = PULSE_2_OHR;
		ohrBuzzerFlags.countCycles = COUNT_CYCLES_P2;		// begin cycles
		ohrLedFlags.inUse = 1;	     // on led
		ohrBuzzerFlags.inUse = 1;	 // on buzzer
		sygnalisationMode--;
		break;

	case SYGNAL_MODE_LEDI3_BUZ1:
		ohrLedFlags.stepCount = PULSE_3_OHR;
		ohrBuzzerFlags.stepCount = ALWAYS_ON_OHR;
		ohrLedFlags.inUse = 1;	     // on led
		ohrBuzzerFlags.inUse = 1;	 // on buzzer
		sygnalisationMode--;
		break;

	case SYGNAL_MODE_LEDI3_BUZ0:
		ohrLedFlags.stepCount = PULSE_3_OHR;
		ohrLedFlags.inUse = 1;	     // on led
		ohrBuzzerFlags.inUse = 0;	 // off buzzer
		sygnalisationMode--;
		break;

	case SYGNAL_MODE_OFF:
		ohrLedFlags.inUse = 0;	     // off sygnalisation
		ohrBuzzerFlags.inUse = 0;
		break;

	default:
		break;
	}
}

void Event_10ms(void)
{ // 10 mSec timer
	if(beginInputFlag == FALSE)					return;
//***********************  LED  **********************************//
	if(ohrLedFlags.inUse == 1)
	{
		switch(ohrLedFlags.stepCount)
		{
		case ALWAYS_ON_OHR:
			SetLedOhr(LED_PIN_ON);
			ohrLedFlags.stepCount = ALWAYS_ON_OHR;
			break;

////////////////// PULSE 1 RUNNING  ////////////////////////////
		case PULSE_1_OHR: // on led 1st, set time counter on led
			SetLedOhr(LED_PIN_ON);
			ohrLedFlags.countPause = COUNT_LED_ON_P1;
			ohrLedFlags.stepCount--;
			break;

		case (PULSE_1_OHR-1):	// wait on led, 9
			if(ohrLedFlags.countPause)	ohrLedFlags.countPause--;
			if(ohrLedFlags.countPause == 0)
			{						// off led 1st, set time counter off led
				SetLedOhr(LED_PIN_OFF);
				ohrLedFlags.countPause = COUNT_LED_OFF_P1;
				ohrLedFlags.stepCount--;
			}
			break;

		case (PULSE_1_OHR-2):			// wait off led 1st, 8
			if(ohrLedFlags.countPause)	ohrLedFlags.countPause--;
			if(ohrLedFlags.countPause == 0)
			{
				SetLedOhr(LED_PIN_ON);	 // on led 2st, set time counter on led
				ohrLedFlags.countPause = COUNT_LED_ON_P1;
				ohrLedFlags.stepCount--;
			}
			break;

		case (PULSE_1_OHR-3): 			// wait on led 2st, 7
			if(ohrLedFlags.countPause)	ohrLedFlags.countPause--;
			if(ohrLedFlags.countPause == 0)
			{							// off led 2st, set time counter off led
				SetLedOhr(LED_PIN_OFF);
				ohrLedFlags.countPause = COUNT_PAUSE_P1;
				ohrLedFlags.stepCount--;
			}
			break;

		case (PULSE_1_OHR-4):			// wait off led 2st, 6
			if(ohrLedFlags.countPause)	ohrLedFlags.countPause--;
			if(ohrLedFlags.countPause == 0)
			{
				ohrLedFlags.stepCount--;
			}
			break;

		case (PULSE_1_OHR-5): 			// end pulse and next pulse, 5
			ohrLedFlags.stepCount = PULSE_1_OHR;
			break;

////////////////// END OF PULSE 1 RUNNING  ////////////////////////////

////////////////// PULSE 2 RUNNING  ////////////////////////////
		case PULSE_2_OHR: //
			SetLedOhr(LED_PIN_ON);  // on led 1st, set time count on led
			ohrLedFlags.countPause = COUNT_LED_ON_P2;
			ohrLedFlags.stepCount--;
			break;

		case (PULSE_2_OHR-1):	// wait on led 1st, 19
			if(ohrLedFlags.countPause)	ohrLedFlags.countPause--;
			if(ohrLedFlags.countPause == 0)
			{						// off led 1st, set time counter off led
				SetLedOhr(LED_PIN_OFF);
				ohrLedFlags.countPause = COUNT_LED_OFF_P2;
				ohrLedFlags.stepCount--;
			}
			break;

		case (PULSE_2_OHR-2):	// wait off led 1st, 18
			if(ohrLedFlags.countPause)	ohrLedFlags.countPause--;
			if(ohrLedFlags.countPause == 0)
			{						// on led 2st, set time counter on led
				SetLedOhr(LED_PIN_ON);
				ohrLedFlags.countPause = COUNT_LED_ON_P2;
				ohrLedFlags.stepCount--;
			}
			break;

		case (PULSE_2_OHR-3):	// wait on led 2st, 17
			if(ohrLedFlags.countPause)	ohrLedFlags.countPause--;
			if(ohrLedFlags.countPause == 0)
			{						// off led 2st, set time counter off led
				SetLedOhr(LED_PIN_OFF);
				delay_tmp = COUNT_PAUSE_P2;
				delay_tmp -= (DELTA_PAUSE_SHORT_P2 * (COUNT_CYCLES_P2 - ohrLedFlags.countCycles));
				if(delay_tmp < COUNT_LED_OFF_P2)	delay_tmp = COUNT_LED_OFF_P2;
				ohrLedFlags.countPause = delay_tmp;
				ohrLedFlags.stepCount--;
			}
			break;

		case (PULSE_2_OHR-4): 			// end pulse or next pulse, 16
			if(ohrLedFlags.countPause)	ohrLedFlags.countPause--;
			if(ohrLedFlags.countPause == 0)
			{
				ohrLedFlags.stepCount--;
			}
			break;

		case (PULSE_2_OHR-5): 			// end pulse or next pulse, 15
			if(ohrLedFlags.countCycles > 0)
			{
				ohrLedFlags.countCycles--;
				ohrLedFlags.stepCount = PULSE_2_OHR;
			}
			else
			{
				ohrLedFlags.countCycles = 0;
				ohrLedFlags.stepCount--;
			}
			break;

		case (PULSE_2_OHR-6): 		// , 14
			SetLedOhr(LED_PIN_ON);  // on led cycle, set time count on led
			ohrLedFlags.countPause = COUNT_LED_ON_P2;
			ohrLedFlags.stepCount--;
			break;

		case (PULSE_2_OHR-7):	// wait on led cycle, 13
			if(ohrLedFlags.countPause)	ohrLedFlags.countPause--;
			if(ohrLedFlags.countPause == 0)
			{						// off led cycle, set time counter off led
				SetLedOhr(LED_PIN_OFF);
				ohrLedFlags.countPause = COUNT_LED_OFF_P2;
				ohrLedFlags.stepCount--;
			}
			break;

		case (PULSE_2_OHR-8):	// wait off led cycle, 12
			if(ohrLedFlags.countPause)	ohrLedFlags.countPause--;
			if(ohrLedFlags.countPause == 0)
			{						// goto cycle,
				ohrLedFlags.stepCount = (PULSE_2_OHR-6);
			}
			break;

////////////////// END OF PULSE 2 RUNNING  ////////////////////////////

////////////////// PULSE 3 RUNNING  ////////////////////////////
		case PULSE_3_OHR: 		// , 30
			SetLedOhr(LED_PIN_ON);  // on led cycle, set time count on led
			ohrLedFlags.countPause = COUNT_LED_ON_P3;
			ohrLedFlags.stepCount--;
			break;

		case (PULSE_3_OHR-1):	// wait on led cycle, 29
			if(ohrLedFlags.countPause)	ohrLedFlags.countPause--;
			if(ohrLedFlags.countPause == 0)
			{						// off led cycle, set time counter off led
				SetLedOhr(LED_PIN_OFF);
				ohrLedFlags.countPause = COUNT_LED_OFF_P3;
				ohrLedFlags.stepCount--;
			}
			break;

		case (PULSE_3_OHR-2):	// wait off led cycle, 28
			if(ohrLedFlags.countPause)	ohrLedFlags.countPause--;
			if(ohrLedFlags.countPause == 0)
			{						// goto cycle,
				ohrLedFlags.stepCount = PULSE_3_OHR;
			}
			break;

////////////////// END OF PULSE 3 RUNNING  ////////////////////////////
		case 0:
		default:
			break;
		}
	}
	else
	{
		SetLedOhr(LED_PIN_OFF);
	}

//***********************  BUZZER **********************************//
	if(ohrBuzzerFlags.inUse == 1)
	{
		switch(ohrBuzzerFlags.stepCount)
		{
		case ALWAYS_ON_OHR:
			SetBuzzer(BUZZER_PIN_ON);
			ohrBuzzerFlags.stepCount = ALWAYS_ON_OHR;
			break;

////////////////// PULSE 1 RUNNING  ////////////////////////////
		case PULSE_1_OHR: // on buzzer 1st, set time counter on buzzer
			SetBuzzer(BUZZER_PIN_ON);
			ohrBuzzerFlags.countPause = COUNT_BUZZER_ON_P1;
			ohrBuzzerFlags.stepCount--;
			break;

		case (PULSE_1_OHR-1):	// wait on buzzer, 9
			if(ohrBuzzerFlags.countPause)	ohrBuzzerFlags.countPause--;
			if(ohrBuzzerFlags.countPause == 0)
			{						// off buzzer 1st, set time counter off buzzer
				SetBuzzer(BUZZER_PIN_OFF);
				ohrBuzzerFlags.countPause = COUNT_BUZZER_OFF_P1;
				ohrBuzzerFlags.stepCount--;
			}
			break;

		case (PULSE_1_OHR-2):			// wait off buzzer 1st, 8
			if(ohrBuzzerFlags.countPause)	ohrBuzzerFlags.countPause--;
			if(ohrBuzzerFlags.countPause == 0)
			{
				SetBuzzer(BUZZER_PIN_ON);	 // on buzzer 2st, set time counter on buzzer
				ohrBuzzerFlags.countPause = COUNT_BUZZER_ON_P1;
				ohrBuzzerFlags.stepCount--;
			}
			break;

		case (PULSE_1_OHR-3): 			// wait on buzzer 2st, 7
			if(ohrBuzzerFlags.countPause)	ohrBuzzerFlags.countPause--;
			if(ohrBuzzerFlags.countPause == 0)
			{							// off buzzer 2st, set time counter off buzzer
				SetBuzzer(BUZZER_PIN_OFF);
				ohrBuzzerFlags.countPause = COUNT_PAUSE_P1;
				ohrBuzzerFlags.stepCount--;
			}
			break;

		case (PULSE_1_OHR-4):			// wait off buzzer 2st, 6
			if(ohrBuzzerFlags.countPause)	ohrBuzzerFlags.countPause--;
			if(ohrBuzzerFlags.countPause == 0)
			{
				ohrBuzzerFlags.stepCount--;
			}
			break;

		case (PULSE_1_OHR-5): 			// end pulse and next pulse, 5
			ohrBuzzerFlags.stepCount = PULSE_1_OHR;
			break;

////////////////// END OF PULSE 1 RUNNING  ////////////////////////////

////////////////// PULSE 2 RUNNING  ////////////////////////////
		case PULSE_2_OHR: //
			SetBuzzer(BUZZER_PIN_ON);  // on buzzer 1st, set time count on buzzer
			ohrBuzzerFlags.countPause = COUNT_BUZZER_ON_P2;
			ohrBuzzerFlags.stepCount--;
			break;

		case (PULSE_2_OHR-1):	// wait on buzzer 1st, 19
			if(ohrBuzzerFlags.countPause)	ohrBuzzerFlags.countPause--;
			if(ohrBuzzerFlags.countPause == 0)
			{						// off buzzer 1st, set time counter off buzzer
				SetBuzzer(BUZZER_PIN_OFF);
				ohrBuzzerFlags.countPause = COUNT_BUZZER_OFF_P2;
				ohrBuzzerFlags.stepCount--;
			}
			break;

		case (PULSE_2_OHR-2):	// wait off buzzer 1st, 18
			if(ohrBuzzerFlags.countPause)	ohrBuzzerFlags.countPause--;
			if(ohrBuzzerFlags.countPause == 0)
			{						// on buzzer 2st, set time counter on buzzer
				SetBuzzer(BUZZER_PIN_ON);
				ohrBuzzerFlags.countPause = COUNT_BUZZER_ON_P2;
				ohrBuzzerFlags.stepCount--;
			}
			break;

		case (PULSE_2_OHR-3):	// wait on buzzer 2st, 17
			if(ohrBuzzerFlags.countPause)	ohrBuzzerFlags.countPause--;
			if(ohrBuzzerFlags.countPause == 0)
			{						// off buzzer 2st, set time counter off buzzer
				SetBuzzer(BUZZER_PIN_OFF);
				delay_tmp = COUNT_PAUSE_P2;
				delay_tmp -= (DELTA_PAUSE_SHORT_P2 * (COUNT_CYCLES_P2 - ohrBuzzerFlags.countCycles));
				if(delay_tmp < COUNT_BUZZER_OFF_P2)	delay_tmp = COUNT_BUZZER_OFF_P2;
				ohrBuzzerFlags.countPause = delay_tmp;
				ohrBuzzerFlags.stepCount--;
			}
			break;

		case (PULSE_2_OHR-4): 			// end pulse or next pulse, 16
			if(ohrBuzzerFlags.countPause)	ohrBuzzerFlags.countPause--;
			if(ohrBuzzerFlags.countPause == 0)
			{
				ohrBuzzerFlags.stepCount--;
			}
			break;

		case (PULSE_2_OHR-5): 			// end pulse or next pulse, 15
			if(ohrBuzzerFlags.countCycles)
			{
				ohrBuzzerFlags.countCycles--;
				ohrBuzzerFlags.stepCount = PULSE_2_OHR;
			}
			else
			{
				ohrBuzzerFlags.stepCount--;
			}
			break;

		case (PULSE_2_OHR-6): 		// , 14
			SetBuzzer(BUZZER_PIN_ON);  // on buzzer cycle, set time count on buzzer
			ohrBuzzerFlags.countPause = COUNT_BUZZER_ON_P2;
			ohrBuzzerFlags.stepCount--;
			break;

		case (PULSE_2_OHR-7):	// wait on buzzer cycle, 13
			if(ohrBuzzerFlags.countPause)	ohrBuzzerFlags.countPause--;
			if(ohrBuzzerFlags.countPause == 0)
			{						// off buzzer cycle, set time counter off buzzer
				SetBuzzer(BUZZER_PIN_OFF);
				ohrBuzzerFlags.countPause = COUNT_BUZZER_OFF_P2;
				ohrBuzzerFlags.stepCount--;
			}
			break;

		case (PULSE_2_OHR-8):	// wait off buzzer cycle, 12
			if(ohrBuzzerFlags.countPause)	ohrBuzzerFlags.countPause--;
			if(ohrBuzzerFlags.countPause == 0)
			{						// goto cycle,
				ohrBuzzerFlags.stepCount = (PULSE_2_OHR-6);
			}
			break;

////////////////// END OF PULSE 2 RUNNING  ////////////////////////////

////////////////// PULSE 3 RUNNING  ////////////////////////////
		case PULSE_3_OHR: 		// , 30
			SetBuzzer(BUZZER_PIN_ON);  // on buzzer cycle, set time count on buzzer
			ohrBuzzerFlags.countPause = COUNT_BUZZER_ON_P3;
			ohrBuzzerFlags.stepCount--;
			break;

		case (PULSE_3_OHR-1):	// wait on buzzer cycle, 29
			if(ohrBuzzerFlags.countPause)	ohrBuzzerFlags.countPause--;
			if(ohrBuzzerFlags.countPause == 0)
			{						// off buzzer cycle, set time counter off buzzer
				SetBuzzer(BUZZER_PIN_OFF);
				ohrBuzzerFlags.countPause = COUNT_BUZZER_OFF_P3;
				ohrBuzzerFlags.stepCount--;
			}
			break;

		case (PULSE_3_OHR-2):	// wait off buzzer cycle, 28
			if(ohrBuzzerFlags.countPause)	ohrBuzzerFlags.countPause--;
			if(ohrBuzzerFlags.countPause == 0)
			{						// goto cycle,
				ohrBuzzerFlags.stepCount = PULSE_3_OHR;
			}
			break;

////////////////// END OF PULSE 3 RUNNING  ////////////////////////////
		case 0:
		default:
			break;
		}
	}
	else
	{
		SetBuzzer(BUZZER_PIN_OFF);
	}
}	// End Event_10ms()

void Event_1sec(void)
{
	ReadControlPin();
	RunOhr();			// run security cycles
}	// End Event_1sec()

bool ReadSensorOhr(void)
{
	bool val;

	val = -1;
	if(HAL_GPIO_ReadPin(D8_GPIO_Port, D8_Pin) == 1)	val = 1;
	if(HAL_GPIO_ReadPin(D8_GPIO_Port, D8_Pin) == 0)	val = 0;
	return val;
}

bool ReadControlOhr(void)
{
	bool val;

	val = -1;
	if(ClockRAM.config.alarm_cmd & 0x0001)	val = 0;
	else									val = 1;
	return val;
}

void ReadControlPin(void)
{
	if(HAL_GPIO_ReadPin(SEC_GPIO_Port, SEC_Pin) == oldControlPin)	return;
	oldControlPin = HAL_GPIO_ReadPin(SEC_GPIO_Port, SEC_Pin);
	if(oldControlPin == 0)				ClockRAM.config.alarm_cmd |= 0x0001;
	else								ClockRAM.config.alarm_cmd &= 0xFFFE;
}

void SetLedOhr(int state)
{
	if(state == LED_PIN_ON)
	{
		HAL_GPIO_WritePin(LED_GPIO_Port, LED_Pin, LED_PIN_ON); // led on
		ohrLedFlags.currentState = 1;
    }
	else
	{
		HAL_GPIO_WritePin(LED_GPIO_Port, LED_Pin, LED_PIN_OFF); // led off
		ohrLedFlags.currentState = 0;
	}
}

void SetBuzzer(int state)
{
	if(state == BUZZER_PIN_ON)
	{
		HAL_GPIO_WritePin(BUZ_GPIO_Port, BUZ_Pin, BUZZER_PIN_ON); // buzzer on
		ohrBuzzerFlags.currentState = 1;
	}
	else
	{
		HAL_GPIO_WritePin(BUZ_GPIO_Port, BUZ_Pin, BUZZER_PIN_OFF); // buzzer off
		ohrBuzzerFlags.currentState = 0;
	}
}

void Println(UART_HandleTypeDef *huart, char _out[])
{
	HAL_UART_Transmit(huart, (uint8_t *) _out, strlen(_out), UART_TIMEOUT);
}


