/*
 * sygnal_1_380_zu.c
 *
 *  Created on: 29 авг. 2022 г.
 *      Author: vitaly
 */

/* Includes ------------------------------------------------------------------*/
#include "stm32f0xx_hal.h"
#include <stdlib.h>
#include <math.h>
#include "main.h"
#include "sygnal_1_380_bus.h"
#include "sygnal_1_380_zu.h"
#include "sygnal_1_380.h"
#include "adc_stm32.h"

zuFlags zuLedFlags;

void InitializeZu(void)
{
	SetLedZu(LED_ZU_PIN_OFF);
	SetReleZu(RELE_ZU_OFF);
	SetDischarge(DISCHARGE_OFF);
	SetCharge(CHARGE_OFF);
	adcInit();
	countADC = 1;
	stateBat = TEST_BAT;
	meassure_flag = 0;
	cntDischargeProtect = 0;
	ClearBatAvary();
#ifdef _ZU_OUTPUT_UART
	if(debugMessage == MESSAGE_ZU)
	{
		Println(&huart1, "\n------ Initialize after reset ZU --------");
	}
#endif
}

void TestBattery(void)
{
	switch(stateBat)
	{
	case TEST_BAT:		// 9
		SetDischarge(DISCHARGE_OFF);
		SetCharge(CHARGE_OFF);
		SetReleZu(RELE_ZU_OFF);
		zuLedFlags.stepCount = ZU_LED_MODE_P1;			// Pulse P1 - Test battery
		U_BAT_tst = ClockRAM.config.u_battery;
		faultMode = 0;
		SetMemAvary(ClockRAM.config.u_battery);
		stateBat--;
		break;

	case (TEST_BAT-1):		// 8
		if(ifStableVoltage(ClockRAM.config.u_battery, U_BAT_tst) == TRUE)
		{
			if(ClockRAM.config.u_battery <= DevNVRAM.config.VoltageBatteryFault)
			{
				stateBat = FAULT_BAT;
				faultMode = 11;
#ifdef _ZU_OUTPUT_UART
				if(debugMessage == MESSAGE_ZU)
				{
					meassure_flag = 1;
					itoa(ClockRAM.config.u_battery*100, buff, 10);
					Println(&huart1, "\nU_BAT: ");
					Println(&huart1, buff);
					Println(&huart1, "\nGo_to_fault_battery.1PA1");
				}
#endif
			}
			else
			{
				countPreCharge = DevNVRAM.config.PrechargeCycles-1;
				stateBat--;
			}
		}
		else
		{
			U_BAT_tst = ClockRAM.config.u_battery;		// wait, if stable voltage
		}
		break;

	case (TEST_BAT-2):		// 7
		if(ClockRAM.config.u_battery < DevNVRAM.config.VoltageBatteryGood)
		{
			stateBat = NEPONYATNY_BAT;
#ifdef _ZU_OUTPUT_UART
			if(debugMessage == MESSAGE_ZU)
			{
				meassure_flag = 1;
				Println(&huart1, "\nGo_to_neponyatny_battery.");
			}
#endif
		}
		else
		{
			stateBat = GOOD_BAT;
#ifdef _ZU_OUTPUT_UART
			if(debugMessage == MESSAGE_ZU)
			{
				Println(&huart1, "\nGo_to_good_battery_probe.");
			}
#endif
		}
		break;

	case PRECHARGE_BAT:				// precharging, 17
		if(countTimeZu1 == 1)
		{
			countTimeZu1 = 0;
			if(countPreCharge)
			{
				countTimeZu1 = DevNVRAM.config.TimeBatteryPrecharge+1;
				countPreCharge--;
#ifdef _ZU_OUTPUT_UART
				if(debugMessage == MESSAGE_ZU)
				{
					Println(&huart1, "\nPrecharge_cycle: ");
					itoa(countPreCharge+1, buff, 10);
					Println(&huart1, buff);
				}
#endif
			}
			else
			{
				SetCharge(CHARGE_OFF);
				U_BAT_tst = ClockRAM.config.u_battery;
				stateBat--;
#ifdef _ZU_OUTPUT_UART
				if(debugMessage == MESSAGE_ZU)
				{
					Println(&huart1, "\nEnd_precharging_cycles.");
				}
#endif
			}
		}
		break;

	case (PRECHARGE_BAT-1):				// precharging-1, 16
		if(ifStableVoltage(ClockRAM.config.u_battery, U_BAT_tst) == TRUE)
		{
			if(ClockRAM.config.u_battery < DevNVRAM.config.VoltageBatteryGood)
			{
				stateBat = FAULT_BAT;
				faultMode = 13;
#ifdef _ZU_OUTPUT_UART
				if(debugMessage == MESSAGE_ZU)
				{
					meassure_flag = 1;
					itoa(ClockRAM.config.u_battery*100, buff, 10);
			    	Println(&huart1, "\nU_BAT: ");
			    	Println(&huart1, buff);
			    	Println(&huart1, "\nGo_to_fault_voltage_battery.1PA3");
				}
#endif
			}
			else
			{
				stateBat = NEPONYATNY_BAT;
			}
		}
		else
		{
			U_BAT_tst = ClockRAM.config.u_battery;
		}
		break;

	case GOOD_BAT:		// 15
		SetCharge(CHARGE_OFF);
		SetReleZu(RELE_ZU_OFF);
		SetDischarge(DISCHARGE_ON);
		countTimeZu2 = DevNVRAM.config.TimeBatteryTest+1;
		stateBat--;
		break;

	case (GOOD_BAT-1):		// wait time Zu2, 14
		if(countTimeZu2 == 1)
		{
			countTimeZu2 = 0;
			U_BAT_tst = ClockRAM.config.u_battery;
		    SetDischarge(DISCHARGE_OFF);
		    stateBat--;
#ifdef _ZU_OUTPUT_UART
			if(debugMessage == MESSAGE_ZU)
			{
				itoa(U_BAT_tst*100, buff, 10);
				Println(&huart1, "\nU_BAT_test: ");
				Println(&huart1, buff);
			}
#endif
		}
		break;

	case (GOOD_BAT-2):		// verify battery after discharge cycle, 13
		if(U_BAT_tst < DevNVRAM.config.VoltageBatteryGood)
		{
			if(netAC_ok == FALSE)
			{
				stateBat = FAULT_BAT;
				faultMode = 14;
#ifdef _ZU_OUTPUT_UART
				if(debugMessage == MESSAGE_ZU)
				{
					meassure_flag = 1;
					itoa(ClockRAM.config.u_battery*100, buff, 10);
					Println(&huart1, "\nU_BAT: ");
					Println(&huart1, buff);
					Println(&huart1, "\nGo_to_fault_battery.1PA4");
				}
#endif
			}
			else
			{ // (netAC_ok == TRUE)
				SetReleZu(RELE_ZU_ON);
				SetCharge(CHARGE_ON);
				countTimeZu1 = DevNVRAM.config.TimeBatteryPrecharge+1;
				if(countPreCharge)
				{
					stateBat = PRECHARGE_BAT;
#ifdef _ZU_OUTPUT_UART
					if(debugMessage == MESSAGE_ZU)
					{
						meassure_flag = 1;
						Println(&huart1, "\nGo_to_preCharge_cycles.");
					}
#endif
				}
				else
				{
					stateBat = FAULT_BAT;
					faultMode = 13;
#ifdef _ZU_OUTPUT_UART
					if(debugMessage == MESSAGE_ZU)
					{
						meassure_flag = 1;
						itoa(ClockRAM.config.u_battery*100, buff, 10);
						Println(&huart1, "\nU_BAT: ");
						Println(&huart1, buff);
						Println(&huart1, "\nGo_to_fault_cycles_battery.1PA3");
					}
#endif
				}
			}
		}
		else
		{
			stateBat--;			// Ubat > DevNVRAM.config.VoltageBatteryGood (U_BAT5)
			U_BAT_tst = ClockRAM.config.u_battery;
		}
		break;

	case (GOOD_BAT-3):		// , 12
		if(ifStableVoltage(ClockRAM.config.u_battery, U_BAT_tst) == TRUE)
		{
			if(ClockRAM.config.u_battery > DevNVRAM.config.VoltageBatteryOff)
			{
				if(netAC_ok == TRUE)
				{
					stateBat = CHARGE_BAT;
#ifdef _ZU_OUTPUT_UART
					if(debugMessage == MESSAGE_ZU)
					{
						meassure_flag = 1;
						Println(&huart1, "\nGo_to_charge_battery_1.");
					}
#endif
				}
				else
				{
					stateBat = WORK_BAT;
#ifdef _ZU_OUTPUT_UART
					if(debugMessage == MESSAGE_ZU)
					{
						meassure_flag = 1;
						Println(&huart1, "\nGo_to_work_battery.");
					}
#endif
				}
			}
			else  // ClockRAM.config.u_battery < DevNVRAM.config.VoltageBatteryOff (U_BAT4)
			{
				if(netAC_ok == TRUE)
				{
					stateBat = CHARGE_BAT;
#ifdef _ZU_OUTPUT_UART
					if(debugMessage == MESSAGE_ZU)
					{
						meassure_flag = 1;
						Println(&huart1, "\nGo_to_charge_battery_1.");
					}
#endif
				}
				else
				{
					zuLedFlags.stepCount = ZU_LED_MODE_P8;		//LED_ZU sleep
#ifdef _ZU_OUTPUT_UART
					if(debugMessage == MESSAGE_ZU)
					{
						meassure_flag = 1;
						Println(&huart1, "\nWait_AC_voltage.");
					}
#endif
					stateBat--;
				}
			}
		}
		else
		{
			U_BAT_tst = ClockRAM.config.u_battery;
		}
		break;

	case (GOOD_BAT-4):		// waiting AC voltage, 11
		if(netAC_ok == TRUE)
		{
			stateBat--;		// AC voltage OK!
			U_BAT_tst = ClockRAM.config.u_battery;
		}
		break;

	case (GOOD_BAT-5):		// , 10
		if(ifStableVoltage(ClockRAM.config.u_battery, U_BAT_tst) == TRUE)
		{
			if(ClockRAM.config.u_battery > DevNVRAM.config.VoltageBatteryFault)
			{
				stateBat = CHARGE_BAT;
#ifdef _ZU_OUTPUT_UART
				if(debugMessage == MESSAGE_ZU)
				{
					meassure_flag = 1;
					Println(&huart1, "\nGo_to_charge_battery_2.");
				}
#endif
			}
			else
			{
				stateBat = FAULT_BAT;
				faultMode = 15;
#ifdef _ZU_OUTPUT_UART
				if(debugMessage == MESSAGE_ZU)
				{
					meassure_flag = 1;
					itoa(ClockRAM.config.u_battery*100, buff, 10);
					Println(&huart1, "\nU_BAT: ");
					Println(&huart1, buff);
					Println(&huart1, "\nGo_to_fault_battery.1PA5");
				}
#endif
			}
		}
		else
		{
			U_BAT_tst = ClockRAM.config.u_battery;
		}
	    break;

	case NEPONYATNY_BAT:	// neponyatny battery, 6, testing AC voltage
		if(netAC_ok == FALSE)
		{
			zuLedFlags.stepCount = ZU_LED_MODE_P8;		//LED_ZU sleep
#ifdef _ZU_OUTPUT_UART
			if(debugMessage == MESSAGE_ZU)
			{
				meassure_flag = 1;
				Println(&huart1, "\nLow_AC_voltage.");
			}
#endif
		}
		stateBat--;
		break;

	case (NEPONYATNY_BAT-1):	// neponyatny battery-1, 5
		if(netAC_ok == TRUE)
		{								// AC voltage OK!
			SetReleZu(RELE_ZU_ON);
			SetCharge(CHARGE_ON);
			countTimeZu1 = DevNVRAM.config.TimeBatteryPrecharge+1;
			zuLedFlags.stepCount = ZU_LED_MODE_P1;			// Pulse P1 - Test battery
			stateBat--;
#ifdef _ZU_OUTPUT_UART
			if(debugMessage == MESSAGE_ZU)
			{
				meassure_flag = 1;
				itoa(ClockRAM.config.u_input*100, buff, 10);
				Println(&huart1, "\nU_input: ");
				Println(&huart1, buff);
				Println(&huart1, "\nAC_voltage_OK.");
				Println(&huart1, "\nStart_timer_TZU1.");
			}
#endif
		}
		break;

	case (NEPONYATNY_BAT-2):	// neponyatny battery-2, 4
		if(countTimeZu1 == 1)
		{
			countTimeZu1 = 0;
			SetCharge(CHARGE_OFF);
			stateBat--;
			U_BAT_tst = ClockRAM.config.u_battery;
		}
		break;

	case (NEPONYATNY_BAT-3):	// neponyatny battery-3, 3
		if(ifStableVoltage(ClockRAM.config.u_battery, U_BAT_tst) == TRUE)
		{
			if(ClockRAM.config.u_battery < DevNVRAM.config.VoltageBatteryGood)
			{
				stateBat = FAULT_BAT;
				faultMode = 12;
#ifdef _ZU_OUTPUT_UART
				if(debugMessage == MESSAGE_ZU)
				{
					itoa(ClockRAM.config.u_battery*100, buff, 10);
					Println(&huart1, "\nU_BAT: ");
					Println(&huart1, buff);
					Println(&huart1, "\nGo_to_fault_battery.1PA2");
				}
#endif
			}
			else
			{
				stateBat = GOOD_BAT;
#ifdef _ZU_OUTPUT_UART
				if(debugMessage == MESSAGE_ZU)
				{
					meassure_flag = 1;
					itoa(ClockRAM.config.u_battery*100, buff, 10);
					Println(&huart1, "\nU_BAT: ");
					Println(&huart1, buff);
					Println(&huart1, "\nGo_to_good_battery.npb-3");
				}
#endif
			}
		}
		else
		{
			U_BAT_tst = ClockRAM.config.u_battery;
		}
		break;

	case WORK_BAT:			// 22
		SetDischarge(DISCHARGE_OFF);
		SetReleZu(RELE_ZU_ON);
		if(netAC_ok == TRUE)	SetCharge(CHARGE_ON);
		zuLedFlags.stepCount = ZU_LED_MODE_P6;	// Pulse P6 - always OFF, Discharge
		stateBat--;
		U_BAT_tst = ClockRAM.config.u_battery;
#ifdef _ZU_OUTPUT_UART
		if(debugMessage == MESSAGE_ZU)
		{
			meassure_flag = 1;
			Println(&huart1, "\nWork_battery_on.");
		}
#endif
		break;

	case (WORK_BAT-1):			// 21
		if(ifStableVoltage(ClockRAM.config.u_battery, U_BAT_tst) == TRUE)
		{
			if(ClockRAM.config.u_battery < DevNVRAM.config.VoltageBatteryOff)
			{	// 10,5V, rele off, sleep
				stateBat--;
			}
			else
			{
				stateBat = WORK_BAT-4;
			}
			if(netAC_ok == TRUE)
			{
				stateBat = CHARGE_BAT;
			}
		}
		else
		{
			U_BAT_tst = ClockRAM.config.u_battery;
		}
		break;

	case (WORK_BAT-2):			// on sleep mode, 20
		SetReleZu(RELE_ZU_OFF);
		zuLedFlags.stepCount = ZU_LED_MODE_P8;	// Pulse P8 - Battery is empty, sleep
		stateBat--;
#ifdef _ZU_OUTPUT_UART
		if(debugMessage == MESSAGE_ZU)
		{
			if(beginInputFlag == TRUE)
			{
				meassure_flag = 1;
				itoa(ClockRAM.config.u_battery*100, buff, 10);
				Println(&huart1, "\nU_BAT: ");
				Println(&huart1, buff);
				Println(&huart1, "\nBattery_sleep.");
			}
		}
#endif
		break;

	case (WORK_BAT-3):			// test battery U6, 19
		if(ClockRAM.config.u_battery <= DevNVRAM.config.VoltageBatteryFault)
		{
			if(netAC_ok)
			{
				stateBat = CHARGE_BAT;
			}
			else
			{
				stateBat = FAULT_BAT;
				faultMode = 31;
#ifdef _ZU_OUTPUT_UART
				if(debugMessage == MESSAGE_ZU)
				{
					meassure_flag = 1;
					itoa(ClockRAM.config.u_battery*100, buff, 10);
					Println(&huart1, "\nU_BAT: ");
					Println(&huart1, buff);
					Println(&huart1, "\nGo_to_fault_battery.3PA1");
				}
#endif
			}
		}
		else
		{
			stateBat = WORK_BAT-1;
		}
		break;

	case (WORK_BAT-4):			// low battery, U3...U4, 18
		if(ClockRAM.config.u_battery < DevNVRAM.config.VoltageBatteryDischarge)
		{ // 11,5V
			zuLedFlags.stepCount = ZU_LED_MODE_P7;		// Pulse P7 - Battery low
			SetAvary(ClockRAM.config.u_battery);
#ifdef _ZU_OUTPUT_UART
			if(debugMessage == MESSAGE_ZU)
			{
				if(beginInputFlag == TRUE)
				{
					meassure_flag = 1;
					itoa(ClockRAM.config.u_battery*100, buff, 10);
					Println(&huart1, "\nU_BAT: ");
					Println(&huart1, buff);
					Println(&huart1, "\nBattery_low.");
				}
			}
#endif
		}
		else
		{
			SetMemAvary(ClockRAM.config.u_battery);
			zuLedFlags.stepCount = ZU_LED_MODE_P6;	// Pulse P6 - always OFF, Discharge
		}
		stateBat = WORK_BAT-1;
		break;

	case CHARGE_BAT:		// 25
		SetDischarge(DISCHARGE_OFF);
		SetReleZu(RELE_ZU_ON);
		SetCharge(CHARGE_ON);
		zuLedFlags.stepCount = ZU_LED_MODE_P2;	// Pulse P2 - Charge battery in progress
		countTimeZu3 = DevNVRAM.config.TimeBatteryCheck+1;
		countTimeZu4 = DevNVRAM.config.TimeBatteryLimit * 3600;
		countTimeZu5 = DevNVRAM.config.TimeBatteryHealth * 3600;
		stateBat--;
#ifdef _ZU_OUTPUT_UART
		if(debugMessage == MESSAGE_ZU)
		{
			meassure_flag = 1;
		}
#endif
		break;

	case (CHARGE_BAT-1):		// 24 osnovnoy cycle charge
		SetMemAvary(ClockRAM.config.u_battery);
		if(ClockRAM.config.u_battery > DevNVRAM.config.VoltageBatteryFull)
		{
			stateBat = CHARGE_FULL;
		}
		break;

	case (CHARGE_BAT-2):		// 23 test battery online
//		SetMemAvaryPriority(ClockRAM.config.u_battery);
		if(ClockRAM.config.u_battery > DevNVRAM.config.VoltageBatteryFault)
		{
#ifdef _ZU_OUTPUT_UART
			if(debugMessage == MESSAGE_ZU)
			{
				itoa(ClockRAM.config.u_battery*100, buff, 10);
				Println(&huart1, "\nU_BAT: ");
				Println(&huart1, buff);
			}
#endif
			SetCharge(CHARGE_ON);
			stateBat++;
#ifdef _ZU_OUTPUT_UART
			if(debugMessage == MESSAGE_ZU)
			{
				meassure_flag = 1;
				Println(&huart1, "\nBattery_online.");
			}
#endif
		}
		else
		{
			stateBat = FAULT_BAT;
			faultMode = 21;
#ifdef _ZU_OUTPUT_UART
			if(debugMessage == MESSAGE_ZU)
			{
				meassure_flag = 1;
				itoa(ClockRAM.config.u_battery*100, buff, 10);
				Println(&huart1, "\nU_BAT: ");
				Println(&huart1, buff);
				Println(&huart1, "\nGo_to_fault_battery.2PA1");
			}
#endif
		}
		break;

	case CHARGE_FULL:		// 26
		SetCharge(CHARGE_OFF);
		zuLedFlags.stepCount = ZU_LED_MODE_P3;	// Pulse P3 - always ON, Charge full
#ifdef _ZU_OUTPUT_UART
		if(debugMessage == MESSAGE_ZU)
		{
			meassure_flag = 1;
			itoa(ClockRAM.config.u_battery*100, buff, 10);
			Println(&huart1, "\nU_BAT: ");
			Println(&huart1, buff);
			Println(&huart1, "\nCharge_battery_full.");
		}
#endif
		stateBat++;
		break;

	case (CHARGE_FULL+1):		// 27
		if(ClockRAM.config.u_battery < DevNVRAM.config.VoltageBatteryCharge)
		{
			SetCharge(CHARGE_ON);
			stateBat = CHARGE_BAT-1;
		}
		if(ClockRAM.config.u_battery < U_BAT_ZERO)
		{
			stateBat = FAULT_BAT;
			faultMode = 10;
		}
		break;

	case (FAULT_BAT+2):		// 2
		if(ifStableVoltage(ClockRAM.config.u_battery, U_BAT_tst) == TRUE)
		{
			if(ClockRAM.config.u_battery > U_BAT_ZERO)	// DevNVRAM.config.VoltageBatteryFault)
			{
				stateBat = TEST_BAT;
#ifdef _ZU_OUTPUT_UART
				if(debugMessage == MESSAGE_ZU)
				{
					meassure_flag = 1;
					itoa(ClockRAM.config.u_battery*100, buff, 10);
					Println(&huart1, "\nU_BAT: ");
					Println(&huart1, buff);
					Println(&huart1, "\nGo_to_test_battery.4PR1");
				}
#endif
			}
		}
		else
		{
			U_BAT_tst = ClockRAM.config.u_battery;
		}
		break;

	case FAULT_BAT+1:		// 1
		if(ClockRAM.config.u_battery < U_BAT_ZERO)
		{
			stateBat++;
			U_BAT_tst = ClockRAM.config.u_battery;
			SetAvaryNoBat();
#ifdef _ZU_OUTPUT_UART
			if(debugMessage == MESSAGE_ZU)
			{
				meassure_flag = 1;
				Println(&huart1, "\nLow_voltage_battery_detected.");
			}
#endif
		}
		break;

	case FAULT_BAT:		// 0
		SetDischarge(DISCHARGE_OFF);
		SetCharge(CHARGE_OFF);
		SetReleZu(RELE_ZU_OFF);
		zuLedFlags.stepCount = ZU_LED_MODE_P5;		// Error battery indication
		SetAvary(ClockRAM.config.u_battery);
		stateBat++;
//		SetMemAvaryPriority(ClockRAM.config.u_battery);
#ifdef _ZU_OUTPUT_UART
		if(debugMessage == MESSAGE_ZU)
		{
			meassure_flag = 1;
			itoa(ClockRAM.config.u_battery*100, buff, 10);
			Println(&huart1, "\nU_BAT: ");
			Println(&huart1, buff);
			Println(&huart1, "\nFault_battery. Wait_low_voltage.");
		}
#endif
		break;
	default:
		break;
	}
}

void TimersCharger(void)
{
//////////////////// timer zu 5 /////////////////////////////////
	if(countTimeZu5 == DevNVRAM.config.TimeBatteryTest+1)  // za 4 sec do 0
	{   // test battery for using
		countTimeZu3 = DevNVRAM.config.TimeBatteryCheck+1;
		// timer zu3, zu4 reload, to next test
		countTimeZu4 = DevNVRAM.config.TimeBatteryLimit * 3600; // timer zu4 reload, to next test
		if(stateCharge == CHARGE_ON)	SetCharge(CHARGE_OFF);
		SetDischarge(DISCHARGE_ON);						// begin test battery
		zuLedFlags.stepCount = ZU_LED_MODE_P1;			// Pulse P1 - Test battery
		stateBat = WAIT_TZU5;							// waiting for test battery
#ifdef _ZU_OUTPUT_UART
		if(debugMessage == MESSAGE_ZU)
		{
			Println(&huart1, "\nTimer_TZU5_end.");
		}
#endif
	}
	if(countTimeZu5 == 1)
	{
		countTimeZu5 = 0;
		U_BAT_tst = ClockRAM.config.u_battery;
		SetDischarge(DISCHARGE_OFF);						// end test battery
#ifdef _ZU_OUTPUT_UART
		if(debugMessage == MESSAGE_ZU)
		{
			itoa(U_BAT_tst*100, buff, 10);
			Println(&huart1, "\nU_BAT_test: ");
			Println(&huart1, buff);
		}
#endif
		if(U_BAT_tst < DevNVRAM.config.VoltageBatteryGood)
		{
			stateBat = FAULT_BAT;
			faultMode = 20;
#ifdef _ZU_OUTPUT_UART
			if(debugMessage == MESSAGE_ZU)
			{
				Println(&huart1, "\nGo_to_fault_battery.2PA");
			}
#endif
			return;
		}
		countTimeZu5 = DevNVRAM.config.TimeBatteryHealth * 3600;
		stateBat = CHARGE_BAT;
#ifdef _ZU_OUTPUT_UART
		if(debugMessage == MESSAGE_ZU)
		{
			Println(&huart1, "\nBattery_is_good.");
		}
#endif
		return;
	}
//////////////////// timer zu 4 /////////////////////////////////
	if(countTimeZu4 == 1)
	{
		countTimeZu3 = DevNVRAM.config.TimeBatteryCheck+1;	// timer zu3 reload, to next test
		// test battery of full charge
		countTimeZu4 = DevNVRAM.config.TimeBatteryLimit * 3600;
		if((ClockRAM.config.u_battery < DevNVRAM.config.VoltageBatteryCharge) && (stateCharge == CHARGE_ON))
		{
			zuLedFlags.stepCount = ZU_LED_MODE_P4;	// Pulse P4 - Charge error
#ifdef _ZU_OUTPUT_UART
			if(debugMessage == MESSAGE_ZU)
			{
				Println(&huart1, "\nCharge_error.");
			}
#endif
		}
#ifdef _ZU_OUTPUT_UART
		if(debugMessage == MESSAGE_ZU)
		{
			meassure_flag = 1;
			Println(&huart1, "\nTimer_TZU4_end.");
		}
#endif
	}
//////////////////// timer zu 3 /////////////////////////////////
	if(countTimeZu3 == 1)
	{
		countTimeZu3 = DevNVRAM.config.TimeBatteryCheck+1;
		if(stateCharge == CHARGE_ON)		 SetCharge(CHARGE_OFF);
		if((stateBat > PRECHARGE_BAT) && (stateBat < CHARGE_FULL))
		{
			stateBat = CHARGE_BAT-2;
		}
#ifdef _ZU_OUTPUT_UART
		if(debugMessage == MESSAGE_ZU)
		{
			itoa(ClockRAM.config.u_battery*100, buff, 10);
			Println(&huart1, "\nU_BAT: ");
			Println(&huart1, buff);
			Println(&huart1, "\nTimer_TZU3_end.");
		}
#endif
	}
}

void ControlZuLed_10ms(void)
{ // 10 mSec timer

	switch(zuLedFlags.stepCount)
	{
////////////////// PULSE 1 RUNNING  ////////////////////////////
	case ZU_LED_MODE_P1:			// , 5
		SetLedZu(LED_ZU_PIN_ON);	// zu led ON
		zuLedFlags.countPause = COUNT_ZU_LED_ON_P1;
		zuLedFlags.stepCount--;
		break;

	case (ZU_LED_MODE_P1-1):		// wait, zu led ON, 4
		if(zuLedFlags.countPause)	zuLedFlags.countPause--;
	    if(zuLedFlags.countPause == 0)
	    {
	    	SetLedZu(LED_ZU_PIN_OFF);	// zu led OFF
		    zuLedFlags.countPause = COUNT_ZU_LED_OFF_P1;
		    zuLedFlags.stepCount--;
	    }
		break;

	case (ZU_LED_MODE_P1-2):		// wait, zu led OFF, 3
		if(zuLedFlags.countPause)	zuLedFlags.countPause--;
	    if(zuLedFlags.countPause == 0)
	    {
		    zuLedFlags.stepCount = ZU_LED_MODE_P1;
	    }
	    break;
////////////////// END OF PULSE 1 RUNNING  ////////////////////////////

////////////////// PULSE 2 RUNNING  ////////////////////////////
	case ZU_LED_MODE_P2:			// , 9
		SetLedZu(LED_ZU_PIN_ON);	// zu led ON
		zuLedFlags.countPause = COUNT_ZU_LED_ON_P2;
		zuLedFlags.stepCount--;
		break;

	case (ZU_LED_MODE_P2-1):		// wait, zu led ON, 8
		if(zuLedFlags.countPause)	zuLedFlags.countPause--;
	    if(zuLedFlags.countPause == 0)
	    {
	    	SetLedZu(LED_ZU_PIN_OFF);	// zu led OFF
		    zuLedFlags.countPause = COUNT_ZU_LED_OFF_P2;
		    zuLedFlags.stepCount--;
	    }
		break;

	case (ZU_LED_MODE_P2-2):		// wait, zu led OFF, 7
		if(zuLedFlags.countPause)	zuLedFlags.countPause--;
	    if(zuLedFlags.countPause == 0)
	    {
		    zuLedFlags.stepCount = ZU_LED_MODE_P2;
	    }
	    break;
////////////////// END OF PULSE 2 RUNNING  ////////////////////////////

////////////////// PULSE 5 RUNNING  ////////////////////////////
	case ZU_LED_MODE_P5:			// , 12
		SetLedZu(LED_ZU_PIN_ON);	// zu led ON
		zuLedFlags.countPause = COUNT_ZU_LED_ON_P5;
		zuLedFlags.stepCount--;
		break;

	case (ZU_LED_MODE_P5-1):		// wait, zu led ON, 11
		if(zuLedFlags.countPause)	zuLedFlags.countPause--;
	    if(zuLedFlags.countPause == 0)
	    {
	    	SetLedZu(LED_ZU_PIN_OFF);	// zu led OFF
		    zuLedFlags.countPause = COUNT_ZU_LED_OFF_P5;
		    zuLedFlags.stepCount--;
	    }
		break;

	case (ZU_LED_MODE_P5-2):		// wait, zu led OFF, 10
		if(zuLedFlags.countPause)	zuLedFlags.countPause--;
	    if(zuLedFlags.countPause == 0)
	    {
		    zuLedFlags.stepCount = ZU_LED_MODE_P5;
	    }
	    break;
//////////////////  END OF PULSE 5 RUNNING  ////////////////////////////

/////////////////////// PULSE 8 RUNNING  ////////////////////////////
   	case ZU_LED_MODE_P8:			// , 16
   		SetLedZu(LED_ZU_PIN_ON);	// zu led ON
   		zuLedFlags.countPause = COUNT_ZU_LED_ON_P8;
   		zuLedFlags.stepCount--;
   		break;

   	case (ZU_LED_MODE_P8-1):		// wait, zu led ON, 15
 		if(zuLedFlags.countPause)	zuLedFlags.countPause--;
   	    if(zuLedFlags.countPause == 0)
   	    {
   	    	SetLedZu(LED_ZU_PIN_OFF);	// zu led OFF
   		    zuLedFlags.countPause = COUNT_ZU_LED_OFF_P8;
   		    zuLedFlags.stepCount--;
   	    }
   	    break;

   	case (ZU_LED_MODE_P8-2):		// wait, zu led OFF, 14
	    if(zuLedFlags.countPause)	zuLedFlags.countPause--;
   		if(zuLedFlags.countPause == 0)
   		{
   			zuLedFlags.stepCount = ZU_LED_MODE_P8;
   		}
   		break;
//////////////////  END OF PULSE 8 RUNNING  ////////////////////////////

////////////////// PULSE 4 RUNNING  ////////////////////////////
   	case ZU_LED_MODE_P4:			// , 24
   		SetLedZu(LED_ZU_PIN_ON);	// zu led ON, 1st
   		zuLedFlags.countPause = COUNT_ZU_LED_ON_P4;
   		zuLedFlags.stepCount--;
   		break;

   	case (ZU_LED_MODE_P4-1):		// wait, zu led ON, 23, 1st
		if(zuLedFlags.countPause)	zuLedFlags.countPause--;
	    if(zuLedFlags.countPause == 0)
	    {
	    	SetLedZu(LED_ZU_PIN_OFF);	// zu led OFF, 1st
		    zuLedFlags.countPause = COUNT_ZU_LED_OFF_P4;
		    zuLedFlags.stepCount--;
	    }
		break;

   	case (ZU_LED_MODE_P4-2):		// wait, zu led OFF, 22, 1st-end
		if(zuLedFlags.countPause)	zuLedFlags.countPause--;
	    if(zuLedFlags.countPause == 0)
	    {
	    	SetLedZu(LED_ZU_PIN_ON);	// zu led ON, 2st
		    zuLedFlags.countPause = COUNT_ZU_LED_ON_P4;
		    zuLedFlags.stepCount--;
	    }
		break;

   	case (ZU_LED_MODE_P4-3):		// wait, zu led ON, 21, 2st
		if(zuLedFlags.countPause)	zuLedFlags.countPause--;
	    if(zuLedFlags.countPause == 0)
	    {
	    	SetLedZu(LED_ZU_PIN_OFF);	// zu led OFF, 2st
		    zuLedFlags.countPause = COUNT_ZU_LED_OFF_P4;
		    zuLedFlags.stepCount--;
	    }
		break;

   	case (ZU_LED_MODE_P4-4):		// wait, zu led ON, 20, 2st-end
		if(zuLedFlags.countPause)	zuLedFlags.countPause--;
	    if(zuLedFlags.countPause == 0)
	    {
	    	SetLedZu(LED_ZU_PIN_ON);	// zu led ON, 3st
		    zuLedFlags.countPause = COUNT_ZU_LED_ON_P4;
		    zuLedFlags.stepCount--;
	    }
		break;

   	case (ZU_LED_MODE_P4-5):		// wait, zu led ON, 19, 3st
		if(zuLedFlags.countPause)	zuLedFlags.countPause--;
	    if(zuLedFlags.countPause == 0)
	    {
	    	SetLedZu(LED_ZU_PIN_OFF);	// zu led OFF, 3st
		    zuLedFlags.countPause = COUNT_ZU_LED_PAUSE_P4;
		    zuLedFlags.stepCount--;
	    }
		break;

	case (ZU_LED_MODE_P4-6):		// wait, zu led OFF, 18, 3st-end
		if(zuLedFlags.countPause)	zuLedFlags.countPause--;
	    if(zuLedFlags.countPause == 0)
	    {
		    zuLedFlags.stepCount = ZU_LED_MODE_P4;
	    }
	    break;
////////////////////////  END OF PULSE 4 RUNNING  ////////////////////////////

////////////////// PULSE 7 RUNNING  ////////////////////////////
	case ZU_LED_MODE_P7:			// , 30
		SetLedZu(LED_ZU_PIN_ON);	// zu led ON, 1st
		zuLedFlags.countPause = COUNT_ZU_LED_ON_P7;
		zuLedFlags.stepCount--;
		break;

	case (ZU_LED_MODE_P7-1):		// wait, zu led ON, 29
   		if(zuLedFlags.countPause)	zuLedFlags.countPause--;
   	    if(zuLedFlags.countPause == 0)
   	    {
   	    	SetLedZu(LED_ZU_PIN_OFF);	// zu led OFF, 1st
   	    	zuLedFlags.countPause = COUNT_ZU_LED_OFF_P7;
   	    	zuLedFlags.stepCount--;
   	    }
   	    break;

   	case (ZU_LED_MODE_P7-2):		// wait, zu led OFF, 28
		if(zuLedFlags.countPause)	zuLedFlags.countPause--;
   		if(zuLedFlags.countPause == 0)
   		{
   			SetLedZu(LED_ZU_PIN_ON);	// zu led ON
   			zuLedFlags.countPause = COUNT_ZU_LED_ON_P7;
   			zuLedFlags.stepCount--;
   		}
   		break;

   	case (ZU_LED_MODE_P7-3):		// wait, zu led ON, 27
	    if(zuLedFlags.countPause)	zuLedFlags.countPause--;
   		if(zuLedFlags.countPause == 0)
   		{
   			SetLedZu(LED_ZU_PIN_OFF);	// zu led OFF
   			zuLedFlags.countPause = COUNT_ZU_LED_PAUSE_P7;
   			zuLedFlags.stepCount--;
   		}
   		break;

   	case (ZU_LED_MODE_P7-4):		// wait, zu led OFF, 26
		if(zuLedFlags.countPause)	zuLedFlags.countPause--;
   		if(zuLedFlags.countPause == 0)
   		{
   			zuLedFlags.stepCount = ZU_LED_MODE_P7;
   		}
   		break;
////////////////////////  END OF PULSE 7 RUNNING  ////////////////////////////

	case ZU_LED_MODE_P3:	// always ON
		SetLedZu(LED_ZU_PIN_ON);
		break;

	case ZU_LED_MODE_P6:	// always OFF
	default:
		SetLedZu(LED_ZU_PIN_OFF);
		break;
	}
	Meassure();
}

void ControlZu_1sec(void)
{ // 1 Sec timer
	if(beginDelay)		return;
	netAC_ok = TestAC();
#ifdef _ZU_OUTPUT_UART
	if(meassure_flag)
	{
		if(debugMessage == MESSAGE_ZU)
		{
			itoa(ClockRAM.config.u_battery*100, buff, 10);
			Println(&huart1, "\nU_battery: ");
			Println(&huart1, buff);
			itoa(ClockRAM.config.u_input*100, buff, 10);
			Println(&huart1, " mV; U_input: ");
			Println(&huart1, buff);
			itoa(ClockRAM.config.temperature, buff, 10);
			Println(&huart1, " mV; Themperature: ");
			Println(&huart1, buff);
			meassure_flag = 0;
		}
	}
#endif
	if(netAC_ok == TRUE)
	{
		if(countTimeZu1)	countTimeZu1--;
		if(stateBat > WORK_BAT)  // if battery charging, run timers 3, 4, 5
		{
			if(countTimeZu3)	countTimeZu3--;
			if(countTimeZu4)	countTimeZu4--;
			if(countTimeZu5)	countTimeZu5--;
		}
		beginInputFlag = TRUE;		// for digital inputs (sygnal_1_380_bus.c)
	}
	if(countTimeZu2)			countTimeZu2--;
	TestBattery();
	TimersCharger();
	DisChargeOff();			// for notLegasy discharging
	if((netAC_ok == FALSE) && (ClockRAM.config.u_battery < DevNVRAM.config.VoltageBatteryFault))
	{
		beginInputFlag = FALSE;		// for digital inputs (sygnal_1_380_bus.c)
	}
}

int ConvTemperature(int vadc)
{
	double tmp;
	int rez;

	if (vadc >= 2650)
	{	// y(x)=140-x/18
		tmp = vadc / 18;
		rez = (int)(140 - tmp);
	}
	if ((vadc < 2650) && (vadc > 1419))
	{	// y(x)=78.5-x/31
		tmp = vadc / 31;
		rez = (int)(78.5 - tmp);
	}
	if ((vadc < 1420) && (vadc > 999))
	{	// y(x)=82.5-x/28.5
		tmp = vadc / 28.5;
		rez = (int)(82.5 - tmp);
	}
	if ((vadc < 1000) && (vadc > 639))
	{	// y(x)=95-x/21
		tmp = vadc / 21;
		rez = (int)(95 - tmp);
	}
	if ((vadc < 640) && (vadc > 413))
	{	// y(x)=112-x/13,5
		tmp = vadc / 13.5;
		rez = (int)(112 - tmp);
	}
	if ((vadc < 414) && (vadc > 242))
	{	// y(x)=130-x/8.5
		tmp = vadc / 8.5;
		rez = (int)(130 - tmp);
	}
	if (vadc <= 242)
	{	// y(x)=150-x/5)
		tmp = vadc / 5;
		rez = (int)(150 - tmp);
	}
	return rez;
}

void Meassure(void)
{
	int ci;
	uint32_t tmp0, tmp1, tmp2;
	double rez;

	Single();
	if(countSample > 6)
	{
	uBattery[countADC] = ADC_result[0];
	uAdapter[countADC] = ADC_result[1];
	sensorNTC[countADC] = ADC_result[2];
	countADC++;
	if(countADC > 16)	countADC = 1;
	tmp0 = 0;
	tmp1 = 0;
	tmp2 = 0;
	for(ci = 1; ci < 17; ci++)
	{
		tmp0 += uBattery[ci];
		tmp1 += uAdapter[ci];
		tmp2 += sensorNTC[ci];
	}
	uBattery[0] = tmp0 >> 4;
	rez = ADC_KU_12 * uBattery[0];
	rez = rez / 100;
	ClockRAM.config.u_battery = (uint16_t)rez;
	uAdapter[0] = tmp1 >> 4;
	rez = ADC_KU_12 * uAdapter[0];
	rez = rez / 100;
	ClockRAM.config.u_input = (uint16_t)rez;
	sensorNTC[0] = tmp2 >> 4;
    rez = ADC_KU_3 * sensorNTC[0];
    ClockRAM.config.temperature = ConvTemperature((int)rez);
	}
}

bool ifStableVoltage(uint16_t u_now, uint16_t u_old)
{
	uint8_t rez;

	rez = FALSE;
	if(beginDelay)	return rez;
	if(u_now > u_old)
	{
		u_now -= u_old;
		if(u_now < DELTA_U)		rez = TRUE;
	}
	else
	{
		u_old -= u_now;
		if(u_old < DELTA_U)		rez = TRUE;
	}
	return rez;
}

bool TestAC(void)
{
	bool tst;

	if(BIT_TEST(ClockRAM.config.di2_PP380, 12) && (ClockRAM.config.u_input > ((DevNVRAM.config.VoltageLevelInput+DevNVRAM.config.VoltageInputHysteresis)*10)))
	{	// set register memory avary AKM4
		BIT_CLR(ClockRAM.config.di2_PP380, 12);
		BIT_SET(ClockRAM.config.dim2_PP380, 12);
	}
	if(ClockRAM.config.u_input > (DevNVRAM.config.VoltageLevelInput*10))
	{
		cntDelayLowInputVoltage = (DevNVRAM.config.DelayNetSensor & 0x00FF)+1;
		tst = TRUE;
	}
	else
	{	// set register avary AK4
		if((cntDelayLowInputVoltage == 0) && (ClockRAM.config.u_input > U_BAT5))
		{
			if((BIT_TEST(ClockRAM.config.di2_PP380, 3)==0) && (BIT_TEST(ClockRAM.config.di2_PP380, 6)==0) && (BIT_TEST(ClockRAM.config.di2_PP380, 8)==0))
			{ // no phase A, over voltage, no energy
				BIT_SET(ClockRAM.config.di2_PP380, 12);
			}
		}
		tst = FALSE;
		if(cntDelayLowInputVoltage)			cntDelayLowInputVoltage--;
	}
	if(tst != netAC_last)
	{
		if(tst == FALSE)	SetCharge(CHARGE_OFF);
		if(stateBat > WORK_BAT)		stateBat = WORK_BAT;
#ifdef _ZU_OUTPUT_UART
		if(debugMessage == MESSAGE_ZU)
		{
			itoa(ClockRAM.config.u_input*100, buff, 10);
			Println(&huart1, "\nU_input: ");
			Println(&huart1, buff);
			Println(&huart1, " mV, voltage level for charging: ");
			itoa(DevNVRAM.config.VoltageLevelInput*1000, buff, 10);
			Println(&huart1, buff);
			Println(&huart1, " mV");
		}
#endif
	}
	netAC_last = tst;
	return tst;
}

void SetAvary(uint16_t voltage)
{
	switch(faultMode)
	{
	case 10:
	case 11:
	case 12:
	case 13:
	case 14:
	case 15:
	case 20:
	case 21:
	case 31:
		if(voltage < U_BAT_ZERO)
		{	// set register avary AK2, akb not conected
			BIT_SET(ClockRAM.config.di2_PP380, 10);
		}
		else
		{	// set register memory avary AKM3, avary akb
			BIT_SET(ClockRAM.config.di2_PP380, 11);
		}
		faultMode = 0;
		break;

	case 0:
	default:
		if((voltage <= DevNVRAM.config.VoltageLevelBattery) && (voltage > DevNVRAM.config.VoltageBatteryFault) && (netAC_ok == FALSE))
		{	// set register avary AK1, akb rozryazhena
			BIT_SET(ClockRAM.config.di2_PP380, 9);
		}
		if((voltage <= DevNVRAM.config.VoltageBatteryFault) && (voltage >= U_BAT_ZERO))
		{	// set register avary AK3, avary akb
			BIT_SET(ClockRAM.config.di2_PP380, 11);
		}
		if(voltage < U_BAT_ZERO)
		{	// set register avary AK2, akb not conected
			BIT_SET(ClockRAM.config.di2_PP380, 10);
		}
		break;
	}
}

void SetMemAvary(uint16_t voltage)
{
	if(voltage >= (DevNVRAM.config.VoltageLevelBattery+DevNVRAM.config.VoltageBatteryHysteresis))
	{	// set register memory avary AKM1, akb rozryazhena
		if(BIT_TEST(ClockRAM.config.di2_PP380, 9))
		{	// set register memory avary AKM1, akb rozryazhena
			BIT_CLR(ClockRAM.config.di2_PP380, 9);
			BIT_SET(ClockRAM.config.dim2_PP380, 9);
		}
	}
	if(voltage > U_BAT_ZERO)		// DevNVRAM.config.VoltageBatteryFault)
	{	// avary AK2, akb not conected
		if(BIT_TEST(ClockRAM.config.di2_PP380, 10))
		{	// set register memory avary AKM2, akb not conected
			BIT_CLR(ClockRAM.config.di2_PP380, 10);
			BIT_SET(ClockRAM.config.dim2_PP380, 10);
		}
	}
	if(voltage > DevNVRAM.config.VoltageBatteryFault)		// VoltageLevelBattery)
	{
		if(BIT_TEST(ClockRAM.config.di2_PP380, 11))
		{	// set register memory avary AKM3, avary akb
			BIT_CLR(ClockRAM.config.di2_PP380, 11);
			BIT_SET(ClockRAM.config.dim2_PP380, 11);
		}
	}
}

void SetAvaryNoBat(void)
{
	// set register avary AK2, akb not conected
	BIT_SET(ClockRAM.config.di2_PP380, 10);
	if(BIT_TEST(ClockRAM.config.di2_PP380, 11))
	{	// set register memory avary AKM3, avary akb
		BIT_CLR(ClockRAM.config.di2_PP380, 11);
		BIT_SET(ClockRAM.config.dim2_PP380, 11);
	}
	if(BIT_TEST(ClockRAM.config.di2_PP380, 9))
	{	// set register memory avary AKM1, akb rozryazhena
		BIT_CLR(ClockRAM.config.di2_PP380, 9);
		BIT_SET(ClockRAM.config.dim2_PP380, 9);
	}
}

void ClearBatAvary(void)
{
	BIT_CLR(ClockRAM.config.di2_PP380, 9);
	BIT_CLR(ClockRAM.config.di2_PP380, 10);
	BIT_CLR(ClockRAM.config.di2_PP380, 11);
}

void SetReleZu(int state)
{ //
	int curState;

	curState = HAL_GPIO_ReadPin(RELE_ZU_GPIO_Port, RELE_ZU_Pin);
	if(state == curState)			return;
	HAL_GPIO_WritePin(RELE_ZU_GPIO_Port, RELE_ZU_Pin, state);
	if(state == RELE_ZU_ON)
	{
		beginInputFlag = TRUE;		// for digital inputs (sygnal_1_380_bus.c)
		phaseNet.delay = 5;			// in
#ifdef _ZU_OUTPUT_UART
		if(debugMessage == MESSAGE_ZU)
		{
			Println(&huart1, "\nRele_on.");
		}
#endif
	}
	if(state != RELE_ZU_ON)
	{
		beginInputFlag = FALSE;		// for digital inputs (sygnal_1_380_bus.c)
#ifdef _ZU_OUTPUT_UART
		if(debugMessage == MESSAGE_ZU)
		{
			Println(&huart1, "\nRele_off.");
		}
#endif
	}
}

void SetDischarge(int state)
{
	int curState;

	curState = HAL_GPIO_ReadPin(DCH_GPIO_Port, DCH_Pin);
	if(state == curState)			return;
	HAL_GPIO_WritePin(DCH_GPIO_Port, DCH_Pin, state);
#ifdef _ZU_OUTPUT_UART
	if(state == DISCHARGE_ON)
	{
		if(debugMessage == MESSAGE_ZU)
		{
			Println(&huart1, "\nDischarge_on.");
		}
	}
	else
	{
		if(debugMessage == MESSAGE_ZU)
		{
			Println(&huart1, "\nDischarge_off.");
		}
	}
#endif
}

void DisChargeOff(void)
{
	if(HAL_GPIO_ReadPin(DCH_GPIO_Port, DCH_Pin) == DISCHARGE_ON)
	{ // discharging on
		cntDischargeProtect++;
		if(cntDischargeProtect > DevNVRAM.config.TimeBatteryTest)
		{
			HAL_GPIO_WritePin(DCH_GPIO_Port, DCH_Pin, DISCHARGE_OFF); // discharge off
		}
#ifdef _ZU_OUTPUT_UART
		if(debugMessage == MESSAGE_ZU)
		{
			Println(&huart1, "\nDischarging_is_on: ");
			itoa(cntDischargeProtect, buff, 10);
			Println(&huart1, buff);
			Println(&huart1, " sec.");
		}
#endif
	}
	if(HAL_GPIO_ReadPin(DCH_GPIO_Port, DCH_Pin) == DISCHARGE_OFF)
	{
		cntDischargeProtect = 0;
	}
}

void SetCharge(int state)
{
	if(state == stateCharge)			return;
	if(state == CHARGE_ON)
	{
		if(netAC_ok == TRUE)
		{
			HAL_GPIO_WritePin(EN_ZU_GPIO_Port, EN_ZU_Pin, CHARGE_ON); // charge on
			stateCharge = CHARGE_ON;
#ifdef _ZU_OUTPUT_UART
			if(debugMessage == MESSAGE_ZU)
			{
				Println(&huart1, "\nCharge_battery_on.");
			}
#endif
		}
		if(netAC_ok == FALSE)
		{
			HAL_GPIO_WritePin(EN_ZU_GPIO_Port, EN_ZU_Pin, CHARGE_OFF); // charge off
			stateCharge = CHARGE_OFF;
#ifdef _ZU_OUTPUT_UART
			if(debugMessage == MESSAGE_ZU)
			{
				Println(&huart1, "\nDon`t charge, low_input_voltage.");
			}
#endif
		}
	}
	if((state == CHARGE_OFF) || (netAC_ok == FALSE))
	{
		HAL_GPIO_WritePin(EN_ZU_GPIO_Port, EN_ZU_Pin, CHARGE_OFF); // charge off
		stateCharge = CHARGE_OFF;
#ifdef _ZU_OUTPUT_UART
		if(netAC_ok == FALSE)
		{
			Println(&huart1, "\nLow_input_voltage.");
		}
		if(debugMessage == MESSAGE_ZU)
		{
			Println(&huart1, "\nCharge_battery_off.");
		}
#endif
	}
}

void SetLedZu(int state)
{
	HAL_GPIO_WritePin(LED_ZU_GPIO_Port, LED_ZU_Pin, state);
}
