/*
 * sygnal_1_380.h
 *
 *  Created on: 24 авг. 2022 г.
 *      Author: vitaly
 */

#ifndef __SYGNAL_1_380_H
#define __SYGNAL_1_380_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f0xx_hal.h"
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
//#define _SECURITY_OUTPUT_UART			// debug output to UART1

#define LED_PIN_ON           1
#define LED_PIN_OFF		     !LED_PIN_ON
#define BUZZER_PIN_ON        1
#define BUZZER_PIN_OFF	     !BUZZER_PIN_ON
#define SENSOR_OHR_CLOSE     0
#define SENSOR_OHR_OPEN      !SENSOR_OHR_CLOSE
#define CONTROL_OHR_ACTIVE   0
#define CONTROL_OHR_OFF      !CONTROL_OHR_ACTIVE

#define COUNT_LED_ON_P1			15		// 25*timebase = 250 mSec
#define COUNT_LED_OFF_P1		15		// 25*timebase = 250 mSec
#define COUNT_BUZZER_ON_P1		15		// 25*timebase = 250 mSec
#define COUNT_BUZZER_OFF_P1		15		// 25*timebase = 250 mSec
#define COUNT_PAUSE_P1			100		// 100*timebase = 1 Sec
#define COUNT_LED_ON_P2			15		// 25*timebase = 250 mSec
#define COUNT_LED_OFF_P2		15		// 25*timebase = 250 mSec
#define COUNT_BUZZER_ON_P2		15		// 25*timebase = 250 mSec
#define COUNT_BUZZER_OFF_P2		15		// 25*timebase = 250 mSec
#define COUNT_PAUSE_P2			100		// 100*timebase = 1 Sec
#define COUNT_CYCLES_P2			2000	// 20 Sec
#define DELTA_PAUSE_SHORT_P2 	6		// for 20 Sec, 50 mSec
#define COUNT_LED_ON_P3			50		// 50*timebase = 500 mSec
#define COUNT_LED_OFF_P3		50		// 50*timebase = 500 mSec
#define COUNT_BUZZER_ON_P3		50		// 50*timebase = 500 mSec
#define COUNT_BUZZER_OFF_P3		50		// 50*timebase = 500 mSec
#define COUNT_TIMER_ALARM		60		// 60 Sec
#define ALARM_CYCLES_TRESHOLD	5		// 5 cycles of alarm
#define COUNT_WAIT_ALARM		20		// 20 Sec

#define SYGNAL_MODE_OFF				0
#define SYGNAL_MODE_LEDI1_BUZI1		5
#define SYGNAL_MODE_LED1_BUZ0		10
#define SYGNAL_MODE_LEDI2_BUZI2		15
#define SYGNAL_MODE_LEDI3_BUZ1		20
#define SYGNAL_MODE_LEDI3_BUZ0		25

#define ALWAYS_ON_OHR				2
#define PULSE_1_OHR					10
#define PULSE_2_OHR					20
#define PULSE_3_OHR					30

/// ohrState
#define OHR_ACTIVE					0
#define OHR_GO_ACTIVE				1
#define OHR_WAIT_ALARM				2
#define OHR_GO_ALARM				3
#define OHR_ALARM					4
#define OHR_WAIT_SENSOR_CLOSE		5
#define OHR_WAIT_SENSOR_OPEN		6
#define OHR_GO_OFF					7
#define OHR_OFF						8

/// Variables
extern UART_HandleTypeDef huart1;
extern UART_HandleTypeDef huart2;
extern UART_HandleTypeDef huart3;

int sygnalisationMode;
int ohrState;
int delay_tmp;
int timerAlarm;
int waitAlarm;
int countAlarmCycles;
uint8_t hello[32];
uint8_t oldControlPin;

typedef struct
{
	bool inUse;	             // '1'-led or buzzer is active
	bool currentState;		 // current state led or buzzer
	bool pauseState;		 // '1'-in pause state
	bool changeOk;			 // modify parameter is success
	int  stepCount;          // running led or buzzer state, '0'-is stopped
	int  countCycles;        // counter cycles led or buzzer, '0'-stopped
	int  countPause;		 // time counter on, off
} ohrFlags;

/* USER CODE BEGIN Private defines */

void Event_10ms(void);
void Event_1sec(void);
void Initialize(void);
void BeginOhr(void);
void RunOhr(void);
bool ReadSensorOhr(void);
void ReadControlPin(void);
bool ReadControlOhr(void);
void Sygnalization(int);		    // step of begin
void SetLedOhr(int);
void SetBuzzer(int);
void Println(UART_HandleTypeDef *huart, char _out[]);

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __SYGNAL_1_380_H */

