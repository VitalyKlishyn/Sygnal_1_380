
ADC_HandleTypeDef hadc1;

extern int countSample;
extern uint16_t ADC_result[6];

void adcInit(void);
uint16_t adcRead(void);
void Single(void);
