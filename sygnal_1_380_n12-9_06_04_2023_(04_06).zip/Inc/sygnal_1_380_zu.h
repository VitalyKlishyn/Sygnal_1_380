/*
 * sygnal_1_380_zu.h
 *
 *  Created on: 29 авг. 2022 г.
 *      Author: vitaly
 */

#ifndef __SYGNAL_1_380_ZU_H
#define __SYGNAL_1_380_ZU_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f0xx_hal.h"
#include "main.h"
#include "sygnal_1_380_bus.h"

/* Private defines -----------------------------------------------------------*/
#ifdef _BUS_OUTPUT_UART
#define _ZU_OUTPUT_UART			// debug output to UART1
#endif

// ADC converting, (5^2+1^2+0.5^2)^0.5 ~ 5%, +-1.3 V
// 5%-рез.делитель, 1%-источник опорнрго нанряжения(питания), 0,5%-дискретность АЦП
// ADC-12 bit, Uref=3V3, K=7,912, R1=47k, R2=6k8, Skale=26,11V, ADC_KU=4096/Scale
#define ADC_KU_12			6.3743		// Uizm = data * ADC_KU_12, Ubat, Uin
#define ADC_KU_3			0.8057		// Uizm = data * ADC_KU_3, Uthemperature
#define U_REF_ADC			3300		// in mV
////////////////////
#define	TRUE					1
#define FALSE					0

#define LED_ZU_PIN_ON           1
#define LED_ZU_PIN_OFF		     !LED_ZU_PIN_ON
#define	RELE_ZU_ON				1
#define	RELE_ZU_OFF				!RELE_ZU_ON
#define DISCHARGE_ON			1
#define DISCHARGE_OFF			!DISCHARGE_ON
#define CHARGE_ON				0
#define CHARGE_OFF				!CHARGE_ON

/// Pulse P1 - Test battery
#define COUNT_ZU_LED_ON_P1			100		// 100*timebase = 1000 mSec
#define COUNT_ZU_LED_OFF_P1			100		// 100*timebase = 1000 mSec
/// Pulse P2 - Charge battery in progress
#define COUNT_ZU_LED_ON_P2			10		// 10*timebase = 100 mSec
#define COUNT_ZU_LED_OFF_P2			100		// 100*timebase = 1000 mSec
/// Pulse P5 - Error battery
#define COUNT_ZU_LED_ON_P5			50		// 50*timebase = 500 mSec
#define COUNT_ZU_LED_OFF_P5			50		// 50*timebase = 500 mSec
/// Pulse P8 - Battery is empty, sleep
#define COUNT_ZU_LED_ON_P8			10		// 10*timebase = 100 mSec
#define COUNT_ZU_LED_OFF_P8			500		// 500*timebase = 5000 mSec
/// Pulse P3 - always ON, Charge full
/// Pulse P6 - always OFF, Discharge
/// Pulse P4 - Charge error
#define COUNT_ZU_LED_ON_P4			50		// 50*timebase = 500 mSec
#define COUNT_ZU_LED_OFF_P4			50		// 50*timebase = 500 mSec
#define COUNT_ZU_LED_PAUSE_P4		200		// 200*timebase = 2000 mSec
/// Pulse P7 - Battery low
#define COUNT_ZU_LED_ON_P7			10		// 10*timebase = 100 mSec
#define COUNT_ZU_LED_OFF_P7			50		// 50*timebase = 500 mSec
#define COUNT_ZU_LED_PAUSE_P7		300		// 300*timebase = 3000 mSec

#define ZU_LED_MODE_P6				0		// Pulse P6 - always OFF, Discharge
#define ZU_LED_MODE_P3				1		// Pulse P3 - always ON, Charge full
#define ZU_LED_MODE_P1				5		// Pulse P1 - Test battery
#define ZU_LED_MODE_P2				9		// Pulse P2 - Charge battery in progress
#define ZU_LED_MODE_P5				12		// Pulse P5 - Error battery
#define ZU_LED_MODE_P8				16		// Pulse P8 - Battery is empty, sleep
#define ZU_LED_MODE_P4				24		// Pulse P4 - Charge error
#define ZU_LED_MODE_P7				30		// Pulse P7 - Battery low

#define	U_BAT1					145 // 00	// battery voltage in V*10 (145==>14.5V)
#define	U_BAT2					130 // 00      voltage in V*10 (130==>13.0V)
#define	U_BAT3					115 // 00      voltage in V*10 (115==>11,5V)
#define	U_BAT4					105 // 00      voltage in V*10 (105==>10,5V)
#define	U_BAT5					95  // 00      voltage in V*10 (95==>9,5V)
#define	U_BAT6					80  // 00      voltage in V*10 (80==>8,0V)
#define	U_BAT_ZERO				5   // 00      voltage in V*10 (5==>0,5V)
#define U_AC					14	// 00	// adapter voltage in V (14==>14V)
#define DELTA_U					2	// 		// in V*10	(2==>0,2V)

#define CYCLES_PRECHARGE		2			// n cycles
#define TIME_ZU_1				35			// 35 second
#define TIME_ZU_2				3			// 3 second
#define TIME_ZU_3				60			// 60 second
#define TIME_ZU_4				24			// 24 hour, 86400 second
#define TIME_ZU_5				72			// 72 hour, 259200 second
#define PREDELAY				5			// in sec., after reset

// stateBat
#define		FAULT_BAT			0		// avariya 0, 1, 2
#define     NEPONYATNY_BAT		6		// neponyatny battery 6, 5, 4, 3
#define		TEST_BAT			9		// test battery 9, 8, 7
#define		GOOD_BAT			15		// good battery Nst probe 15, 14, 13, 12, 11, 10
#define 	PRECHARGE_BAT		17		// cycles precharge battery 17, 16
#define		WORK_BAT			22		// 22, 21, 20, 19, 18
#define		CHARGE_BAT			25		// charging 25, 24, 23
#define		CHARGE_FULL			26		// charge full 26, 27
#define		WAIT_TZU5			28		// wait for discharge testing battery

typedef struct
{
	bool pauseState;		 // '1'-in pause state
	bool changeOk;			 // modify parameter is success
	int  stepCount;          // running zu led state, '0'-is stopped
	int  countCycles;        // counter cycles zu led, '0'-stopped
	int  countPause;		 // time counter on, off
} zuFlags;

int uBattery[17];
int uAdapter[17];
int sensorNTC[17];
int countADC;
uint16_t ADC_result[6];
char buff[8];
int stateBat;
int countPreCharge;
int countTimeZu1;
int countTimeZu2;
int countTimeZu3;
uint32_t countTimeZu4;
uint32_t countTimeZu5;
uint16_t U_BAT_tst;			// temporary for test battery
bool meassure_flag;
bool netAC_ok;
bool netAC_last;
bool stateCharge;			// temporary for state charge
uint8_t  cntDischargeProtect;
uint8_t  cntDelayLowInputVoltage;
uint8_t  faultMode;

void InitializeZu(void);
void SetLedZu(int);
void ControlZuLed_10ms(void);
void ControlZu_1sec(void);
void Meassure(void);
void TestBattery(void);
void TimersCharger(void);
void SetReleZu(int);
void SetDischarge(int);
void SetCharge(int);
int ConvTemperature(int);
bool TestAC(void);
bool ifStableVoltage(uint16_t, uint16_t);
void SetAvary(uint16_t);
void SetMemAvary(uint16_t);
void DisChargeOff(void);
void ClearBatAvary(void);
void SetAvaryNoBat(void);

#ifdef __cplusplus
}
#endif

#endif /* __SYGNAL_1_380__ZU_H */
