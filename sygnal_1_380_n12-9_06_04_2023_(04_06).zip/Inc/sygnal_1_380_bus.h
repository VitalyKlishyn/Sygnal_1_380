/*
 * sygnal_1_380_bus.h
 *
 *  Created on: 07 сент. 2022 г.
 *      Author: vitaly
 */
#ifndef __SYGNAL_1_380_BUS_H
#define __SYGNAL_1_380_BUS_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f0xx_hal.h"
#include "main.h"

/* Private defines -----------------------------------------------------------*/
///#define _BUS_OUTPUT_UART			// debug output to UART1

#define			VERSION_PP380			0x0406		// 16 bit, -> 12_09 (04_06)  06/04/2023

#define			MESSAGE_OFF				0
#define			MESSAGE_BUS				1
#define			MESSAGE_ZU				2
#define			MESSAGE_OS				3

#define			MEM_ADDR				0xA0	// 24LC256 chip address
#define 		ARCHIVE_MSG_LEN			8
#define			MAX_ADDR				0x7FE8  //7FF0-ARCHIVE_MSG_LEN=7FE8		// 0x8000 - 0x10
#define			CURR_ADDR				0x7FF2		// store current address (2 bytes)
#define			ARCHIVE_PARAM_MAX		18			// 0...17 uint16 registers
#define			ARCHIVE_MAX_MSG			4094	// 0x7FF0 / 0x08 = 0x0FFE

#define			WAIT_PERIOD_MIN				3
#define			READ_HOLD_REG				0x03
#define			READ_IN_REG					0x04
#define			WRITE_ONE_REG				0x06
#define			LOOP_TEST					0x08
#define			WRITE_MULTI_REG				0x10
#define			REPORT_ID					0x11
#define			READ_WRITE					0x17
#define			TEST_CMD_0					0xA2
#define			TEST_CMD_1					0xA4
#define			TEST_CMD_2					0xA6
#define			TEST_CMD_3					0xA8
#define			TEST_CMD_4					0xAA
#define			TEST_CMD_5					0xA0
#define			TEST_CMD_6					0xAC
#define			TABLE_ZIMA_LETO_READ		0xF0
#define			TABLE_ZIMA_LETO_DEL_LINE	0xF2
#define			TABLE_ZIMA_LETO_ADD_LINE	0xF4

// MACROS BITS
#define	BIT_SET(port, n)	(port |= (1 << n))
#define BIT_CLR(port, n) 	(port &= ~(1 << n))
#define BIT_INV(port, n) 	(port ^= (1 << n))
#define BIT_TEST(port, n) 	(port & (1 << n))

#define		FLASH_CONFIG_START_ADDR			0x0801F000
#define     FLASH_CONFIG_END_ADDR			FLASH_CONFIG_START_ADDR + FLASH_PAGE_SIZE
#define		DELAY_FLASH_WRITE				300		// in sec.
#define		RAM_CONFIG_START_ADDR			0	// physical address = 0x08
#define		RAM_CONFIG_LEN_BYTES			38	// 38 bytes -> 18 words, 56 bytes - MAX!!!
#define		RAM_KEY_DEFINE					0x0568
#define		DEFAULT_SOFT_SWITCH				0x0740	// 03/01/2023 - 0x0740
#define		INIT_STATUS						0x3FF8	// reset 1,2,14,15 bits
#define		COUNTTESTDELAY					5		// 5 -> 4 sec. (N-1)
#define     NEW_SETTINGS_TIMEOUT			11		// in sec.

#define     LOW_TEMPERATURE					5
#define		LOW_HYSTERESIS					2
#define		HIGH_TEMPERATURE				70
#define		HIGH_HYSTERESIS					5
#define     FAULT_CONTROL					3			// 0 bit - wire sensor, 1 bit - low temperature
#define		ERROR_TEMP_HIGH					110
#define		NO_ERROR_TEMP_HIGH				100
#define		ERROR_TEMP_LOW					-30
#define		NO_ERROR_TEMP_LOW				-25
#define		PINTYPE_NO						1
#define		PINTYPE_NC						2
#define		PINTYPE_OFF						0
#define		OUTTYPE_NO						1
#define		OUTTYPE_NC						0
#define		OUT_CNTR_MASK					0
#define		OUT_CNTR_MASK_USER				1
#define		OUT_CNTR_MANUAL					2
#define		OUT_CNTR_REMOTE					4
#define		OUT_OFF_SZO						7
#define		OUT_SHBL_NASOS					0
#define		OUT_SHBL_MN						1
#define		OUT_SHBL_SZO					2
#define		OUT_SHBL_KLAPAN					3
#define		OUT_SHBL_AVARIA					4
#define		MASK_NASOS_VAL					0x01F80002
#define		MASK_MN_VAL						0x01F80003
#define		MASK_AVARIA_VAL					0x00000080		// rele 2
#define		MASK_SZO_VAL					0x03FBFF7F		// rele 1
#define		MASK_KLAPAN_VAL					0x0200103C

#define		FAZA_DELAY						0x8002			// in second, MSB-test poryadok phase
#define		FAZA_SELECT_SIZE				24
#define     FAZA_FAULT						0xF0
#define     FAZA_NO_PHASE_A					0x10
#define     FAZA_NO_PHASE_B					0x20
#define     FAZA_NO_PHASE_C					0x40
#define     FAZA_NO_PHASE_COUNT				0x10
#define     FAZA_NO_PHASE					0x70
#define     FAZA_ABC_UP						0x0
#define     FAZA_ABC_DOWN					0x01
#define		FAZA_ABC_EQU					0x02
#define		FAZA_AB							0x03
#define		FAZA_BC							0x04
#define		FAZA_AC							0x05
#define		FAZA_A							0x06
#define		FAZA_B							0x07
#define		FAZA_C							0x08
#define		OVP_DELAY						0x02		// in sec., (- 1)

#define		MASK_INIT_INPUT					0x0000	// set bits 5,6,7-name default
#define		MASK_REG_INPUT					0x00E0	// set bits 5,6,7(Name change)
#define		MASK_INIT_OUTPUT				0x0000	// set bits 5-name default,6,7,8,9
#define		MASK_REG_OUTPUT					0x07E0	// set bits 5(Name change),6,7,8,9,10
#define		MASK_VLV_OUTPUT					0x04C0	// set bits change 6,7,10
#define		VALVE_STOP						0
#define		VALVE_START						1		// 1,2,3,4,5,6,7 - work
#define		VALVE_ON						1
#define		VALVE_OFF						2
#define		VALVE_DLY_ON					100		// 100*10 mSec = 1 sec
#define		VALVE_DLY_OFF					300		// 300*10 mSec = 3 sec

#define		DEFAULT_BAUD_RATE	0x60	// 9600 (0x60 * 100)
#define		WAITPERIOD_PI382	3		// ~30 mSec
#define		WAIT_BASE			384
#define 	UART_INPUT_LEN		128		// max 27 registers to write (9 bytes cmd)
#define 	UART_OUTPUT_LEN		256
#define 	UART_TIMEOUT		100		// in mS
#define		TEST_LINE_TIME		20		// 20 sec.
#define		MINE				1
#define		STRANGER			0
#define		MINE_MASK			0x3FFF	// 14, 15 bits no set
#define		SET_STRANGER_MASK	0x2000	// 0x2000, set 13 bit
#define		CLR_STRANGER_MASK	0xF7FF	// 0x2800, clr 11 bit
#define		ANS_PORT1_MASK		0x7FFF  // 15 bit off
#define		ANS_PORT2_MASK		0xBFFF	// 14 bit off

#define 	REGISTERS			92		// counter all registers

#define     ARCHIVE_INDEX		74

typedef struct
{
	uint16_t cntReceive;
	uint16_t  waitTimer;
	uint16_t  cntTimeOut;
	uint16_t  startReg;						// for cmd, start data registers index
	uint16_t  lenReg;						// for cmd, data lengh
	uint16_t  cntTestLine;					// counter time errors
	uint8_t	  tstLine;						// testing line avary control
	uint8_t input_buff[UART_INPUT_LEN];
	uint8_t output_buff[UART_OUTPUT_LEN];
	uint8_t num;							// number uart port
	char dataReady;
	char dataOver;
	char mineStranger;						// 1-mine, 0-stranger
} config_uart_t;

typedef struct 				// memory in clock (max 56 bytes, 28 word)
{	// RAM_CONFIG_LEN_BYTES = 36
	uint16_t  status_PP380;
	uint16_t  di1_PP380;
	uint16_t  di2_PP380;
	uint16_t  dim1_PP380;
	uint16_t  dim2_PP380;
	uint16_t  Temperature;				// copy current temperature
	uint16_t  u_input;					// current Uinput
	uint16_t  u_battery;				// current Ubattery
	uint16_t  output_switch_PP380;		// current relay state
	uint16_t  time_PP380;				// Time ( h(15-8), m(7-0)
	uint16_t  date_PP380;				// Date (day(0-4)_mon(5-8)_year(9-14) bits)
	uint16_t  alarm_cmd;				// control state alarm system
	uint16_t  battery_state;			// current state battery
	uint16_t  LineTest;					// test line modbus 1, 2
	int16_t	  temperature;				// current temperature
	uint16_t  eeAddress;
	uint16_t  ramKey;
	uint16_t  Rezerv;					// rezerv
} Registers_var;

typedef struct
{
	uint16_t  CfgTypeInit;
	uint16_t  Mask_0_15;
	uint16_t  Mask_16_31;
	uint8_t   Name[10];
} outFlash_t;

typedef struct
{
	uint16_t  CfgTypeDelay;
	uint8_t   Name[20];
} inFlash_t;

typedef struct
{
	uint16_t  InputsCMD;
	uint16_t  InputsState;
	uint16_t  InputDelay;					// input type and delay
	uint16_t  InputName1;
	uint16_t  InputName2;
	uint16_t  InputName3;
	uint16_t  InputName4;
	uint16_t  InputName5;
	uint16_t  InputName6;
	uint16_t  InputName7;
	uint16_t  InputName8;
	uint16_t  InputName9;
	uint16_t  InputName10;
} input_cmd_t;

typedef struct
{
	uint16_t  OutputsCMD;
	uint16_t  OutputState;
	uint16_t  OutputName1;
	uint16_t  OutputName2;
	uint16_t  OutputName3;
	uint16_t  OutputName4;
	uint16_t  OutputName5;
	uint16_t  OutputType;
	uint16_t  OutputMask0_15;
	uint16_t  OutputMask16_31;
	uint16_t  OutputMask32_47;
} output_cmd_t;

typedef struct
{
	uint16_t  ArchiveCMD;
	uint16_t  ArchiveParam1;
	uint16_t  ArchiveParam2;
	uint16_t  ArchiveParam3;
	uint16_t  ArchiveParam4;
	uint16_t  ArchiveParam5;
	uint16_t  ArchiveParam6;				// 128 words (width 16bit), 256 bytes
	uint16_t  ArchiveParam7;
	uint16_t  ArchiveParam8;
	uint16_t  ArchiveParam9;
	uint16_t  ArchiveParam10;
	uint16_t  ArchiveParam11;
	uint16_t  ArchiveParam12;				// 1
	uint16_t  ArchiveParam13;
	uint16_t  ArchiveParam14;
	uint16_t  ArchiveParam15;
	uint16_t  ArchiveParam16;
	uint16_t  ArchiveParam17;
	uint16_t  ArchiveParam18;				// 140 words (width 16bit), 280 bytes
} archive_cmd_t;

typedef struct
{
	uint16_t  AlarmParam1;					// time wait alarm
	uint16_t  AlarmParam2;					// time alarm
	uint16_t  AlarmParam3;					// count alarm
	uint16_t  VoltageBatteryFull;			// U_BAT1
	uint16_t  VoltageBatteryCharge;			// U_BAT2
	uint16_t  VoltageBatteryDischarge;		// U_BAT3
	uint16_t  VoltageBatteryOff;			// U_BAT4
	uint16_t  VoltageBatteryGood;			// U_BAT5
	uint16_t  VoltageBatteryFault;			// U_BAT6
	uint16_t  TimeBatteryPrecharge;
	uint16_t  TimeBatteryTest;
	uint16_t  TimeBatteryCheck;
	uint16_t  TimeBatteryLimit;				// in hour
	uint16_t  TimeBatteryHealth;			// in hour
	uint16_t  PrechargeCycles;
	uint16_t  VersionPP380;
	uint16_t  DeviceType;
	uint16_t  ReleaseDate;
	uint16_t  SerialNumber1;
	uint16_t  SerialNumber2;
	uint16_t  FlashCntWrite;				// 21 words (width 16bit), 42 bytes, 10,5 dwords
	//  input_cmd_registers
	uint16_t  LowTemperature;
	uint16_t  LowHysteresys;
	uint16_t  HighTemperature;
	uint16_t  HighHysteresis;
	uint16_t  FaultControl;
	uint16_t  DelayNetSensor;
	uint16_t  VoltageLevelInput;
	uint16_t  VoltageInputHysteresis;
	uint16_t  VoltageLevelBattery;
	uint16_t  VoltageBatteryHysteresis;		// 31 words (width 16bit), 62 bytes, 15,5 dwords
	// output_cmd_registers
	uint16_t  AddressPP380;
	uint16_t  BaudRate;						// baud * 100
	uint16_t  BitsConfig;					// data (0-1), stop (2-3), parity (4-5)
	// archive_cmd_registers				// 34 words (width 16bit), 78 bytes, 17 dwords
//  Inputs store DevNVRAM
	inFlash_t DF1;							// inFlash_t -> 11 words (16 bit)
	inFlash_t DF2;
	inFlash_t DF3;
	inFlash_t DF4;
	inFlash_t DF5;
	inFlash_t DF6;
	inFlash_t DF7;
	inFlash_t DF8;
	inFlash_t DF9;
	inFlash_t DF10;
	inFlash_t DF11;
	inFlash_t DF12;
	inFlash_t DF13;
	inFlash_t DF14;
	inFlash_t DF15;
	inFlash_t DF16;							// 210 words (width 16bit), 420 bytes, 105 dwords
//  Outputs store DevNVRAM
	outFlash_t	ReleF1;						// outFlash_t -> 8 words (16 bit)
	outFlash_t	ReleF2;
	outFlash_t	ReleF3;
	outFlash_t	ReleF4;
	outFlash_t	ReleF5;
	outFlash_t	ValveF;				// 258 words (width 16bit), 516 bytes, 129 dwords
//	uint16_t  to_parity;					// align data, 366 words

    uint32_t  magicKey;				// all 130 d_words
} Registers_t;

struct FLASH_Sector
{
    uint8_t    data[2048-4];
    uint16_t   cntWrite;
    uint16_t   checkSum;
};

union NVRAM
{
	Registers_t				config;
	struct	FLASH_Sector	sector;
	uint32_t				data32[512];
} DevNVRAM;

union CLOCKRAM
{
	Registers_var		config;
	uint8_t				data8[RAM_CONFIG_LEN_BYTES];
} ClockRAM;

typedef struct
{
	uint16_t counter;		// delay counter
	uint8_t  state;			// current counter state, 0-stop, 1-start
	uint8_t	 type;			// output type, read from registers
	uint16_t init;			// state of initialize, read from registers
	uint16_t shablon;		// shablon for mask
	uint16_t mask0;			// mask 0...15 for working
	uint16_t mask1;			// mask 16...31 for working
//	uint8_t  name[10];		// name outputs, read/write in registers
} output_t;					// 17 bytes nvram

typedef struct
{
	uint8_t  state;			// pin current state
	uint16_t delay;			// delay counter
	uint8_t	 type;			// input type, read from registers (no OVP)
//	uint16_t configDelay;	// delay, read from registers
//	uint8_t name[20];		// name inputs, read/write in registers
} input_t;					// 22 bytes nvram

struct PHASE_NET
{
	uint8_t  phase;						// tested phase result
	uint8_t  phaseOld;					// tested phase old result
	uint16_t nophAcnt;					// no phase A counter
	uint16_t nophBcnt;					// no phase B counter
	uint16_t nophCcnt;					// no phase C counter
	uint16_t nophcnt;					// no all phase counter
	uint8_t  select[FAZA_SELECT_SIZE];	// selected from input
	uint8_t  cntBuff;					// counter input buffer, interrupt
	uint8_t  delay;						// delay for registers
	uint8_t  state;						// state counter
};

#ifdef _BUS_OUTPUT_UART
uint8_t	 debugMessage;						/// debug
uint8_t  input_bf[UART_INPUT_LEN];			/// debug
uint8_t  len_bf;							/// debug
uint16_t timerRes;							/// debug
uint16_t regState;							/// debug
#endif

uint16_t errorInitUART1;
uint16_t errorInitUART2;

extern uint16_t cnt10mS;

uint8_t  resetDefault;
uint8_t  beginDelay;
uint8_t  beginInputFlag;
uint8_t  buff_i2c[RAM_CONFIG_LEN_BYTES];
uint8_t  currAddress;
uint16_t WaitPeriod;
uint8_t  tempSensorOk;
uint8_t  countTestDelay;					// 3 sec. default
uint8_t  countSettingsDelay;
uint8_t  myAddress;
uint16_t oldSpeed;
uint16_t oldParam;
uint8_t  trueAddress;
uint8_t  flagReInstal;

uint32_t  nvAddress;
uint32_t  nvIndex;
uint32_t  nvError;
uint32_t  inputNow;
uint32_t  inputOld;
uint32_t  inputNowMem;
uint32_t  inputOldMem;
uint32_t  inputDiNow;
uint32_t  inputDiOld;
uint32_t  inputDiNowSZO;
uint32_t  inputDiOldSZO;
uint32_t  inputSZOmask;
uint8_t   flagDiSZO;
uint8_t   flagRunVLV;			// valve no change - 0; VALVE_ON - 1; VALVE_OFF - 2;

uint16_t  archiveEeAddrPoint;
uint16_t  archiveYear;
uint16_t  archiveMonth;
uint16_t  archiveDay;
uint16_t  archiveIndexYears;
uint16_t  archiveIndexMonts;
uint16_t  archiveIndexDays;
uint16_t  archiveIndexEvents;
uint16_t  archiveCntYears;
uint16_t  archiveCntMonts;
uint16_t  archiveCntDays;
uint16_t  archiveCntEvents;
uint16_t  archiveArrYears[ARCHIVE_PARAM_MAX];
uint16_t  archiveArrMonts[ARCHIVE_PARAM_MAX];
uint16_t  archiveArrDays[ARCHIVE_PARAM_MAX*2];
uint16_t  archiveArrEvents[ARCHIVE_PARAM_MAX*15];

config_uart_t UART_1;
config_uart_t UART_2;
config_uart_t UART_3;

input_cmd_t   InputCmd;
output_cmd_t  OutputCmd;
archive_cmd_t ArchiveCmd;

uint16_t *ptr_reg[REGISTERS];

uint16_t sequenceCmd[4];				// [0] - flag, [1]-address, [2]-value

struct PHASE_NET phaseNet;

input_t D1;
input_t D2;
input_t D3;
input_t D4;
input_t D5;
input_t D6;
input_t D7;
input_t D8;
input_t D9;
input_t D10;
input_t D11;
input_t D12;
input_t D13;
input_t D14;
input_t D15;
input_t D16;
input_t OVP;

output_t RELE1;
output_t RELE2;
output_t RELE3;
output_t RELE4;
output_t RELE5;
output_t VALVE;

void InitializeBus(void);
void TimeOutReceive_10ms(void);
void Event_1sec_bus(void);
void Setup_UARTs(void);
void FlashToRegisters(void);
void RefreshFlashData(void);
void ReadRamToRegisters(void);
void RefreshMemData(void);
void ReadUART1(void);
void ReadUART2(void);
void ReadUART3(void);
void UARTsend(config_uart_t*,uint16_t);
void Working(void);
void WriteArchive(void);
void InitD(input_t*, inFlash_t*, uint16_t);
void GetInitD1(void);
void GetInitD2(void);
void GetInitD3(void);
void GetInitD4(void);
void GetInitD5(void);
void GetInitD6(void);
void GetInitD7(void);
void GetInitD8(void);
void GetInitD9(void);
void GetInitD10(void);
void GetInitD11(void);
void GetInitD12(void);
void GetInitD13(void);
void GetInitD14(void);
void GetInitD15(void);
void GetInitD16(void);
void TestOVP(void);
void TestD(input_t*, inFlash_t*, uint16_t bit, GPIO_TypeDef*, uint16_t);
void InitRele1(uint16_t);
void InitRele2(uint16_t);
void InitRele3(uint16_t);
void InitRele4(uint16_t);
void InitRele5(uint16_t);
void InitValve(uint16_t);
void GetInitRele1(void);
void GetInitRele2(void);
void GetInitRele3(void);
void GetInitRele4(void);
void GetInitRele5(void);
void GetInitValve(void);
void InitOut(output_t*, outFlash_t*, uint16_t);
void SetRele1(void);
void SetRele2(void);
void SetRele3(void);
void SetRele4(void);
void SetRele5(void);
void SetValve(void);
void RunValve(void);
void DelayCounting(void);
void InitInputPins(void);
void ReadInputPins(void);
void InitOutputPins(void);
void SetOutputPins(void);
void RefreshOutputPins(void);
void SetFlagValve(void);
void TestPhase(void);
void TestLines(void);
void SetTestLines(uint16_t);
uint8_t ComparePhase(uint8_t*);
void PhaseStateChange(void);
void ReadTemperature(void);
void ParseInput(config_uart_t*);
void GetReportId(config_uart_t*);
uint8_t WriteRegister(uint16_t,uint16_t,uint8_t);
uint16_t ReadRegisters(config_uart_t*);
uint16_t StatusRegProc(uint16_t, uint8_t);
uint16_t CalculateCRC16(uint8_t*, uint8_t);
void SetInputName(uint8_t*);
void GetInputName(uint8_t*);
void SetOutputName(uint8_t*);
void GetOutputName(uint8_t*);
void IndexingRegisters(void);
void InputRegistersCmd(uint16_t);
void InputRegistersWrite(uint16_t);
void InputRegistersRead(uint16_t);
void OutputRegistersCmd(uint16_t);
void OutputRegistersWrite(uint16_t);
void OutputRegistersRead(uint16_t);
void RunSequenceCmd(void);
void InitArchive(void);
void ArchiveCommand(uint16_t);
uint16_t ArchiveReadYears(uint16_t*,uint8_t,uint16_t);
uint16_t ArchiveReadMonts(uint16_t*,uint8_t,uint8_t,uint16_t);
uint16_t ArchiveReadDays(uint16_t*,uint8_t,uint8_t,uint8_t,uint16_t);
uint16_t ArchiveReadEvents(uint16_t*,uint8_t,uint8_t,uint8_t,uint16_t,uint16_t);
void ArchiveDebug(uint16_t,uint16_t,uint16_t);
void InitEEPROM(void);
void NextAddrEEPROM(void);
uint16_t ClearEEprom(void);
void OffSZO(void);
void SetFlagSZO(void);
void ChangeSettings(void);
void USART1_Init(uint32_t, uint32_t, uint32_t, uint32_t); // speed, data, stop, parity
void USART2_Init(uint32_t, uint32_t, uint32_t, uint32_t); // speed, data, stop, parity
void USART3_Init(void);
uint16_t CheckBaudRate(uint16_t);
void Ports_1_2_ReInit(void);
void TestStatus01(void);			/// debug

#ifdef __cplusplus
}
#endif

#endif /* __SYGNAL_1_380__BUS_H */
