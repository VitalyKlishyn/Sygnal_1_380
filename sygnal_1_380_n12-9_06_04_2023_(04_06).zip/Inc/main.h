/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f0xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */
#define 	bool		 char
/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define DCH_Pin GPIO_PIN_13
#define DCH_GPIO_Port GPIOC
#define RELE_ZU_Pin GPIO_PIN_14
#define RELE_ZU_GPIO_Port GPIOC
#define EN_ZU_Pin GPIO_PIN_15
#define EN_ZU_GPIO_Port GPIOC
#define AN_AK_Pin GPIO_PIN_0
#define AN_AK_GPIO_Port GPIOC
#define AN_BP_Pin GPIO_PIN_1
#define AN_BP_GPIO_Port GPIOC
#define AN_NTC_Pin GPIO_PIN_2
#define AN_NTC_GPIO_Port GPIOC
#define LED_ZU_Pin GPIO_PIN_3
#define LED_ZU_GPIO_Port GPIOC
#define DIR2_Pin GPIO_PIN_1
#define DIR2_GPIO_Port GPIOA
#define TX2_Pin GPIO_PIN_2
#define TX2_GPIO_Port GPIOA
#define FAZA1_Pin GPIO_PIN_4
#define FAZA1_GPIO_Port GPIOA
#define FAZA2_Pin GPIO_PIN_5
#define FAZA2_GPIO_Port GPIOA
#define FAZA3_Pin GPIO_PIN_6
#define FAZA3_GPIO_Port GPIOA
#define RELE1_Pin GPIO_PIN_7
#define RELE1_GPIO_Port GPIOA
#define RELE2_Pin GPIO_PIN_0
#define RELE2_GPIO_Port GPIOB
#define RELE3_Pin GPIO_PIN_1
#define RELE3_GPIO_Port GPIOB
#define RELE4_Pin GPIO_PIN_2
#define RELE4_GPIO_Port GPIOB
#define RELE5_Pin GPIO_PIN_10
#define RELE5_GPIO_Port GPIOB
#define VLV_Pin GPIO_PIN_11
#define VLV_GPIO_Port GPIOB
#define OVP_Pin GPIO_PIN_12
#define OVP_GPIO_Port GPIOB
#define D1_Pin GPIO_PIN_13
#define D1_GPIO_Port GPIOB
#define D2_Pin GPIO_PIN_14
#define D2_GPIO_Port GPIOB
#define D3_Pin GPIO_PIN_15
#define D3_GPIO_Port GPIOB
#define D4_Pin GPIO_PIN_6
#define D4_GPIO_Port GPIOC
#define D5_Pin GPIO_PIN_7
#define D5_GPIO_Port GPIOC
#define D6_Pin GPIO_PIN_8
#define D6_GPIO_Port GPIOC
#define D7_Pin GPIO_PIN_9
#define D7_GPIO_Port GPIOC
#define D8_Pin GPIO_PIN_8
#define D8_GPIO_Port GPIOA
#define D9_Pin GPIO_PIN_9
#define D9_GPIO_Port GPIOA
#define D10_Pin GPIO_PIN_10
#define D10_GPIO_Port GPIOA
#define D11_Pin GPIO_PIN_11
#define D11_GPIO_Port GPIOA
#define D12_Pin GPIO_PIN_12
#define D12_GPIO_Port GPIOA
#define SWDIO_Pin GPIO_PIN_13
#define SWDIO_GPIO_Port GPIOA
#define SWCLK_Pin GPIO_PIN_14
#define SWCLK_GPIO_Port GPIOA
#define D13_Pin GPIO_PIN_15
#define D13_GPIO_Port GPIOA
#define D14_Pin GPIO_PIN_10
#define D14_GPIO_Port GPIOC
#define D15_Pin GPIO_PIN_11
#define D15_GPIO_Port GPIOC
#define D16_Pin GPIO_PIN_12
#define D16_GPIO_Port GPIOC
#define SEC_Pin GPIO_PIN_2
#define SEC_GPIO_Port GPIOD
#define LED_Pin GPIO_PIN_3
#define LED_GPIO_Port GPIOB
#define BUZ_Pin GPIO_PIN_4
#define BUZ_GPIO_Port GPIOB
#define DIR1_Pin GPIO_PIN_5
#define DIR1_GPIO_Port GPIOB
#define TX1_Pin GPIO_PIN_6
#define TX1_GPIO_Port GPIOB
#define RX1_Pin GPIO_PIN_7
#define RX1_GPIO_Port GPIOB
#define SCL_Pin GPIO_PIN_8
#define SCL_GPIO_Port GPIOB
#define SDA_Pin GPIO_PIN_9
#define SDA_GPIO_Port GPIOB
/* USER CODE BEGIN Private defines */
uint16_t cnt10mS;
int countSample;		// for ADC
char Event_1sec_OS;
char Event_1sec_ZU;
char Event_10mS_OS;
char Event_10mS_ZU;
char Event_10mS_BUS;
char Event_1sec_BUS;

void Task_OS(void);
void Task_ZU(void);
void Task_BUS(void);
/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
